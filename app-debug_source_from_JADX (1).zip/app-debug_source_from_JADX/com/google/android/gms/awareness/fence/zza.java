package com.google.android.gms.awareness.fence;

public interface zza {
}
