package com.google.android.gms.awareness.fence;

import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.internal.zzaep;
import java.util.ArrayList;
import java.util.Collection;

public abstract class AwarenessFence extends zza {
    protected AwarenessFence() {
    }

    public static AwarenessFence and(Collection<AwarenessFence> collection) {
        boolean z = (collection == null || collection.isEmpty()) ? false : true;
        zzac.zzax(z);
        return zzaep.zzg(zzd(collection));
    }

    public static AwarenessFence and(AwarenessFence... awarenessFenceArr) {
        boolean z = awarenessFenceArr != null && awarenessFenceArr.length > 0;
        zzac.zzax(z);
        return zzaep.zzg(zza(awarenessFenceArr));
    }

    public static AwarenessFence not(AwarenessFence awarenessFence) {
        zzac.zzw(awarenessFence);
        return zzaep.zza((zzaep) awarenessFence);
    }

    public static AwarenessFence or(Collection<AwarenessFence> collection) {
        boolean z = (collection == null || collection.isEmpty()) ? false : true;
        zzac.zzax(z);
        return zzaep.zzh(zzd(collection));
    }

    public static AwarenessFence or(AwarenessFence... awarenessFenceArr) {
        boolean z = awarenessFenceArr != null && awarenessFenceArr.length > 0;
        zzac.zzax(z);
        return zzaep.zzh(zza(awarenessFenceArr));
    }

    private static ArrayList<zzaep> zza(AwarenessFence[] awarenessFenceArr) {
        ArrayList<zzaep> arrayList = new ArrayList(awarenessFenceArr.length);
        for (AwarenessFence awarenessFence : awarenessFenceArr) {
            arrayList.add((zzaep) awarenessFence);
        }
        return arrayList;
    }

    private static ArrayList<zzaep> zzd(Collection<AwarenessFence> collection) {
        ArrayList<zzaep> arrayList = new ArrayList(collection.size());
        for (AwarenessFence awarenessFence : collection) {
            arrayList.add((zzaep) awarenessFence);
        }
        return arrayList;
    }
}
