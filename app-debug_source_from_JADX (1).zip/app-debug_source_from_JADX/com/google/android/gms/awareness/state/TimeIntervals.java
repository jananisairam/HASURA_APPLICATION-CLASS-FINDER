package com.google.android.gms.awareness.state;

public interface TimeIntervals {
    int[] getTimeIntervals();

    boolean hasTimeInterval(int i);
}
