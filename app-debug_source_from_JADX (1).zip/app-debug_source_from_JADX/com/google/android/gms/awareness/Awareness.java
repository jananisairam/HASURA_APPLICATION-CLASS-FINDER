package com.google.android.gms.awareness;

import com.google.android.gms.common.api.Api;
import com.google.android.gms.internal.zzaef;

public final class Awareness {
    public static final Api<AwarenessOptions> API = zzaef.API;
    public static final FenceApi FenceApi = zzaef.FenceApi;
    public static final SnapshotApi SnapshotApi = zzaef.SnapshotApi;

    private Awareness() {
    }
}
