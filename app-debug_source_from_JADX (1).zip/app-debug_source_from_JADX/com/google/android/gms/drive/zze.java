package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zze extends zza {
    public static final Creator<zze> CREATOR = new zzf();
    final long zzaKQ;
    final long zzaKR;
    final int zzaiI;

    zze(int i, long j, long j2) {
        this.zzaiI = i;
        this.zzaKQ = j;
        this.zzaKR = j2;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzf.zza(this, parcel, i);
    }
}
