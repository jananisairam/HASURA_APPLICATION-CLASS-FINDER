package com.google.android.gms.drive;

import com.google.android.gms.drive.ExecutionOptions.Builder;

public class zzk extends ExecutionOptions {
    private String zzaLf;
    private String zzaLg;

    public static class zza extends Builder {
        public /* synthetic */ ExecutionOptions build() {
            return zzAA();
        }

        public /* synthetic */ Builder setConflictStrategy(int i) {
            return zzei(i);
        }

        public /* synthetic */ Builder setNotifyOnCompletion(boolean z) {
            return zzay(z);
        }

        public /* synthetic */ Builder setTrackingTag(String str) {
            return zzdF(str);
        }

        public zzk zzAA() {
            zzAx();
            return new zzk(this.zzaLc, this.zzaLd, null, null, this.zzaLe);
        }

        public zza zzay(boolean z) {
            super.setNotifyOnCompletion(z);
            return this;
        }

        public zza zzdF(String str) {
            super.setTrackingTag(str);
            return this;
        }

        public zza zzei(int i) {
            throw new UnsupportedOperationException();
        }
    }

    private zzk(String str, boolean z, String str2, String str3, int i) {
        super(str, z, i);
        this.zzaLf = str2;
        this.zzaLg = str3;
    }

    public static zzk zza(ExecutionOptions executionOptions) {
        zza com_google_android_gms_drive_zzk_zza = new zza();
        if (executionOptions != null) {
            if (executionOptions.zzAw() != 0) {
                throw new IllegalStateException("May not set a conflict strategy for new file creation.");
            }
            String zzAu = executionOptions.zzAu();
            if (zzAu != null) {
                com_google_android_gms_drive_zzk_zza.setTrackingTag(zzAu);
            }
            com_google_android_gms_drive_zzk_zza.setNotifyOnCompletion(executionOptions.zzAv());
        }
        return (zzk) com_google_android_gms_drive_zzk_zza.build();
    }

    public String zzAy() {
        return this.zzaLf;
    }

    public String zzAz() {
        return this.zzaLg;
    }
}
