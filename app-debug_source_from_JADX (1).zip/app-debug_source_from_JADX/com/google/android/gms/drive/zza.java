package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.Base64;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.internal.zzalr;
import com.google.android.gms.internal.zzbxt;

public class zza extends com.google.android.gms.common.internal.safeparcel.zza {
    public static final Creator<zza> CREATOR = new zzb();
    final long zzaKA;
    final long zzaKB;
    final long zzaKC;
    private volatile String zzaKD = null;
    final int zzaiI;

    zza(int i, long j, long j2, long j3) {
        boolean z = true;
        zzac.zzax(j != -1);
        zzac.zzax(j2 != -1);
        if (j3 == -1) {
            z = false;
        }
        zzac.zzax(z);
        this.zzaiI = i;
        this.zzaKA = j;
        this.zzaKB = j2;
        this.zzaKC = j3;
    }

    public final String encodeToString() {
        if (this.zzaKD == null) {
            String encodeToString = Base64.encodeToString(zzAn(), 10);
            String valueOf = String.valueOf("ChangeSequenceNumber:");
            encodeToString = String.valueOf(encodeToString);
            this.zzaKD = encodeToString.length() != 0 ? valueOf.concat(encodeToString) : new String(valueOf);
        }
        return this.zzaKD;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof zza)) {
            return false;
        }
        zza com_google_android_gms_drive_zza = (zza) obj;
        return com_google_android_gms_drive_zza.zzaKB == this.zzaKB && com_google_android_gms_drive_zza.zzaKC == this.zzaKC && com_google_android_gms_drive_zza.zzaKA == this.zzaKA;
    }

    public int hashCode() {
        String valueOf = String.valueOf(String.valueOf(this.zzaKA));
        String valueOf2 = String.valueOf(String.valueOf(this.zzaKB));
        String valueOf3 = String.valueOf(String.valueOf(this.zzaKC));
        return new StringBuilder((String.valueOf(valueOf).length() + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append(valueOf).append(valueOf2).append(valueOf3).toString().hashCode();
    }

    public String toString() {
        return encodeToString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzb.zza(this, parcel, i);
    }

    final byte[] zzAn() {
        zzbxt com_google_android_gms_internal_zzalr = new zzalr();
        com_google_android_gms_internal_zzalr.versionCode = this.zzaiI;
        com_google_android_gms_internal_zzalr.zzaOC = this.zzaKA;
        com_google_android_gms_internal_zzalr.zzaOD = this.zzaKB;
        com_google_android_gms_internal_zzalr.zzaOE = this.zzaKC;
        return zzbxt.zzf(com_google_android_gms_internal_zzalr);
    }
}
