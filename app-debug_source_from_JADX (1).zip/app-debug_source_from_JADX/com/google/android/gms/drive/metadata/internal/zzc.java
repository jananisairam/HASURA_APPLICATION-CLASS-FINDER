package com.google.android.gms.drive.metadata.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.drive.metadata.CustomPropertyKey;

public class zzc extends zza {
    public static final Creator<zzc> CREATOR = new zzd();
    final String mValue;
    final CustomPropertyKey zzaOQ;
    final int zzaiI;

    zzc(int i, CustomPropertyKey customPropertyKey, String str) {
        this.zzaiI = i;
        zzac.zzb((Object) customPropertyKey, (Object) "key");
        this.zzaOQ = customPropertyKey;
        this.mValue = str;
    }

    public zzc(CustomPropertyKey customPropertyKey, String str) {
        this(1, customPropertyKey, str);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        zzc com_google_android_gms_drive_metadata_internal_zzc = (zzc) obj;
        return zzaa.equal(this.zzaOQ, com_google_android_gms_drive_metadata_internal_zzc.zzaOQ) && zzaa.equal(this.mValue, com_google_android_gms_drive_metadata_internal_zzc.mValue);
    }

    public String getValue() {
        return this.mValue;
    }

    public int hashCode() {
        return zzaa.hashCode(this.zzaOQ, this.mValue);
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzd.zza(this, parcel, i);
    }

    public CustomPropertyKey zzBu() {
        return this.zzaOQ;
    }
}
