package com.google.android.gms.drive.metadata.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.BitmapTeleporter;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.zzaic;
import com.google.android.gms.internal.zzalu;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class MetadataBundle extends zza implements ReflectedParcelable {
    public static final Creator<MetadataBundle> CREATOR = new zzi();
    final Bundle zzaOT;
    final int zzaiI;

    MetadataBundle(int i, Bundle bundle) {
        this.zzaiI = i;
        this.zzaOT = (Bundle) zzac.zzw(bundle);
        this.zzaOT.setClassLoader(getClass().getClassLoader());
        List<String> arrayList = new ArrayList();
        for (String str : this.zzaOT.keySet()) {
            String str2;
            if (zzf.zzdJ(str2) == null) {
                arrayList.add(str2);
                String str3 = "MetadataBundle";
                String str4 = "Ignored unknown metadata field in bundle: ";
                str2 = String.valueOf(str2);
                zzaic.zzF(str3, str2.length() != 0 ? str4.concat(str2) : new String(str4));
            }
        }
        for (String str22 : arrayList) {
            this.zzaOT.remove(str22);
        }
    }

    private MetadataBundle(Bundle bundle) {
        this(1, bundle);
    }

    public static MetadataBundle zzBx() {
        return new MetadataBundle(new Bundle());
    }

    public static <T> MetadataBundle zzb(MetadataField<T> metadataField, T t) {
        MetadataBundle zzBx = zzBx();
        zzBx.zzc(metadataField, t);
        return zzBx;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MetadataBundle)) {
            return false;
        }
        MetadataBundle metadataBundle = (MetadataBundle) obj;
        Set<String> keySet = this.zzaOT.keySet();
        if (!keySet.equals(metadataBundle.zzaOT.keySet())) {
            return false;
        }
        for (String str : keySet) {
            if (!zzaa.equal(this.zzaOT.get(str), metadataBundle.zzaOT.get(str))) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        int i = 1;
        for (String str : this.zzaOT.keySet()) {
            i *= 31;
            i = this.zzaOT.get(str).hashCode() + i;
        }
        return i;
    }

    public void setContext(Context context) {
        BitmapTeleporter bitmapTeleporter = (BitmapTeleporter) zza(zzalu.zzaPC);
        if (bitmapTeleporter != null) {
            bitmapTeleporter.zzd(context.getCacheDir());
        }
    }

    public String toString() {
        String valueOf = String.valueOf(this.zzaOT);
        return new StringBuilder(String.valueOf(valueOf).length() + 24).append("MetadataBundle [values=").append(valueOf).append("]").toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzi.zza(this, parcel, i);
    }

    public MetadataBundle zzBy() {
        return new MetadataBundle(new Bundle(this.zzaOT));
    }

    public Set<MetadataField<?>> zzBz() {
        Set<MetadataField<?>> hashSet = new HashSet();
        for (String zzdJ : this.zzaOT.keySet()) {
            hashSet.add(zzf.zzdJ(zzdJ));
        }
        return hashSet;
    }

    public <T> T zza(MetadataField<T> metadataField) {
        return metadataField.zzs(this.zzaOT);
    }

    public <T> void zzc(MetadataField<T> metadataField, T t) {
        if (zzf.zzdJ(metadataField.getName()) == null) {
            String str = "Unregistered field: ";
            String valueOf = String.valueOf(metadataField.getName());
            throw new IllegalArgumentException(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        }
        metadataField.zza(t, this.zzaOT);
    }

    public boolean zzc(MetadataField<?> metadataField) {
        return this.zzaOT.containsKey(metadataField.getName());
    }
}
