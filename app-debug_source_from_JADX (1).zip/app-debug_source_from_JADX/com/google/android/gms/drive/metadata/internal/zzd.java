package com.google.android.gms.drive.metadata.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.drive.metadata.CustomPropertyKey;

public class zzd implements Creator<zzc> {
    static void zza(zzc com_google_android_gms_drive_metadata_internal_zzc, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, com_google_android_gms_drive_metadata_internal_zzc.zzaiI);
        zzc.zza(parcel, 2, com_google_android_gms_drive_metadata_internal_zzc.zzaOQ, i, false);
        zzc.zza(parcel, 3, com_google_android_gms_drive_metadata_internal_zzc.mValue, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzdk(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzfK(i);
    }

    public zzc zzdk(Parcel parcel) {
        String str = null;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        CustomPropertyKey customPropertyKey = null;
        while (parcel.dataPosition() < zzaY) {
            CustomPropertyKey customPropertyKey2;
            int zzg;
            String str2;
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    String str3 = str;
                    customPropertyKey2 = customPropertyKey;
                    zzg = zzb.zzg(parcel, zzaX);
                    str2 = str3;
                    break;
                case 2:
                    zzg = i;
                    CustomPropertyKey customPropertyKey3 = (CustomPropertyKey) zzb.zza(parcel, zzaX, CustomPropertyKey.CREATOR);
                    str2 = str;
                    customPropertyKey2 = customPropertyKey3;
                    break;
                case 3:
                    str2 = zzb.zzq(parcel, zzaX);
                    customPropertyKey2 = customPropertyKey;
                    zzg = i;
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    str2 = str;
                    customPropertyKey2 = customPropertyKey;
                    zzg = i;
                    break;
            }
            i = zzg;
            customPropertyKey = customPropertyKey2;
            str = str2;
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzc(i, customPropertyKey, str);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzc[] zzfK(int i) {
        return new zzc[i];
    }
}
