package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.common.util.zzf;
import java.util.Set;
import java.util.regex.Pattern;

public class DriveSpace extends zza implements ReflectedParcelable {
    public static final Creator<DriveSpace> CREATOR = new zzj();
    public static final DriveSpace zzaKW = new DriveSpace("DRIVE");
    public static final DriveSpace zzaKX = new DriveSpace("APP_DATA_FOLDER");
    public static final DriveSpace zzaKY = new DriveSpace("PHOTOS");
    public static final Set<DriveSpace> zzaKZ = zzf.zza(zzaKW, zzaKX, zzaKY);
    public static final String zzaLa = TextUtils.join(",", zzaKZ.toArray());
    private static final Pattern zzaLb = Pattern.compile("[A-Z0-9_]*");
    private final String mName;
    final int zzaiI;

    DriveSpace(int i, String str) {
        this.zzaiI = i;
        this.mName = (String) zzac.zzw(str);
    }

    private DriveSpace(String str) {
        this(1, str);
    }

    public boolean equals(Object obj) {
        return (obj == null || obj.getClass() != DriveSpace.class) ? false : this.mName.equals(((DriveSpace) obj).mName);
    }

    public String getName() {
        return this.mName;
    }

    public int hashCode() {
        return 1247068382 ^ this.mName.hashCode();
    }

    public String toString() {
        return this.mName;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzj.zza(this, parcel, i);
    }
}
