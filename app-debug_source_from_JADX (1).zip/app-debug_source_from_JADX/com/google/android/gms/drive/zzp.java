package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import java.util.List;

public class zzp implements Creator<zzo> {
    static void zza(zzo com_google_android_gms_drive_zzo, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, com_google_android_gms_drive_zzo.zzaiI);
        zzc.zzb(parcel, 2, com_google_android_gms_drive_zzo.zzaLw, false);
        zzc.zzb(parcel, 3, com_google_android_gms_drive_zzo.zzaLx, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzbS(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzen(i);
    }

    public zzo zzbS(Parcel parcel) {
        List list = null;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        List list2 = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 2:
                    list2 = zzb.zzE(parcel, zzaX);
                    break;
                case 3:
                    list = zzb.zzE(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzo(i, list2, list);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzo[] zzen(int i) {
        return new zzo[i];
    }
}
