package com.google.android.gms.drive;

import com.google.android.gms.common.data.AbstractDataBuffer;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.drive.metadata.internal.zzf;
import com.google.android.gms.internal.zzahq;
import com.google.android.gms.internal.zzalu;

public final class MetadataBuffer extends AbstractDataBuffer<Metadata> {
    private zza zzaLi;

    private static class zza extends Metadata {
        private final DataHolder zzaBi;
        private final int zzaDM;
        private final int zzaLj;

        public zza(DataHolder dataHolder, int i) {
            this.zzaBi = dataHolder;
            this.zzaLj = i;
            this.zzaDM = dataHolder.zzcI(i);
        }

        public /* synthetic */ Object freeze() {
            return zzAD();
        }

        public boolean isDataValid() {
            return !this.zzaBi.isClosed();
        }

        public Metadata zzAD() {
            MetadataBundle zzBx = MetadataBundle.zzBx();
            for (MetadataField metadataField : zzf.zzBv()) {
                if (metadataField != zzalu.zzaPC) {
                    metadataField.zza(this.zzaBi, zzBx, this.zzaLj, this.zzaDM);
                }
            }
            return new zzahq(zzBx);
        }

        public <T> T zza(MetadataField<T> metadataField) {
            return metadataField.zza(this.zzaBi, this.zzaLj, this.zzaDM);
        }
    }

    public MetadataBuffer(DataHolder dataHolder) {
        super(dataHolder);
        dataHolder.zzxf().setClassLoader(MetadataBuffer.class.getClassLoader());
    }

    public Metadata get(int i) {
        zza com_google_android_gms_drive_MetadataBuffer_zza = this.zzaLi;
        if (com_google_android_gms_drive_MetadataBuffer_zza != null && com_google_android_gms_drive_MetadataBuffer_zza.zzaLj == i) {
            return com_google_android_gms_drive_MetadataBuffer_zza;
        }
        Metadata com_google_android_gms_drive_MetadataBuffer_zza2 = new zza(this.zzaBi, i);
        this.zzaLi = com_google_android_gms_drive_MetadataBuffer_zza2;
        return com_google_android_gms_drive_MetadataBuffer_zza2;
    }

    @Deprecated
    public String getNextPageToken() {
        return null;
    }

    public void release() {
        if (this.zzaBi != null) {
            zzf.zza(this.zzaBi);
        }
        super.release();
    }
}
