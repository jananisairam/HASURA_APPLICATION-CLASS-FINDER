package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzn implements Creator<zzm> {
    static void zza(zzm com_google_android_gms_drive_zzm, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, com_google_android_gms_drive_zzm.zzaiI);
        zzc.zza(parcel, 2, com_google_android_gms_drive_zzm.zzAH(), false);
        zzc.zzc(parcel, 3, com_google_android_gms_drive_zzm.zzAI());
        zzc.zza(parcel, 4, com_google_android_gms_drive_zzm.zzAJ(), false);
        zzc.zza(parcel, 5, com_google_android_gms_drive_zzm.zzAK(), false);
        zzc.zzc(parcel, 6, com_google_android_gms_drive_zzm.getRole());
        zzc.zza(parcel, 7, com_google_android_gms_drive_zzm.zzAL());
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzbR(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzem(i);
    }

    public zzm zzbR(Parcel parcel) {
        String str = null;
        boolean z = false;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        String str2 = null;
        int i2 = 0;
        String str3 = null;
        int i3 = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i3 = zzb.zzg(parcel, zzaX);
                    break;
                case 2:
                    str3 = zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    i2 = zzb.zzg(parcel, zzaX);
                    break;
                case 4:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 5:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 6:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 7:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzm(i3, str3, i2, str2, str, i, z);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzm[] zzem(int i) {
        return new zzm[i];
    }
}
