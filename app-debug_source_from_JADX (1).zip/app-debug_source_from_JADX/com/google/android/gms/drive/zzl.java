package com.google.android.gms.drive;

import com.google.android.gms.drive.ExecutionOptions.Builder;

public class zzl extends ExecutionOptions {
    private boolean zzaLh;

    public static class zza extends Builder {
        private boolean zzaLh = true;

        public /* synthetic */ ExecutionOptions build() {
            return zzAC();
        }

        public /* synthetic */ Builder setConflictStrategy(int i) {
            return zzej(i);
        }

        public /* synthetic */ Builder setNotifyOnCompletion(boolean z) {
            return zzaz(z);
        }

        public /* synthetic */ Builder setTrackingTag(String str) {
            return zzdG(str);
        }

        public zzl zzAC() {
            zzAx();
            return new zzl(this.zzaLc, this.zzaLd, this.zzaLe, this.zzaLh);
        }

        public zza zzaz(boolean z) {
            super.setNotifyOnCompletion(z);
            return this;
        }

        public zza zzdG(String str) {
            super.setTrackingTag(str);
            return this;
        }

        public zza zzej(int i) {
            super.setConflictStrategy(i);
            return this;
        }
    }

    private zzl(String str, boolean z, int i, boolean z2) {
        super(str, z, i);
        this.zzaLh = z2;
    }

    public static zzl zzb(ExecutionOptions executionOptions) {
        zza com_google_android_gms_drive_zzl_zza = new zza();
        if (executionOptions != null) {
            com_google_android_gms_drive_zzl_zza.setConflictStrategy(executionOptions.zzAw());
            com_google_android_gms_drive_zzl_zza.setNotifyOnCompletion(executionOptions.zzAv());
            String zzAu = executionOptions.zzAu();
            if (zzAu != null) {
                com_google_android_gms_drive_zzl_zza.setTrackingTag(zzAu);
            }
        }
        return (zzl) com_google_android_gms_drive_zzl_zza.build();
    }

    public boolean zzAB() {
        return this.zzaLh;
    }
}
