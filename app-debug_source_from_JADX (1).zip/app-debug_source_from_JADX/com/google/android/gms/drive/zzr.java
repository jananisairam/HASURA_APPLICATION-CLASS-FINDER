package com.google.android.gms.drive;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzac;

public abstract class zzr extends zza {
    private volatile transient boolean zzaLC = false;

    public void writeToParcel(Parcel parcel, int i) {
        zzac.zzaw(!zzAM());
        this.zzaLC = true;
        zzK(parcel, i);
    }

    public final boolean zzAM() {
        return this.zzaLC;
    }

    protected abstract void zzK(Parcel parcel, int i);
}
