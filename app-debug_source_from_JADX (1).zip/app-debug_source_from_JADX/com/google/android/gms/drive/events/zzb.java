package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;
import java.util.Locale;

public final class zzb extends zza implements DriveEvent {
    public static final Creator<zzb> CREATOR = new zzc();
    final zze zzaLE;
    final int zzaiI;
    final String zzaiu;

    zzb(int i, String str, zze com_google_android_gms_drive_events_zze) {
        this.zzaiI = i;
        this.zzaiu = str;
        this.zzaLE = com_google_android_gms_drive_events_zze;
    }

    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        zzb com_google_android_gms_drive_events_zzb = (zzb) obj;
        return zzaa.equal(this.zzaLE, com_google_android_gms_drive_events_zzb.zzaLE) && zzaa.equal(this.zzaiu, com_google_android_gms_drive_events_zzb.zzaiu);
    }

    public int getType() {
        return 4;
    }

    public int hashCode() {
        return zzaa.hashCode(this.zzaLE, this.zzaiu);
    }

    public String toString() {
        return String.format(Locale.US, "ChangesAvailableEvent [changesAvailableOptions=%s]", new Object[]{this.zzaLE});
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzc.zza(this, parcel, i);
    }
}
