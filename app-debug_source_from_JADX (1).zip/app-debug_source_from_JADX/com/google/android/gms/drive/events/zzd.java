package com.google.android.gms.drive.events;

public interface zzd extends zzh {
    void zza(zzb com_google_android_gms_drive_events_zzb);
}
