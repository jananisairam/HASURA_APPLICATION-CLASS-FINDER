package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzagm;
import java.util.List;

public final class zzr extends zza implements DriveEvent {
    public static final Creator<zzr> CREATOR = new zzs();
    final List<zzagm> zzaMa;
    final int zzaiI;
    final String zzaiu;

    zzr(int i, String str, List<zzagm> list) {
        this.zzaiI = i;
        this.zzaiu = str;
        this.zzaMa = list;
    }

    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        zzr com_google_android_gms_drive_events_zzr = (zzr) obj;
        return zzaa.equal(this.zzaiu, com_google_android_gms_drive_events_zzr.zzaiu) && zzaa.equal(this.zzaMa, com_google_android_gms_drive_events_zzr.zzaMa);
    }

    public int getType() {
        return 7;
    }

    public int hashCode() {
        return zzaa.hashCode(this.zzaiu, this.zzaMa);
    }

    public String toString() {
        return String.format("TransferStateEvent[%s]", new Object[]{TextUtils.join("','", this.zzaMa)});
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzs.zza(this, parcel, i);
    }
}
