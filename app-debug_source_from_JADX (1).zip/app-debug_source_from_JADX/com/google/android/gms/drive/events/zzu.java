package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.drive.DriveSpace;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class zzu extends zza {
    public static final Creator<zzu> CREATOR = new zzv();
    final List<DriveSpace> zzaLH;
    private final Set<DriveSpace> zzaLI;
    final int zzaiI;

    zzu(int i, List<DriveSpace> list) {
        this(i, list, list == null ? null : new HashSet(list));
    }

    private zzu(int i, List<DriveSpace> list, Set<DriveSpace> set) {
        this.zzaiI = i;
        this.zzaLH = list;
        this.zzaLI = set;
    }

    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        return zzaa.equal(this.zzaLI, ((zzu) obj).zzaLI);
    }

    public int hashCode() {
        return zzaa.hashCode(this.zzaLI);
    }

    public String toString() {
        return String.format(Locale.US, "TransferStateOptions[Spaces=%s]", new Object[]{this.zzaLH});
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzv.zza(this, parcel, i);
    }
}
