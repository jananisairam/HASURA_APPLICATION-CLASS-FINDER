package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;

public class zzc implements Creator<zzb> {
    static void zza(zzb com_google_android_gms_drive_events_zzb, Parcel parcel, int i) {
        int zzaZ = com.google.android.gms.common.internal.safeparcel.zzc.zzaZ(parcel);
        com.google.android.gms.common.internal.safeparcel.zzc.zzc(parcel, 1, com_google_android_gms_drive_events_zzb.zzaiI);
        com.google.android.gms.common.internal.safeparcel.zzc.zza(parcel, 2, com_google_android_gms_drive_events_zzb.zzaiu, false);
        com.google.android.gms.common.internal.safeparcel.zzc.zza(parcel, 3, com_google_android_gms_drive_events_zzb.zzaLE, i, false);
        com.google.android.gms.common.internal.safeparcel.zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzbV(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzeq(i);
    }

    public zzb zzbV(Parcel parcel) {
        zze com_google_android_gms_drive_events_zze = null;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 2:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    com_google_android_gms_drive_events_zze = (zze) zzb.zza(parcel, zzaX, zze.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzb(i, str, com_google_android_gms_drive_events_zze);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzb[] zzeq(int i) {
        return new zzb[i];
    }
}
