package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.drive.DriveId;

public class zza implements Creator<ChangeEvent> {
    static void zza(ChangeEvent changeEvent, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, changeEvent.zzaiI);
        zzc.zza(parcel, 2, changeEvent.zzaKG, i, false);
        zzc.zzc(parcel, 3, changeEvent.zzaLD);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzbU(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzep(i);
    }

    public ChangeEvent zzbU(Parcel parcel) {
        int i = 0;
        int zzaY = zzb.zzaY(parcel);
        DriveId driveId = null;
        int i2 = 0;
        while (parcel.dataPosition() < zzaY) {
            DriveId driveId2;
            int zzg;
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    int i3 = i;
                    driveId2 = driveId;
                    zzg = zzb.zzg(parcel, zzaX);
                    zzaX = i3;
                    break;
                case 2:
                    zzg = i2;
                    DriveId driveId3 = (DriveId) zzb.zza(parcel, zzaX, DriveId.CREATOR);
                    zzaX = i;
                    driveId2 = driveId3;
                    break;
                case 3:
                    zzaX = zzb.zzg(parcel, zzaX);
                    driveId2 = driveId;
                    zzg = i2;
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    zzaX = i;
                    driveId2 = driveId;
                    zzg = i2;
                    break;
            }
            i2 = zzg;
            driveId = driveId2;
            i = zzaX;
        }
        if (parcel.dataPosition() == zzaY) {
            return new ChangeEvent(i2, driveId, i);
        }
        throw new com.google.android.gms.common.internal.safeparcel.zzb.zza("Overread allowed size end=" + zzaY, parcel);
    }

    public ChangeEvent[] zzep(int i) {
        return new ChangeEvent[i];
    }
}
