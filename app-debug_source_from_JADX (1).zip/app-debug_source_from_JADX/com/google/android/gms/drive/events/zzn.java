package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzagm;

public final class zzn extends zza implements DriveEvent {
    public static final Creator<zzn> CREATOR = new zzo();
    final zzagm zzaLY;
    final int zzaiI;

    zzn(int i, zzagm com_google_android_gms_internal_zzagm) {
        this.zzaiI = i;
        this.zzaLY = com_google_android_gms_internal_zzagm;
    }

    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        return zzaa.equal(this.zzaLY, ((zzn) obj).zzaLY);
    }

    public int getType() {
        return 8;
    }

    public int hashCode() {
        return zzaa.hashCode(this.zzaLY);
    }

    public String toString() {
        return String.format("TransferProgressEvent[%s]", new Object[]{this.zzaLY.toString()});
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzo.zza(this, parcel, i);
    }

    public zzagm zzAT() {
        return this.zzaLY;
    }
}
