package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.internal.zzagm;
import java.util.List;

public class zzs implements Creator<zzr> {
    static void zza(zzr com_google_android_gms_drive_events_zzr, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, com_google_android_gms_drive_events_zzr.zzaiI);
        zzc.zza(parcel, 2, com_google_android_gms_drive_events_zzr.zzaiu, false);
        zzc.zzc(parcel, 3, com_google_android_gms_drive_events_zzr.zzaMa, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzcb(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzew(i);
    }

    public zzr zzcb(Parcel parcel) {
        List list = null;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 2:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    list = zzb.zzc(parcel, zzaX, zzagm.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzr(i, str, list);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzr[] zzew(int i) {
        return new zzr[i];
    }
}
