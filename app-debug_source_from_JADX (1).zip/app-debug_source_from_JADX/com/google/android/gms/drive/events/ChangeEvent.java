package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.drive.DriveId;
import java.util.Locale;

public final class ChangeEvent extends zza implements ResourceEvent {
    public static final Creator<ChangeEvent> CREATOR = new zza();
    final DriveId zzaKG;
    final int zzaLD;
    final int zzaiI;

    ChangeEvent(int i, DriveId driveId, int i2) {
        this.zzaiI = i;
        this.zzaKG = driveId;
        this.zzaLD = i2;
    }

    public DriveId getDriveId() {
        return this.zzaKG;
    }

    public int getType() {
        return 1;
    }

    public boolean hasBeenDeleted() {
        return (this.zzaLD & 4) != 0;
    }

    public boolean hasContentChanged() {
        return (this.zzaLD & 2) != 0;
    }

    public boolean hasMetadataChanged() {
        return (this.zzaLD & 1) != 0;
    }

    public String toString() {
        return String.format(Locale.US, "ChangeEvent [id=%s,changeFlags=%x]", new Object[]{this.zzaKG, Integer.valueOf(this.zzaLD)});
    }

    public void writeToParcel(Parcel parcel, int i) {
        zza.zza(this, parcel, i);
    }
}
