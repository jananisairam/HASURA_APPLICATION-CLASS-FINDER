package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.drive.DriveSpace;
import java.util.List;

public class zzf implements Creator<zze> {
    static void zza(zze com_google_android_gms_drive_events_zze, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, com_google_android_gms_drive_events_zze.zzaiI);
        zzc.zzc(parcel, 2, com_google_android_gms_drive_events_zze.zzaLF);
        zzc.zza(parcel, 3, com_google_android_gms_drive_events_zze.zzaLG);
        zzc.zzc(parcel, 4, com_google_android_gms_drive_events_zze.zzaLH, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzbW(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzer(i);
    }

    public zze zzbW(Parcel parcel) {
        boolean z = false;
        int zzaY = zzb.zzaY(parcel);
        List list = null;
        int i = 0;
        int i2 = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i2 = zzb.zzg(parcel, zzaX);
                    break;
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                case 4:
                    list = zzb.zzc(parcel, zzaX, DriveSpace.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zze(i2, i, z, list);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zze[] zzer(int i) {
        return new zze[i];
    }
}
