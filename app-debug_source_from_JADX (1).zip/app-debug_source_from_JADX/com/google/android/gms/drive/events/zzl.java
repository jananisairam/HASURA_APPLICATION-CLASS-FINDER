package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzl implements Creator<zzk> {
    static void zza(zzk com_google_android_gms_drive_events_zzk, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, com_google_android_gms_drive_events_zzk.zzaiI);
        zzc.zza(parcel, 2, com_google_android_gms_drive_events_zzk.zzaBi, i, false);
        zzc.zza(parcel, 3, com_google_android_gms_drive_events_zzk.zzaLW);
        zzc.zzc(parcel, 4, com_google_android_gms_drive_events_zzk.zzaLX);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzbY(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzet(i);
    }

    public zzk zzbY(Parcel parcel) {
        int i = 0;
        int zzaY = zzb.zzaY(parcel);
        DataHolder dataHolder = null;
        boolean z = false;
        int i2 = 0;
        while (parcel.dataPosition() < zzaY) {
            boolean z2;
            DataHolder dataHolder2;
            int zzg;
            int zzaX = zzb.zzaX(parcel);
            int i3;
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i3 = i;
                    z2 = z;
                    dataHolder2 = dataHolder;
                    zzg = zzb.zzg(parcel, zzaX);
                    zzaX = i3;
                    break;
                case 2:
                    zzg = i2;
                    boolean z3 = z;
                    dataHolder2 = (DataHolder) zzb.zza(parcel, zzaX, DataHolder.CREATOR);
                    zzaX = i;
                    z2 = z3;
                    break;
                case 3:
                    dataHolder2 = dataHolder;
                    zzg = i2;
                    i3 = i;
                    z2 = zzb.zzc(parcel, zzaX);
                    zzaX = i3;
                    break;
                case 4:
                    zzaX = zzb.zzg(parcel, zzaX);
                    z2 = z;
                    dataHolder2 = dataHolder;
                    zzg = i2;
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    zzaX = i;
                    z2 = z;
                    dataHolder2 = dataHolder;
                    zzg = i2;
                    break;
            }
            i2 = zzg;
            dataHolder = dataHolder2;
            z = z2;
            i = zzaX;
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzk(i2, dataHolder, z, i);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzk[] zzet(int i) {
        return new zzk[i];
    }
}
