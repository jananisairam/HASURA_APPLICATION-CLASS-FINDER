package com.google.android.gms.drive.events;

public interface ChangeListener extends zzh {
    void onChange(ChangeEvent changeEvent);
}
