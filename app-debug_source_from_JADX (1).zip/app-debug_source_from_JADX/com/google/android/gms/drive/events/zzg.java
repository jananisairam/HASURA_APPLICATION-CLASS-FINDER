package com.google.android.gms.drive.events;

import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.List;

public class zzg implements Creator<CompletionEvent> {
    static void zza(CompletionEvent completionEvent, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, completionEvent.zzaiI);
        zzc.zza(parcel, 2, completionEvent.zzaKG, i, false);
        zzc.zza(parcel, 3, completionEvent.zzaiu, false);
        zzc.zza(parcel, 4, completionEvent.zzaLJ, i, false);
        zzc.zza(parcel, 5, completionEvent.zzaLK, i, false);
        zzc.zza(parcel, 6, completionEvent.zzaLL, i, false);
        zzc.zzb(parcel, 7, completionEvent.zzaLM, false);
        zzc.zzc(parcel, 8, completionEvent.zzJO);
        zzc.zza(parcel, 9, completionEvent.zzaLN, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzbX(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzes(i);
    }

    public CompletionEvent zzbX(Parcel parcel) {
        int i = 0;
        IBinder iBinder = null;
        int zzaY = zzb.zzaY(parcel);
        List list = null;
        MetadataBundle metadataBundle = null;
        ParcelFileDescriptor parcelFileDescriptor = null;
        ParcelFileDescriptor parcelFileDescriptor2 = null;
        String str = null;
        DriveId driveId = null;
        int i2 = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i2 = zzb.zzg(parcel, zzaX);
                    break;
                case 2:
                    driveId = (DriveId) zzb.zza(parcel, zzaX, DriveId.CREATOR);
                    break;
                case 3:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 4:
                    parcelFileDescriptor2 = (ParcelFileDescriptor) zzb.zza(parcel, zzaX, ParcelFileDescriptor.CREATOR);
                    break;
                case 5:
                    parcelFileDescriptor = (ParcelFileDescriptor) zzb.zza(parcel, zzaX, ParcelFileDescriptor.CREATOR);
                    break;
                case 6:
                    metadataBundle = (MetadataBundle) zzb.zza(parcel, zzaX, MetadataBundle.CREATOR);
                    break;
                case 7:
                    list = zzb.zzE(parcel, zzaX);
                    break;
                case 8:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 9:
                    iBinder = zzb.zzr(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new CompletionEvent(i2, driveId, str, parcelFileDescriptor2, parcelFileDescriptor, metadataBundle, list, i, iBinder);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public CompletionEvent[] zzes(int i) {
        return new CompletionEvent[i];
    }
}
