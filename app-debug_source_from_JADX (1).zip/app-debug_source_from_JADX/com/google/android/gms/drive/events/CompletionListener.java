package com.google.android.gms.drive.events;

public interface CompletionListener extends zzh {
    void onCompletion(CompletionEvent completionEvent);
}
