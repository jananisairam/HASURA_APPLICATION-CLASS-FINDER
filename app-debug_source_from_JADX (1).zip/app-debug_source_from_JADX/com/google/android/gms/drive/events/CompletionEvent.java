package com.google.android.gms.drive.events;

import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.common.data.BitmapTeleporter;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.util.zzp;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.zzaic;
import com.google.android.gms.internal.zzaja;
import com.google.android.gms.internal.zzalu;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class CompletionEvent extends zza implements ResourceEvent {
    public static final Creator<CompletionEvent> CREATOR = new zzg();
    public static final int STATUS_CANCELED = 3;
    public static final int STATUS_CONFLICT = 2;
    public static final int STATUS_FAILURE = 1;
    public static final int STATUS_SUCCESS = 0;
    final int zzJO;
    final DriveId zzaKG;
    final ParcelFileDescriptor zzaLJ;
    final ParcelFileDescriptor zzaLK;
    final MetadataBundle zzaLL;
    final List<String> zzaLM;
    final IBinder zzaLN;
    private boolean zzaLO = false;
    private boolean zzaLP = false;
    private boolean zzaLQ = false;
    final int zzaiI;
    final String zzaiu;

    CompletionEvent(int i, DriveId driveId, String str, ParcelFileDescriptor parcelFileDescriptor, ParcelFileDescriptor parcelFileDescriptor2, MetadataBundle metadataBundle, List<String> list, int i2, IBinder iBinder) {
        this.zzaiI = i;
        this.zzaKG = driveId;
        this.zzaiu = str;
        this.zzaLJ = parcelFileDescriptor;
        this.zzaLK = parcelFileDescriptor2;
        this.zzaLL = metadataBundle;
        this.zzaLM = list;
        this.zzJO = i2;
        this.zzaLN = iBinder;
    }

    private void zzAN() {
        if (this.zzaLQ) {
            throw new IllegalStateException("Event has already been dismissed or snoozed.");
        }
    }

    private void zzy(boolean z) {
        zzAN();
        this.zzaLQ = true;
        zzp.zza(this.zzaLJ);
        zzp.zza(this.zzaLK);
        if (this.zzaLL != null && this.zzaLL.zzc(zzalu.zzaPC)) {
            ((BitmapTeleporter) this.zzaLL.zza(zzalu.zzaPC)).release();
        }
        if (this.zzaLN == null) {
            String str = "CompletionEvent";
            String str2 = "No callback on ";
            String valueOf = String.valueOf(z ? "snooze" : "dismiss");
            zzaic.zzG(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
            return;
        }
        try {
            zzaja.zza.zzbO(this.zzaLN).zzy(z);
        } catch (RemoteException e) {
            RemoteException remoteException = e;
            str2 = "CompletionEvent";
            valueOf = z ? "snooze" : "dismiss";
            str = String.valueOf(remoteException);
            zzaic.zzG(str2, new StringBuilder((String.valueOf(valueOf).length() + 21) + String.valueOf(str).length()).append("RemoteException on ").append(valueOf).append(": ").append(str).toString());
        }
    }

    public void dismiss() {
        zzy(false);
    }

    public String getAccountName() {
        zzAN();
        return this.zzaiu;
    }

    public InputStream getBaseContentsInputStream() {
        zzAN();
        if (this.zzaLJ == null) {
            return null;
        }
        if (this.zzaLO) {
            throw new IllegalStateException("getBaseInputStream() can only be called once per CompletionEvent instance.");
        }
        this.zzaLO = true;
        return new FileInputStream(this.zzaLJ.getFileDescriptor());
    }

    public DriveId getDriveId() {
        zzAN();
        return this.zzaKG;
    }

    public InputStream getModifiedContentsInputStream() {
        zzAN();
        if (this.zzaLK == null) {
            return null;
        }
        if (this.zzaLP) {
            throw new IllegalStateException("getModifiedInputStream() can only be called once per CompletionEvent instance.");
        }
        this.zzaLP = true;
        return new FileInputStream(this.zzaLK.getFileDescriptor());
    }

    public MetadataChangeSet getModifiedMetadataChangeSet() {
        zzAN();
        return this.zzaLL != null ? new MetadataChangeSet(this.zzaLL) : null;
    }

    public int getStatus() {
        zzAN();
        return this.zzJO;
    }

    public List<String> getTrackingTags() {
        zzAN();
        return new ArrayList(this.zzaLM);
    }

    public int getType() {
        return 2;
    }

    public void snooze() {
        zzy(true);
    }

    public String toString() {
        String str;
        if (this.zzaLM == null) {
            str = "<null>";
        } else {
            str = String.valueOf(TextUtils.join("','", this.zzaLM));
            str = new StringBuilder(String.valueOf(str).length() + 2).append("'").append(str).append("'").toString();
        }
        return String.format(Locale.US, "CompletionEvent [id=%s, status=%s, trackingTag=%s]", new Object[]{this.zzaKG, Integer.valueOf(this.zzJO), str});
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzg.zza(this, parcel, i | 1);
    }
}
