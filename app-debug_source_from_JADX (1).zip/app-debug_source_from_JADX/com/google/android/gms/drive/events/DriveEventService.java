package com.google.android.gms.drive.events;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import com.google.android.gms.common.util.zzy;
import com.google.android.gms.internal.zzaic;
import com.google.android.gms.internal.zzajp;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public abstract class DriveEventService extends Service implements ChangeListener, CompletionListener, zzd, zzt {
    public static final String ACTION_HANDLE_EVENT = "com.google.android.gms.drive.events.HANDLE_EVENT";
    private final String mName;
    int zzaEV;
    private CountDownLatch zzaLR;
    zza zzaLS;
    boolean zzaLT;

    final class zza extends Handler {
        final /* synthetic */ DriveEventService zzaLV;

        zza(DriveEventService driveEventService) {
            this.zzaLV = driveEventService;
        }

        private Message zzAP() {
            return obtainMessage(2);
        }

        private Message zzb(zzajp com_google_android_gms_internal_zzajp) {
            return obtainMessage(1, com_google_android_gms_internal_zzajp);
        }

        public void handleMessage(Message message) {
            zzaic.zzE("DriveEventService", "handleMessage message type:" + message.what);
            switch (message.what) {
                case 1:
                    this.zzaLV.zza((zzajp) message.obj);
                    return;
                case 2:
                    getLooper().quit();
                    return;
                default:
                    zzaic.zzF("DriveEventService", "Unexpected message type:" + message.what);
                    return;
            }
        }
    }

    final class zzb extends com.google.android.gms.internal.zzaiz.zza {
        final /* synthetic */ DriveEventService zzaLV;

        zzb(DriveEventService driveEventService) {
            this.zzaLV = driveEventService;
        }

        public void zzc(zzajp com_google_android_gms_internal_zzajp) throws RemoteException {
            synchronized (this.zzaLV) {
                String valueOf = String.valueOf(com_google_android_gms_internal_zzajp);
                zzaic.zzE("DriveEventService", new StringBuilder(String.valueOf(valueOf).length() + 9).append("onEvent: ").append(valueOf).toString());
                this.zzaLV.zzAO();
                if (this.zzaLV.zzaLS != null) {
                    this.zzaLV.zzaLS.sendMessage(this.zzaLV.zzaLS.zzb(com_google_android_gms_internal_zzajp));
                } else {
                    zzaic.zzG("DriveEventService", "Receiving event before initialize is completed.");
                }
            }
        }
    }

    protected DriveEventService() {
        this("DriveEventService");
    }

    protected DriveEventService(String str) {
        this.zzaLT = false;
        this.zzaEV = -1;
        this.mName = str;
    }

    private void zzAO() throws SecurityException {
        int callingUid = getCallingUid();
        if (callingUid != this.zzaEV) {
            if (zzy.zzf(this, callingUid)) {
                this.zzaEV = callingUid;
                return;
            }
            throw new SecurityException("Caller is not GooglePlayServices");
        }
    }

    private void zza(zzajp com_google_android_gms_internal_zzajp) {
        String valueOf;
        DriveEvent zzBi = com_google_android_gms_internal_zzajp.zzBi();
        String valueOf2 = String.valueOf(zzBi);
        zzaic.zzE("DriveEventService", new StringBuilder(String.valueOf(valueOf2).length() + 20).append("handleEventMessage: ").append(valueOf2).toString());
        try {
            switch (zzBi.getType()) {
                case 1:
                    onChange((ChangeEvent) zzBi);
                    return;
                case 2:
                    onCompletion((CompletionEvent) zzBi);
                    return;
                case 4:
                    zza((zzb) zzBi);
                    return;
                case 7:
                    zza((zzr) zzBi);
                    return;
                default:
                    String str = this.mName;
                    valueOf2 = String.valueOf(zzBi);
                    zzaic.zzF(str, new StringBuilder(String.valueOf(valueOf2).length() + 17).append("Unhandled event: ").append(valueOf2).toString());
                    return;
            }
        } catch (Throwable e) {
            valueOf2 = this.mName;
            valueOf = String.valueOf(zzBi);
            zzaic.zza(valueOf2, e, new StringBuilder(String.valueOf(valueOf).length() + 22).append("Error handling event: ").append(valueOf).toString());
        }
        valueOf2 = this.mName;
        valueOf = String.valueOf(zzBi);
        zzaic.zza(valueOf2, e, new StringBuilder(String.valueOf(valueOf).length() + 22).append("Error handling event: ").append(valueOf).toString());
    }

    protected int getCallingUid() {
        return Binder.getCallingUid();
    }

    public final synchronized IBinder onBind(Intent intent) {
        IBinder asBinder;
        if (ACTION_HANDLE_EVENT.equals(intent.getAction())) {
            if (this.zzaLS == null && !this.zzaLT) {
                this.zzaLT = true;
                final CountDownLatch countDownLatch = new CountDownLatch(1);
                this.zzaLR = new CountDownLatch(1);
                new Thread(this) {
                    final /* synthetic */ DriveEventService zzaLV;

                    public void run() {
                        try {
                            Looper.prepare();
                            this.zzaLV.zzaLS = new zza(this.zzaLV);
                            this.zzaLV.zzaLT = false;
                            countDownLatch.countDown();
                            zzaic.zzE("DriveEventService", "Bound and starting loop");
                            Looper.loop();
                            zzaic.zzE("DriveEventService", "Finished loop");
                        } finally {
                            if (this.zzaLV.zzaLR != null) {
                                this.zzaLV.zzaLR.countDown();
                            }
                        }
                    }
                }.start();
                try {
                    if (!countDownLatch.await(5000, TimeUnit.MILLISECONDS)) {
                        zzaic.zzG("DriveEventService", "Failed to synchronously initialize event handler.");
                    }
                } catch (Throwable e) {
                    throw new RuntimeException("Unable to start event handler", e);
                }
            }
            asBinder = new zzb(this).asBinder();
        } else {
            asBinder = null;
        }
        return asBinder;
    }

    public void onChange(ChangeEvent changeEvent) {
        String str = this.mName;
        String valueOf = String.valueOf(changeEvent);
        zzaic.zzF(str, new StringBuilder(String.valueOf(valueOf).length() + 24).append("Unhandled change event: ").append(valueOf).toString());
    }

    public void onCompletion(CompletionEvent completionEvent) {
        String str = this.mName;
        String valueOf = String.valueOf(completionEvent);
        zzaic.zzF(str, new StringBuilder(String.valueOf(valueOf).length() + 28).append("Unhandled completion event: ").append(valueOf).toString());
    }

    public synchronized void onDestroy() {
        zzaic.zzE("DriveEventService", "onDestroy");
        if (this.zzaLS != null) {
            this.zzaLS.sendMessage(this.zzaLS.zzAP());
            this.zzaLS = null;
            try {
                if (!this.zzaLR.await(5000, TimeUnit.MILLISECONDS)) {
                    zzaic.zzF("DriveEventService", "Failed to synchronously quit event handler. Will quit itself");
                }
            } catch (InterruptedException e) {
            }
            this.zzaLR = null;
        }
        super.onDestroy();
    }

    public boolean onUnbind(Intent intent) {
        return true;
    }

    public void zza(zzb com_google_android_gms_drive_events_zzb) {
        String str = this.mName;
        String valueOf = String.valueOf(com_google_android_gms_drive_events_zzb);
        zzaic.zzF(str, new StringBuilder(String.valueOf(valueOf).length() + 35).append("Unhandled changes available event: ").append(valueOf).toString());
    }

    public void zza(zzr com_google_android_gms_drive_events_zzr) {
        String str = this.mName;
        String valueOf = String.valueOf(com_google_android_gms_drive_events_zzr);
        zzaic.zzF(str, new StringBuilder(String.valueOf(valueOf).length() + 32).append("Unhandled transfer state event: ").append(valueOf).toString());
    }
}
