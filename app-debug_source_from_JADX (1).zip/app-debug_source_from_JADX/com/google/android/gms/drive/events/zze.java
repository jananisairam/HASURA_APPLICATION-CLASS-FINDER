package com.google.android.gms.drive.events;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.drive.DriveSpace;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class zze extends zza {
    public static final Creator<zze> CREATOR = new zzf();
    final int zzaLF;
    final boolean zzaLG;
    final List<DriveSpace> zzaLH;
    private final Set<DriveSpace> zzaLI;
    final int zzaiI;

    zze(int i, int i2, boolean z, List<DriveSpace> list) {
        this(i, i2, z, list, list == null ? null : new HashSet(list));
    }

    private zze(int i, int i2, boolean z, List<DriveSpace> list, Set<DriveSpace> set) {
        this.zzaiI = i;
        this.zzaLF = i2;
        this.zzaLG = z;
        this.zzaLH = list;
        this.zzaLI = set;
    }

    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        zze com_google_android_gms_drive_events_zze = (zze) obj;
        return zzaa.equal(this.zzaLI, com_google_android_gms_drive_events_zze.zzaLI) && this.zzaLF == com_google_android_gms_drive_events_zze.zzaLF && this.zzaLG == com_google_android_gms_drive_events_zze.zzaLG;
    }

    public int hashCode() {
        return zzaa.hashCode(this.zzaLI, Integer.valueOf(this.zzaLF), Boolean.valueOf(this.zzaLG));
    }

    public String toString() {
        return String.format(Locale.US, "ChangesAvailableOptions[ChangesSizeLimit=%d, Repeats=%s, Spaces=%s]", new Object[]{Integer.valueOf(this.zzaLF), Boolean.valueOf(this.zzaLG), this.zzaLH});
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzf.zza(this, parcel, i);
    }
}
