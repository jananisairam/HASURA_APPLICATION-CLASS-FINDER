package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;

public class zzm extends zza {
    public static final Creator<zzm> CREATOR = new zzn();
    private String zzaLq;
    private int zzaLr;
    private String zzaLs;
    private String zzaLt;
    private int zzaLu;
    private boolean zzaLv;
    final int zzaiI;

    zzm(int i, String str, int i2, String str2, String str3, int i3, boolean z) {
        this.zzaiI = i;
        this.zzaLq = str;
        this.zzaLr = i2;
        this.zzaLs = str2;
        this.zzaLt = str3;
        this.zzaLu = i3;
        this.zzaLv = z;
    }

    public static boolean zzek(int i) {
        switch (i) {
            case 256:
            case 257:
            case CallbackHandler.MSG_ROUTE_REMOVED /*258*/:
                return true;
            default:
                return false;
        }
    }

    public static boolean zzel(int i) {
        switch (i) {
            case 0:
            case 1:
            case 2:
            case 3:
                return true;
            default:
                return false;
        }
    }

    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        zzm com_google_android_gms_drive_zzm = (zzm) obj;
        return zzaa.equal(this.zzaLq, com_google_android_gms_drive_zzm.zzaLq) && this.zzaLr == com_google_android_gms_drive_zzm.zzaLr && this.zzaLu == com_google_android_gms_drive_zzm.zzaLu && this.zzaLv == com_google_android_gms_drive_zzm.zzaLv;
    }

    public int getRole() {
        return !zzel(this.zzaLu) ? -1 : this.zzaLu;
    }

    public int hashCode() {
        return zzaa.hashCode(this.zzaLq, Integer.valueOf(this.zzaLr), Integer.valueOf(this.zzaLu), Boolean.valueOf(this.zzaLv));
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzn.zza(this, parcel, i);
    }

    public String zzAH() {
        return !zzek(this.zzaLr) ? null : this.zzaLq;
    }

    public int zzAI() {
        return !zzek(this.zzaLr) ? -1 : this.zzaLr;
    }

    public String zzAJ() {
        return this.zzaLs;
    }

    public String zzAK() {
        return this.zzaLt;
    }

    public boolean zzAL() {
        return this.zzaLv;
    }
}
