package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzac;
import java.util.List;

public class zzo extends zza {
    public static final Creator<zzo> CREATOR = new zzp();
    final List<String> zzaLw;
    final List<String> zzaLx;
    final int zzaiI;

    zzo(int i, List<String> list, List<String> list2) {
        this.zzaiI = i;
        this.zzaLw = (List) zzac.zzw(list);
        this.zzaLx = (List) zzac.zzw(list2);
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzp.zza(this, parcel, i);
    }
}
