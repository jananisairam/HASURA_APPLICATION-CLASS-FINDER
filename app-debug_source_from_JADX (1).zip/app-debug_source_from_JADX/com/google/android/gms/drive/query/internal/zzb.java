package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.SearchableMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class zzb<T> extends zza {
    public static final zzc CREATOR = new zzc();
    final zzx zzaQj;
    final MetadataBundle zzaQk;
    final MetadataField<T> zzaQl;
    final int zzaiI;

    zzb(int i, zzx com_google_android_gms_drive_query_internal_zzx, MetadataBundle metadataBundle) {
        this.zzaiI = i;
        this.zzaQj = com_google_android_gms_drive_query_internal_zzx;
        this.zzaQk = metadataBundle;
        this.zzaQl = zzi.zza(metadataBundle);
    }

    public zzb(zzx com_google_android_gms_drive_query_internal_zzx, SearchableMetadataField<T> searchableMetadataField, T t) {
        this(1, com_google_android_gms_drive_query_internal_zzx, MetadataBundle.zzb(searchableMetadataField, t));
    }

    public T getValue() {
        return this.zzaQk.zza(this.zzaQl);
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzc.zza(this, parcel, i);
    }

    public <F> F zza(zzj<F> com_google_android_gms_drive_query_internal_zzj_F) {
        return com_google_android_gms_drive_query_internal_zzj_F.zzb(this.zzaQj, this.zzaQl, getValue());
    }
}
