package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.drive.metadata.SortableMetadataField;
import com.google.android.gms.drive.query.internal.zzf;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SortOrder extends zza {
    public static final Creator<SortOrder> CREATOR = new zzb();
    final List<zzf> zzaQg;
    final boolean zzaQh;
    final int zzaiI;

    public static class Builder {
        private final List<zzf> zzaQg = new ArrayList();
        private boolean zzaQh = false;

        public Builder addSortAscending(SortableMetadataField sortableMetadataField) {
            this.zzaQg.add(new zzf(sortableMetadataField.getName(), true));
            return this;
        }

        public Builder addSortDescending(SortableMetadataField sortableMetadataField) {
            this.zzaQg.add(new zzf(sortableMetadataField.getName(), false));
            return this;
        }

        public SortOrder build() {
            return new SortOrder(this.zzaQg, false);
        }
    }

    SortOrder(int i, List<zzf> list, boolean z) {
        this.zzaiI = i;
        this.zzaQg = list;
        this.zzaQh = z;
    }

    private SortOrder(List<zzf> list, boolean z) {
        this(1, (List) list, z);
    }

    public String toString() {
        return String.format(Locale.US, "SortOrder[%s, %s]", new Object[]{TextUtils.join(",", this.zzaQg), Boolean.valueOf(this.zzaQh)});
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzb.zza(this, parcel, i);
    }
}
