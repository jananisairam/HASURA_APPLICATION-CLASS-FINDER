package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import java.util.ArrayList;
import java.util.List;

public class zzs implements Creator<zzr> {
    static void zza(zzr com_google_android_gms_drive_query_internal_zzr, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 1, com_google_android_gms_drive_query_internal_zzr.zzaQj, i, false);
        zzc.zzc(parcel, 2, com_google_android_gms_drive_query_internal_zzr.zzaQy, false);
        zzc.zzc(parcel, 1000, com_google_android_gms_drive_query_internal_zzr.zzaiI);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzdx(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzfX(i);
    }

    public zzr zzdx(Parcel parcel) {
        List list = null;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        zzx com_google_android_gms_drive_query_internal_zzx = null;
        while (parcel.dataPosition() < zzaY) {
            int i2;
            zzx com_google_android_gms_drive_query_internal_zzx2;
            ArrayList zzc;
            int zzaX = zzb.zzaX(parcel);
            List list2;
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i2 = i;
                    zzx com_google_android_gms_drive_query_internal_zzx3 = (zzx) zzb.zza(parcel, zzaX, zzx.CREATOR);
                    list2 = list;
                    com_google_android_gms_drive_query_internal_zzx2 = com_google_android_gms_drive_query_internal_zzx3;
                    break;
                case 2:
                    zzc = zzb.zzc(parcel, zzaX, FilterHolder.CREATOR);
                    com_google_android_gms_drive_query_internal_zzx2 = com_google_android_gms_drive_query_internal_zzx;
                    i2 = i;
                    break;
                case 1000:
                    List list3 = list;
                    com_google_android_gms_drive_query_internal_zzx2 = com_google_android_gms_drive_query_internal_zzx;
                    i2 = zzb.zzg(parcel, zzaX);
                    list2 = list3;
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    zzc = list;
                    com_google_android_gms_drive_query_internal_zzx2 = com_google_android_gms_drive_query_internal_zzx;
                    i2 = i;
                    break;
            }
            i = i2;
            com_google_android_gms_drive_query_internal_zzx = com_google_android_gms_drive_query_internal_zzx2;
            Object obj = zzc;
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzr(i, com_google_android_gms_drive_query_internal_zzx, list);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzr[] zzfX(int i) {
        return new zzr[i];
    }
}
