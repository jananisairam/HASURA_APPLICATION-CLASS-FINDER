package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.SearchableMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class zzn<T> extends zza {
    public static final zzo CREATOR = new zzo();
    final MetadataBundle zzaQk;
    final MetadataField<T> zzaQl;
    final int zzaiI;

    zzn(int i, MetadataBundle metadataBundle) {
        this.zzaiI = i;
        this.zzaQk = metadataBundle;
        this.zzaQl = zzi.zza(metadataBundle);
    }

    public zzn(SearchableMetadataField<T> searchableMetadataField, T t) {
        this(1, MetadataBundle.zzb(searchableMetadataField, t));
    }

    public T getValue() {
        return this.zzaQk.zza(this.zzaQl);
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzo.zza(this, parcel, i);
    }

    public <F> F zza(zzj<F> com_google_android_gms_drive_query_internal_zzj_F) {
        return com_google_android_gms_drive_query_internal_zzj_F.zze(this.zzaQl, getValue());
    }
}
