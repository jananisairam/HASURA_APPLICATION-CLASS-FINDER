package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class zzc implements Creator<zzb> {
    static void zza(zzb com_google_android_gms_drive_query_internal_zzb, Parcel parcel, int i) {
        int zzaZ = com.google.android.gms.common.internal.safeparcel.zzc.zzaZ(parcel);
        com.google.android.gms.common.internal.safeparcel.zzc.zza(parcel, 1, com_google_android_gms_drive_query_internal_zzb.zzaQj, i, false);
        com.google.android.gms.common.internal.safeparcel.zzc.zza(parcel, 2, com_google_android_gms_drive_query_internal_zzb.zzaQk, i, false);
        com.google.android.gms.common.internal.safeparcel.zzc.zzc(parcel, 1000, com_google_android_gms_drive_query_internal_zzb.zzaiI);
        com.google.android.gms.common.internal.safeparcel.zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzdq(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzfQ(i);
    }

    public zzb zzdq(Parcel parcel) {
        MetadataBundle metadataBundle = null;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        zzx com_google_android_gms_drive_query_internal_zzx = null;
        while (parcel.dataPosition() < zzaY) {
            int i2;
            MetadataBundle metadataBundle2;
            zzx com_google_android_gms_drive_query_internal_zzx2;
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i2 = i;
                    zzx com_google_android_gms_drive_query_internal_zzx3 = (zzx) zzb.zza(parcel, zzaX, zzx.CREATOR);
                    metadataBundle2 = metadataBundle;
                    com_google_android_gms_drive_query_internal_zzx2 = com_google_android_gms_drive_query_internal_zzx3;
                    break;
                case 2:
                    metadataBundle2 = (MetadataBundle) zzb.zza(parcel, zzaX, MetadataBundle.CREATOR);
                    com_google_android_gms_drive_query_internal_zzx2 = com_google_android_gms_drive_query_internal_zzx;
                    i2 = i;
                    break;
                case 1000:
                    MetadataBundle metadataBundle3 = metadataBundle;
                    com_google_android_gms_drive_query_internal_zzx2 = com_google_android_gms_drive_query_internal_zzx;
                    i2 = zzb.zzg(parcel, zzaX);
                    metadataBundle2 = metadataBundle3;
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    metadataBundle2 = metadataBundle;
                    com_google_android_gms_drive_query_internal_zzx2 = com_google_android_gms_drive_query_internal_zzx;
                    i2 = i;
                    break;
            }
            i = i2;
            com_google_android_gms_drive_query_internal_zzx = com_google_android_gms_drive_query_internal_zzx2;
            metadataBundle = metadataBundle2;
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzb(i, com_google_android_gms_drive_query_internal_zzx, metadataBundle);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzb[] zzfQ(int i) {
        return new zzb[i];
    }
}
