package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.drive.metadata.SearchableCollectionMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.drive.metadata.zzb;
import java.util.Collection;
import java.util.Collections;

public class zzp<T> extends zza {
    public static final zzq CREATOR = new zzq();
    final MetadataBundle zzaQk;
    private final zzb<T> zzaQx;
    final int zzaiI;

    zzp(int i, MetadataBundle metadataBundle) {
        this.zzaiI = i;
        this.zzaQk = metadataBundle;
        this.zzaQx = (zzb) zzi.zza(metadataBundle);
    }

    public zzp(SearchableCollectionMetadataField<T> searchableCollectionMetadataField, T t) {
        this(1, MetadataBundle.zzb(searchableCollectionMetadataField, Collections.singleton(t)));
    }

    public T getValue() {
        return ((Collection) this.zzaQk.zza(this.zzaQx)).iterator().next();
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzq.zza(this, parcel, i);
    }

    public <F> F zza(zzj<F> com_google_android_gms_drive_query_internal_zzj_F) {
        return com_google_android_gms_drive_query_internal_zzj_F.zzb(this.zzaQx, getValue());
    }
}
