package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzw implements Creator<zzv> {
    static void zza(zzv com_google_android_gms_drive_query_internal_zzv, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 1, com_google_android_gms_drive_query_internal_zzv.zzaQz, i, false);
        zzc.zzc(parcel, 1000, com_google_android_gms_drive_query_internal_zzv.zzaiI);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzdz(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzfZ(i);
    }

    public zzv zzdz(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        FilterHolder filterHolder = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    filterHolder = (FilterHolder) zzb.zza(parcel, zzaX, FilterHolder.CREATOR);
                    break;
                case 1000:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzv(i, filterHolder);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzv[] zzfZ(int i) {
        return new zzv[i];
    }
}
