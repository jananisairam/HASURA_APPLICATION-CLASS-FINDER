package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.drive.query.Filter;
import java.util.ArrayList;
import java.util.List;

public class zzr extends zza {
    public static final Creator<zzr> CREATOR = new zzs();
    private List<Filter> zzaQd;
    final zzx zzaQj;
    final List<FilterHolder> zzaQy;
    final int zzaiI;

    zzr(int i, zzx com_google_android_gms_drive_query_internal_zzx, List<FilterHolder> list) {
        this.zzaiI = i;
        this.zzaQj = com_google_android_gms_drive_query_internal_zzx;
        this.zzaQy = list;
    }

    public zzr(zzx com_google_android_gms_drive_query_internal_zzx, Filter filter, Filter... filterArr) {
        this.zzaiI = 1;
        this.zzaQj = com_google_android_gms_drive_query_internal_zzx;
        this.zzaQy = new ArrayList(filterArr.length + 1);
        this.zzaQy.add(new FilterHolder(filter));
        this.zzaQd = new ArrayList(filterArr.length + 1);
        this.zzaQd.add(filter);
        for (Filter filter2 : filterArr) {
            this.zzaQy.add(new FilterHolder(filter2));
            this.zzaQd.add(filter2);
        }
    }

    public zzr(zzx com_google_android_gms_drive_query_internal_zzx, Iterable<Filter> iterable) {
        this.zzaiI = 1;
        this.zzaQj = com_google_android_gms_drive_query_internal_zzx;
        this.zzaQd = new ArrayList();
        this.zzaQy = new ArrayList();
        for (Filter filter : iterable) {
            this.zzaQd.add(filter);
            this.zzaQy.add(new FilterHolder(filter));
        }
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzs.zza(this, parcel, i);
    }

    public <T> T zza(zzj<T> com_google_android_gms_drive_query_internal_zzj_T) {
        List arrayList = new ArrayList();
        for (FilterHolder filter : this.zzaQy) {
            arrayList.add(filter.getFilter().zza(com_google_android_gms_drive_query_internal_zzj_T));
        }
        return com_google_android_gms_drive_query_internal_zzj_T.zzb(this.zzaQj, arrayList);
    }
}
