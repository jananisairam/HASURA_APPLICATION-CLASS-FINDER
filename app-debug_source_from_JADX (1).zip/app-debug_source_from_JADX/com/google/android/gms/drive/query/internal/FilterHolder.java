package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.drive.query.Filter;

public class FilterHolder extends zza implements ReflectedParcelable {
    public static final Creator<FilterHolder> CREATOR = new zzh();
    private final Filter zzaLo;
    final zzb<?> zzaQn;
    final zzd zzaQo;
    final zzr zzaQp;
    final zzv zzaQq;
    final zzp<?> zzaQr;
    final zzt zzaQs;
    final zzn zzaQt;
    final zzl zzaQu;
    final zzz zzaQv;
    final int zzaiI;

    FilterHolder(int i, zzb<?> com_google_android_gms_drive_query_internal_zzb_, zzd com_google_android_gms_drive_query_internal_zzd, zzr com_google_android_gms_drive_query_internal_zzr, zzv com_google_android_gms_drive_query_internal_zzv, zzp<?> com_google_android_gms_drive_query_internal_zzp_, zzt com_google_android_gms_drive_query_internal_zzt, zzn<?> com_google_android_gms_drive_query_internal_zzn_, zzl com_google_android_gms_drive_query_internal_zzl, zzz com_google_android_gms_drive_query_internal_zzz) {
        this.zzaiI = i;
        this.zzaQn = com_google_android_gms_drive_query_internal_zzb_;
        this.zzaQo = com_google_android_gms_drive_query_internal_zzd;
        this.zzaQp = com_google_android_gms_drive_query_internal_zzr;
        this.zzaQq = com_google_android_gms_drive_query_internal_zzv;
        this.zzaQr = com_google_android_gms_drive_query_internal_zzp_;
        this.zzaQs = com_google_android_gms_drive_query_internal_zzt;
        this.zzaQt = com_google_android_gms_drive_query_internal_zzn_;
        this.zzaQu = com_google_android_gms_drive_query_internal_zzl;
        this.zzaQv = com_google_android_gms_drive_query_internal_zzz;
        if (this.zzaQn != null) {
            this.zzaLo = this.zzaQn;
        } else if (this.zzaQo != null) {
            this.zzaLo = this.zzaQo;
        } else if (this.zzaQp != null) {
            this.zzaLo = this.zzaQp;
        } else if (this.zzaQq != null) {
            this.zzaLo = this.zzaQq;
        } else if (this.zzaQr != null) {
            this.zzaLo = this.zzaQr;
        } else if (this.zzaQs != null) {
            this.zzaLo = this.zzaQs;
        } else if (this.zzaQt != null) {
            this.zzaLo = this.zzaQt;
        } else if (this.zzaQu != null) {
            this.zzaLo = this.zzaQu;
        } else if (this.zzaQv != null) {
            this.zzaLo = this.zzaQv;
        } else {
            throw new IllegalArgumentException("At least one filter must be set.");
        }
    }

    public FilterHolder(Filter filter) {
        zzac.zzb((Object) filter, (Object) "Null filter.");
        this.zzaiI = 2;
        this.zzaQn = filter instanceof zzb ? (zzb) filter : null;
        this.zzaQo = filter instanceof zzd ? (zzd) filter : null;
        this.zzaQp = filter instanceof zzr ? (zzr) filter : null;
        this.zzaQq = filter instanceof zzv ? (zzv) filter : null;
        this.zzaQr = filter instanceof zzp ? (zzp) filter : null;
        this.zzaQs = filter instanceof zzt ? (zzt) filter : null;
        this.zzaQt = filter instanceof zzn ? (zzn) filter : null;
        this.zzaQu = filter instanceof zzl ? (zzl) filter : null;
        this.zzaQv = filter instanceof zzz ? (zzz) filter : null;
        if (this.zzaQn == null && this.zzaQo == null && this.zzaQp == null && this.zzaQq == null && this.zzaQr == null && this.zzaQs == null && this.zzaQt == null && this.zzaQu == null && this.zzaQv == null) {
            throw new IllegalArgumentException("Invalid filter type.");
        }
        this.zzaLo = filter;
    }

    public Filter getFilter() {
        return this.zzaLo;
    }

    public String toString() {
        return String.format("FilterHolder[%s]", new Object[]{this.zzaLo});
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzh.zza(this, parcel, i);
    }
}
