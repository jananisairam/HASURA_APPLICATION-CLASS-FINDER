package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.SearchableMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class zzd extends zza {
    public static final Creator<zzd> CREATOR = new zze();
    final MetadataBundle zzaQk;
    private final MetadataField<?> zzaQl;
    final int zzaiI;

    zzd(int i, MetadataBundle metadataBundle) {
        this.zzaiI = i;
        this.zzaQk = metadataBundle;
        this.zzaQl = zzi.zza(metadataBundle);
    }

    public zzd(SearchableMetadataField<?> searchableMetadataField) {
        this(1, MetadataBundle.zzb(searchableMetadataField, null));
    }

    public void writeToParcel(Parcel parcel, int i) {
        zze.zza(this, parcel, i);
    }

    public <T> T zza(zzj<T> com_google_android_gms_drive_query_internal_zzj_T) {
        return com_google_android_gms_drive_query_internal_zzj_T.zze(this.zzaQl);
    }
}
