package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class zzq implements Creator<zzp> {
    static void zza(zzp com_google_android_gms_drive_query_internal_zzp, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 1, com_google_android_gms_drive_query_internal_zzp.zzaQk, i, false);
        zzc.zzc(parcel, 1000, com_google_android_gms_drive_query_internal_zzp.zzaiI);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzdw(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzfW(i);
    }

    public zzp zzdw(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        MetadataBundle metadataBundle = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    metadataBundle = (MetadataBundle) zzb.zza(parcel, zzaX, MetadataBundle.CREATOR);
                    break;
                case 1000:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzp(i, metadataBundle);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzp[] zzfW(int i) {
        return new zzp[i];
    }
}
