package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzh implements Creator<FilterHolder> {
    static void zza(FilterHolder filterHolder, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 1, filterHolder.zzaQn, i, false);
        zzc.zza(parcel, 2, filterHolder.zzaQo, i, false);
        zzc.zza(parcel, 3, filterHolder.zzaQp, i, false);
        zzc.zza(parcel, 4, filterHolder.zzaQq, i, false);
        zzc.zza(parcel, 5, filterHolder.zzaQr, i, false);
        zzc.zza(parcel, 6, filterHolder.zzaQs, i, false);
        zzc.zza(parcel, 7, filterHolder.zzaQt, i, false);
        zzc.zzc(parcel, 1000, filterHolder.zzaiI);
        zzc.zza(parcel, 8, filterHolder.zzaQu, i, false);
        zzc.zza(parcel, 9, filterHolder.zzaQv, i, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzdt(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzfT(i);
    }

    public FilterHolder zzdt(Parcel parcel) {
        zzz com_google_android_gms_drive_query_internal_zzz = null;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        zzl com_google_android_gms_drive_query_internal_zzl = null;
        zzn com_google_android_gms_drive_query_internal_zzn = null;
        zzt com_google_android_gms_drive_query_internal_zzt = null;
        zzp com_google_android_gms_drive_query_internal_zzp = null;
        zzv com_google_android_gms_drive_query_internal_zzv = null;
        zzr com_google_android_gms_drive_query_internal_zzr = null;
        zzd com_google_android_gms_drive_query_internal_zzd = null;
        zzb com_google_android_gms_drive_query_internal_zzb = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    com_google_android_gms_drive_query_internal_zzb = (zzb) zzb.zza(parcel, zzaX, zzb.CREATOR);
                    break;
                case 2:
                    com_google_android_gms_drive_query_internal_zzd = (zzd) zzb.zza(parcel, zzaX, zzd.CREATOR);
                    break;
                case 3:
                    com_google_android_gms_drive_query_internal_zzr = (zzr) zzb.zza(parcel, zzaX, zzr.CREATOR);
                    break;
                case 4:
                    com_google_android_gms_drive_query_internal_zzv = (zzv) zzb.zza(parcel, zzaX, zzv.CREATOR);
                    break;
                case 5:
                    com_google_android_gms_drive_query_internal_zzp = (zzp) zzb.zza(parcel, zzaX, zzp.CREATOR);
                    break;
                case 6:
                    com_google_android_gms_drive_query_internal_zzt = (zzt) zzb.zza(parcel, zzaX, zzt.CREATOR);
                    break;
                case 7:
                    com_google_android_gms_drive_query_internal_zzn = (zzn) zzb.zza(parcel, zzaX, zzn.CREATOR);
                    break;
                case 8:
                    com_google_android_gms_drive_query_internal_zzl = (zzl) zzb.zza(parcel, zzaX, zzl.CREATOR);
                    break;
                case 9:
                    com_google_android_gms_drive_query_internal_zzz = (zzz) zzb.zza(parcel, zzaX, zzz.CREATOR);
                    break;
                case 1000:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new FilterHolder(i, com_google_android_gms_drive_query_internal_zzb, com_google_android_gms_drive_query_internal_zzd, com_google_android_gms_drive_query_internal_zzr, com_google_android_gms_drive_query_internal_zzv, com_google_android_gms_drive_query_internal_zzp, com_google_android_gms_drive_query_internal_zzt, com_google_android_gms_drive_query_internal_zzn, com_google_android_gms_drive_query_internal_zzl, com_google_android_gms_drive_query_internal_zzz);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public FilterHolder[] zzfT(int i) {
        return new FilterHolder[i];
    }
}
