package com.google.android.gms.drive.query;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.drive.DriveSpace;
import com.google.android.gms.drive.query.internal.zzr;
import java.util.List;

public class zza implements Creator<Query> {
    static void zza(Query query, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 1, query.zzaPY, i, false);
        zzc.zza(parcel, 3, query.zzaPZ, false);
        zzc.zza(parcel, 4, query.zzaQa, i, false);
        zzc.zzb(parcel, 5, query.zzaQb, false);
        zzc.zza(parcel, 6, query.zzaQc);
        zzc.zzc(parcel, 7, query.zzaLH, false);
        zzc.zza(parcel, 8, query.zzaNO);
        zzc.zzc(parcel, 1000, query.zzaiI);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzdo(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzfO(i);
    }

    public Query zzdo(Parcel parcel) {
        boolean z = false;
        List list = null;
        int zzaY = zzb.zzaY(parcel);
        boolean z2 = false;
        List list2 = null;
        SortOrder sortOrder = null;
        String str = null;
        zzr com_google_android_gms_drive_query_internal_zzr = null;
        int i = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    com_google_android_gms_drive_query_internal_zzr = (zzr) zzb.zza(parcel, zzaX, zzr.CREATOR);
                    break;
                case 3:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 4:
                    sortOrder = (SortOrder) zzb.zza(parcel, zzaX, SortOrder.CREATOR);
                    break;
                case 5:
                    list2 = zzb.zzE(parcel, zzaX);
                    break;
                case 6:
                    z2 = zzb.zzc(parcel, zzaX);
                    break;
                case 7:
                    list = zzb.zzc(parcel, zzaX, DriveSpace.CREATOR);
                    break;
                case 8:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                case 1000:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new Query(i, com_google_android_gms_drive_query_internal_zzr, str, sortOrder, list2, z2, list, z);
        }
        throw new com.google.android.gms.common.internal.safeparcel.zzb.zza("Overread allowed size end=" + zzaY, parcel);
    }

    public Query[] zzfO(int i) {
        return new Query[i];
    }
}
