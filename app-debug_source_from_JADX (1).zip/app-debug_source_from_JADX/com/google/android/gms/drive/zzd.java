package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzd implements Creator<zzc> {
    static void zza(zzc com_google_android_gms_drive_zzc, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, com_google_android_gms_drive_zzc.zzaiI);
        zzc.zza(parcel, 2, com_google_android_gms_drive_zzc.zzaEr, i, false);
        zzc.zzc(parcel, 3, com_google_android_gms_drive_zzc.zzaKE);
        zzc.zzc(parcel, 4, com_google_android_gms_drive_zzc.zzaKF);
        zzc.zza(parcel, 5, com_google_android_gms_drive_zzc.zzaKG, i, false);
        zzc.zza(parcel, 7, com_google_android_gms_drive_zzc.zzaKH);
        zzc.zza(parcel, 8, com_google_android_gms_drive_zzc.zzxB, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzbN(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzec(i);
    }

    public zzc zzbN(Parcel parcel) {
        String str = null;
        boolean z = false;
        int zzaY = zzb.zzaY(parcel);
        DriveId driveId = null;
        int i = 0;
        int i2 = 0;
        ParcelFileDescriptor parcelFileDescriptor = null;
        int i3 = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i3 = zzb.zzg(parcel, zzaX);
                    break;
                case 2:
                    parcelFileDescriptor = (ParcelFileDescriptor) zzb.zza(parcel, zzaX, ParcelFileDescriptor.CREATOR);
                    break;
                case 3:
                    i2 = zzb.zzg(parcel, zzaX);
                    break;
                case 4:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 5:
                    driveId = (DriveId) zzb.zza(parcel, zzaX, DriveId.CREATOR);
                    break;
                case 7:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                case 8:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzc(i3, parcelFileDescriptor, i2, i, driveId, z, str);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzc[] zzec(int i) {
        return new zzc[i];
    }
}
