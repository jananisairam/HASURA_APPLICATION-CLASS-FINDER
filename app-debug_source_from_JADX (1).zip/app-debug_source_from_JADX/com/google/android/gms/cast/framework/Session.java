package com.google.android.gms.cast.framework;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.internal.zzwv;
import com.google.android.gms.internal.zzyz;

public abstract class Session {
    private static final zzyz zzapV = new zzyz("Session");
    private final zzm zzaqD;
    private final zza zzaqE = new zza();

    private class zza extends com.google.android.gms.cast.framework.zzq.zza {
        final /* synthetic */ Session zzaqF;

        private zza(Session session) {
            this.zzaqF = session;
        }

        public void end(boolean z) {
            this.zzaqF.end(z);
        }

        public long getSessionRemainingTimeMs() {
            return this.zzaqF.getSessionRemainingTimeMs();
        }

        public void resume(Bundle bundle) {
            this.zzaqF.resume(bundle);
        }

        public void start(Bundle bundle) {
            this.zzaqF.start(bundle);
        }

        public int zzsB() {
            return 10298208;
        }

        public IObjectWrapper zzsQ() {
            return zzd.zzA(this.zzaqF);
        }
    }

    protected Session(Context context, String str, String str2) {
        this.zzaqD = zzwv.zza(context, str, str2, this.zzaqE);
    }

    protected abstract void end(boolean z);

    public final String getCategory() {
        zzac.zzdj("Must be called from the main thread.");
        try {
            return this.zzaqD.getCategory();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "getCategory", zzm.class.getSimpleName());
            return null;
        }
    }

    public final String getSessionId() {
        zzac.zzdj("Must be called from the main thread.");
        try {
            return this.zzaqD.getSessionId();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "getSessionId", zzm.class.getSimpleName());
            return null;
        }
    }

    public long getSessionRemainingTimeMs() {
        zzac.zzdj("Must be called from the main thread.");
        return 0;
    }

    public boolean isConnected() {
        boolean z = false;
        zzac.zzdj("Must be called from the main thread.");
        try {
            z = this.zzaqD.isConnected();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "isConnected", zzm.class.getSimpleName());
        }
        return z;
    }

    public boolean isConnecting() {
        boolean z = false;
        zzac.zzdj("Must be called from the main thread.");
        try {
            z = this.zzaqD.isConnecting();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "isConnecting", zzm.class.getSimpleName());
        }
        return z;
    }

    public boolean isDisconnected() {
        boolean z = true;
        zzac.zzdj("Must be called from the main thread.");
        try {
            z = this.zzaqD.isDisconnected();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "isDisconnected", zzm.class.getSimpleName());
        }
        return z;
    }

    public boolean isDisconnecting() {
        boolean z = false;
        zzac.zzdj("Must be called from the main thread.");
        try {
            z = this.zzaqD.isDisconnecting();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "isDisconnecting", zzm.class.getSimpleName());
        }
        return z;
    }

    public boolean isResuming() {
        boolean z = false;
        zzac.zzdj("Must be called from the main thread.");
        try {
            z = this.zzaqD.isResuming();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "isResuming", zzm.class.getSimpleName());
        }
        return z;
    }

    public boolean isSuspended() {
        boolean z = false;
        zzac.zzdj("Must be called from the main thread.");
        try {
            z = this.zzaqD.isSuspended();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "isSuspended", zzm.class.getSimpleName());
        }
        return z;
    }

    protected final void notifyFailedToResumeSession(int i) {
        try {
            this.zzaqD.notifyFailedToResumeSession(i);
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "notifyFailedToResumeSession", zzm.class.getSimpleName());
        }
    }

    protected final void notifyFailedToStartSession(int i) {
        try {
            this.zzaqD.notifyFailedToStartSession(i);
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "notifyFailedToStartSession", zzm.class.getSimpleName());
        }
    }

    protected final void notifySessionEnded(int i) {
        try {
            this.zzaqD.notifySessionEnded(i);
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "notifySessionEnded", zzm.class.getSimpleName());
        }
    }

    protected final void notifySessionResumed(boolean z) {
        try {
            this.zzaqD.notifySessionResumed(z);
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "notifySessionResumed", zzm.class.getSimpleName());
        }
    }

    protected final void notifySessionStarted(String str) {
        try {
            this.zzaqD.notifySessionStarted(str);
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "notifySessionStarted", zzm.class.getSimpleName());
        }
    }

    protected final void notifySessionSuspended(int i) {
        try {
            this.zzaqD.notifySessionSuspended(i);
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "notifySessionSuspended", zzm.class.getSimpleName());
        }
    }

    protected abstract void resume(Bundle bundle);

    protected abstract void start(Bundle bundle);

    public final IObjectWrapper zzsN() {
        try {
            return this.zzaqD.zzsN();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "getWrappedObject", zzm.class.getSimpleName());
            return null;
        }
    }
}
