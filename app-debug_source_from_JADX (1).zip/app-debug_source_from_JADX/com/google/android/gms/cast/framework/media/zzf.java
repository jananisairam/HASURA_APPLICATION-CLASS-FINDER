package com.google.android.gms.cast.framework.media;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.TextView;
import com.google.android.gms.C0355R;
import com.google.android.gms.cast.MediaTrack;
import java.util.ArrayList;
import java.util.List;

public class zzf extends ArrayAdapter<MediaTrack> implements OnClickListener {
    private final Context mContext;
    private int zzasW;

    private class zza {
        final TextView zzasX;
        final RadioButton zzasY;

        private zza(zzf com_google_android_gms_cast_framework_media_zzf, TextView textView, RadioButton radioButton) {
            this.zzasX = textView;
            this.zzasY = radioButton;
        }
    }

    public zzf(Context context, List<MediaTrack> list, int i) {
        List arrayList;
        int i2 = C0355R.layout.cast_tracks_chooser_dialog_row_layout;
        if (list == null) {
            arrayList = new ArrayList();
        }
        super(context, i2, arrayList);
        this.zzasW = -1;
        this.mContext = context;
        this.zzasW = i;
    }

    private String zza(MediaTrack mediaTrack, int i) {
        Object name = mediaTrack.getName();
        if (!TextUtils.isEmpty(name)) {
            return name;
        }
        if (mediaTrack.getSubtype() == 2) {
            return this.mContext.getString(C0355R.string.cast_tracks_chooser_dialog_closed_captions);
        }
        if (!TextUtils.isEmpty(mediaTrack.getLanguage())) {
            name = MediaUtils.getTrackLanguage(mediaTrack).getDisplayLanguage();
            if (!TextUtils.isEmpty(name)) {
                return name;
            }
        }
        return this.mContext.getString(C0355R.string.cast_tracks_chooser_dialog_default_track_name, new Object[]{Integer.valueOf(i + 1)});
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        zza com_google_android_gms_cast_framework_media_zzf_zza;
        View view2;
        if (view == null) {
            view = ((LayoutInflater) this.mContext.getSystemService("layout_inflater")).inflate(C0355R.layout.cast_tracks_chooser_dialog_row_layout, viewGroup, false);
            com_google_android_gms_cast_framework_media_zzf_zza = new zza((TextView) view.findViewById(C0355R.id.text), (RadioButton) view.findViewById(C0355R.id.radio));
            view.setTag(com_google_android_gms_cast_framework_media_zzf_zza);
            view2 = view;
        } else {
            com_google_android_gms_cast_framework_media_zzf_zza = (zza) view.getTag();
            view2 = view;
        }
        if (com_google_android_gms_cast_framework_media_zzf_zza == null) {
            return null;
        }
        com_google_android_gms_cast_framework_media_zzf_zza.zzasY.setTag(Integer.valueOf(i));
        com_google_android_gms_cast_framework_media_zzf_zza.zzasY.setChecked(this.zzasW == i);
        view2.setOnClickListener(this);
        com_google_android_gms_cast_framework_media_zzf_zza.zzasX.setText(zza((MediaTrack) getItem(i), i));
        return view2;
    }

    public void onClick(View view) {
        this.zzasW = ((Integer) ((zza) view.getTag()).zzasY.getTag()).intValue();
        notifyDataSetChanged();
    }

    public MediaTrack zztM() {
        return (this.zzasW < 0 || this.zzasW >= getCount()) ? null : (MediaTrack) getItem(this.zzasW);
    }
}
