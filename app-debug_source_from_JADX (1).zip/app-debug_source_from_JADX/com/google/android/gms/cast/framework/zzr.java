package com.google.android.gms.cast.framework;

import android.os.RemoteException;
import android.support.annotation.NonNull;
import com.google.android.gms.cast.framework.zzo.zza;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.zzd;

public class zzr<T extends Session> extends zza {
    private final SessionManagerListener<T> zzaqH;
    private final Class<T> zzaqI;

    public zzr(@NonNull SessionManagerListener<T> sessionManagerListener, @NonNull Class<T> cls) {
        this.zzaqH = sessionManagerListener;
        this.zzaqI = cls;
    }

    public void zzA(@NonNull IObjectWrapper iObjectWrapper) throws RemoteException {
        Session session = (Session) zzd.zzF(iObjectWrapper);
        if (this.zzaqI.isInstance(session)) {
            this.zzaqH.onSessionStarting((Session) this.zzaqI.cast(session));
        }
    }

    public void zzB(@NonNull IObjectWrapper iObjectWrapper) throws RemoteException {
        Session session = (Session) zzd.zzF(iObjectWrapper);
        if (this.zzaqI.isInstance(session)) {
            this.zzaqH.onSessionEnding((Session) this.zzaqI.cast(session));
        }
    }

    public void zza(@NonNull IObjectWrapper iObjectWrapper, boolean z) throws RemoteException {
        Session session = (Session) zzd.zzF(iObjectWrapper);
        if (this.zzaqI.isInstance(session)) {
            this.zzaqH.onSessionResumed((Session) this.zzaqI.cast(session), z);
        }
    }

    public void zzc(@NonNull IObjectWrapper iObjectWrapper, String str) throws RemoteException {
        Session session = (Session) zzd.zzF(iObjectWrapper);
        if (this.zzaqI.isInstance(session)) {
            this.zzaqH.onSessionStarted((Session) this.zzaqI.cast(session), str);
        }
    }

    public void zzd(@NonNull IObjectWrapper iObjectWrapper, String str) throws RemoteException {
        Session session = (Session) zzd.zzF(iObjectWrapper);
        if (this.zzaqI.isInstance(session)) {
            this.zzaqH.onSessionResuming((Session) this.zzaqI.cast(session), str);
        }
    }

    public void zze(@NonNull IObjectWrapper iObjectWrapper, int i) throws RemoteException {
        Session session = (Session) zzd.zzF(iObjectWrapper);
        if (this.zzaqI.isInstance(session)) {
            this.zzaqH.onSessionStartFailed((Session) this.zzaqI.cast(session), i);
        }
    }

    public void zzf(@NonNull IObjectWrapper iObjectWrapper, int i) throws RemoteException {
        Session session = (Session) zzd.zzF(iObjectWrapper);
        if (this.zzaqI.isInstance(session)) {
            this.zzaqH.onSessionEnded((Session) this.zzaqI.cast(session), i);
        }
    }

    public void zzg(@NonNull IObjectWrapper iObjectWrapper, int i) throws RemoteException {
        Session session = (Session) zzd.zzF(iObjectWrapper);
        if (this.zzaqI.isInstance(session)) {
            this.zzaqH.onSessionResumeFailed((Session) this.zzaqI.cast(session), i);
        }
    }

    public void zzh(@NonNull IObjectWrapper iObjectWrapper, int i) throws RemoteException {
        Session session = (Session) zzd.zzF(iObjectWrapper);
        if (this.zzaqI.isInstance(session)) {
            this.zzaqH.onSessionSuspended((Session) this.zzaqI.cast(session), i);
        }
    }

    public int zzsB() {
        return 10298208;
    }

    public IObjectWrapper zzsC() {
        return zzd.zzA(this.zzaqH);
    }
}
