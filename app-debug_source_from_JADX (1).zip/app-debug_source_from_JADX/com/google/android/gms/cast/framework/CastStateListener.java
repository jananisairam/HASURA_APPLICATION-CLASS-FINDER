package com.google.android.gms.cast.framework;

public interface CastStateListener {
    void onCastStateChanged(int i);
}
