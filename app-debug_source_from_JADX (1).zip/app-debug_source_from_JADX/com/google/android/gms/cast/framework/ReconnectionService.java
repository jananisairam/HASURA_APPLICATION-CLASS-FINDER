package com.google.android.gms.cast.framework;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import com.google.android.gms.internal.zzwv;
import com.google.android.gms.internal.zzyz;

public class ReconnectionService extends Service {
    private static final zzyz zzapV = new zzyz("ReconnectionService");
    private zzl zzaqC;

    public IBinder onBind(Intent intent) {
        try {
            return this.zzaqC.onBind(intent);
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "onBind", zzl.class.getSimpleName());
            return null;
        }
    }

    public void onCreate() {
        CastContext sharedInstance = CastContext.getSharedInstance(this);
        this.zzaqC = zzwv.zza(this, sharedInstance.getSessionManager().zzsE(), sharedInstance.zzsD().zzsE());
        try {
            this.zzaqC.onCreate();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "onCreate", zzl.class.getSimpleName());
        }
        super.onCreate();
    }

    public void onDestroy() {
        try {
            this.zzaqC.onDestroy();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "onDestroy", zzl.class.getSimpleName());
        }
        super.onDestroy();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        int i3 = 1;
        try {
            i3 = this.zzaqC.onStartCommand(intent, i, i2);
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "onStartCommand", zzl.class.getSimpleName());
        }
        return i3;
    }
}
