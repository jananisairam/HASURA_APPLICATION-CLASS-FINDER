package com.google.android.gms.cast.framework.media;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.internal.zzyz;

public class CastMediaOptions extends zza {
    public static final Creator<CastMediaOptions> CREATOR = new zza();
    private static final zzyz zzapV = new zzyz("CastMediaOptions");
    private final String zzarL;
    private final String zzarM;
    private final zzb zzarN;
    private final NotificationOptions zzarO;

    public static final class Builder {
        private String zzarL = MediaIntentReceiver.class.getName();
        private String zzarM;
        private NotificationOptions zzarO = new com.google.android.gms.cast.framework.media.NotificationOptions.Builder().build();
        private ImagePicker zzarP;

        public CastMediaOptions build() {
            return new CastMediaOptions(this.zzarL, this.zzarM, this.zzarP == null ? null : this.zzarP.zztq().asBinder(), this.zzarO);
        }

        public Builder setExpandedControllerActivityClassName(String str) {
            this.zzarM = str;
            return this;
        }

        public Builder setImagePicker(ImagePicker imagePicker) {
            this.zzarP = imagePicker;
            return this;
        }

        public Builder setMediaIntentReceiverClassName(String str) {
            this.zzarL = str;
            return this;
        }

        public Builder setNotificationOptions(NotificationOptions notificationOptions) {
            this.zzarO = notificationOptions;
            return this;
        }
    }

    CastMediaOptions(String str, String str2, IBinder iBinder, NotificationOptions notificationOptions) {
        this.zzarL = str;
        this.zzarM = str2;
        this.zzarN = zzb.zza.zzbc(iBinder);
        this.zzarO = notificationOptions;
    }

    public String getExpandedControllerActivityClassName() {
        return this.zzarM;
    }

    public ImagePicker getImagePicker() {
        if (this.zzarN != null) {
            try {
                return (ImagePicker) zzd.zzF(this.zzarN.zztp());
            } catch (Throwable e) {
                zzapV.zzb(e, "Unable to call %s on %s.", "getWrappedClientObject", zzb.class.getSimpleName());
            }
        }
        return null;
    }

    public String getMediaIntentReceiverClassName() {
        return this.zzarL;
    }

    public NotificationOptions getNotificationOptions() {
        return this.zzarO;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zza.zza(this, parcel, i);
    }

    public IBinder zzto() {
        return this.zzarN == null ? null : this.zzarN.asBinder();
    }
}
