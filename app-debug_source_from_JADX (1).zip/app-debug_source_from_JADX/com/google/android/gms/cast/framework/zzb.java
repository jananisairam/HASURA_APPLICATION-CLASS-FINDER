package com.google.android.gms.cast.framework;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.cast.LaunchOptions;
import com.google.android.gms.cast.framework.media.CastMediaOptions;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import java.util.List;

public class zzb implements Creator<CastOptions> {
    static void zza(CastOptions castOptions, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, castOptions.getReceiverApplicationId(), false);
        zzc.zzb(parcel, 3, castOptions.getSupportedNamespaces(), false);
        zzc.zza(parcel, 4, castOptions.getStopReceiverApplicationWhenEndingSession());
        zzc.zza(parcel, 5, castOptions.getLaunchOptions(), i, false);
        zzc.zza(parcel, 6, castOptions.getResumeSavedSession());
        zzc.zza(parcel, 7, castOptions.getCastMediaOptions(), i, false);
        zzc.zza(parcel, 8, castOptions.getEnableReconnectionService());
        zzc.zza(parcel, 9, castOptions.getVolumeDeltaBeforeIceCreamSandwich());
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzaB(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzbX(i);
    }

    public CastOptions zzaB(Parcel parcel) {
        boolean z = false;
        CastMediaOptions castMediaOptions = null;
        int zzaY = com.google.android.gms.common.internal.safeparcel.zzb.zzaY(parcel);
        double d = 0.0d;
        boolean z2 = false;
        LaunchOptions launchOptions = null;
        boolean z3 = false;
        List list = null;
        String str = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = com.google.android.gms.common.internal.safeparcel.zzb.zzaX(parcel);
            switch (com.google.android.gms.common.internal.safeparcel.zzb.zzdc(zzaX)) {
                case 2:
                    str = com.google.android.gms.common.internal.safeparcel.zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    list = com.google.android.gms.common.internal.safeparcel.zzb.zzE(parcel, zzaX);
                    break;
                case 4:
                    z3 = com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, zzaX);
                    break;
                case 5:
                    launchOptions = (LaunchOptions) com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, zzaX, LaunchOptions.CREATOR);
                    break;
                case 6:
                    z2 = com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, zzaX);
                    break;
                case 7:
                    castMediaOptions = (CastMediaOptions) com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, zzaX, CastMediaOptions.CREATOR);
                    break;
                case 8:
                    z = com.google.android.gms.common.internal.safeparcel.zzb.zzc(parcel, zzaX);
                    break;
                case 9:
                    d = com.google.android.gms.common.internal.safeparcel.zzb.zzn(parcel, zzaX);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new CastOptions(str, list, z3, launchOptions, z2, castMediaOptions, z, d);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public CastOptions[] zzbX(int i) {
        return new CastOptions[i];
    }
}
