package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.annotation.ColorInt;
import android.support.v4.graphics.ColorUtils;
import android.util.TypedValue;
import com.google.android.gms.C0355R;
import com.google.android.gms.cast.TextTrackStyle;
import com.google.android.gms.common.util.zzt;
import com.google.android.gms.internal.zzbli;
import com.google.android.gms.internal.zzblj;

class zze extends Drawable {
    private float centerX;
    private float centerY;
    private final Paint zzaqV = new Paint();
    private float zzaqW;
    private final int zzarF;
    private final int zzarG;
    private final int zzarH;
    private float zzarI = 0.0f;
    private float zzarJ = 0.0f;
    private int zzarK = 244;
    private final Rect zzara = new Rect();
    private float zzary = TextTrackStyle.DEFAULT_FONT_SCALE;
    private final Rect zzarz = new Rect();

    public zze(Context context) {
        if (zzt.zzzo()) {
            setColor(zzay(context));
        } else {
            setColor(context.getResources().getColor(C0355R.color.f20xfbd34f47));
        }
        this.zzaqV.setAntiAlias(true);
        this.zzaqV.setStyle(Style.FILL);
        Resources resources = context.getResources();
        this.zzarF = resources.getDimensionPixelSize(C0355R.dimen.cast_libraries_material_featurehighlight_center_threshold);
        this.zzarG = resources.getDimensionPixelSize(C0355R.dimen.f22xd1678993);
        this.zzarH = resources.getDimensionPixelSize(C0355R.dimen.cast_libraries_material_featurehighlight_outer_padding);
    }

    private float zza(float f, float f2, Rect rect) {
        return (float) Math.ceil((double) zzblj.zza(f, f2, (float) rect.left, (float) rect.top, (float) rect.right, (float) rect.bottom));
    }

    @TargetApi(21)
    private static int zzay(Context context) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(16843827, typedValue, true);
        return ColorUtils.setAlphaComponent(typedValue.data, 244);
    }

    public void draw(Canvas canvas) {
        canvas.drawCircle(this.centerX + 0.0f, this.centerY + 0.0f, this.zzaqW * this.zzary, this.zzaqV);
    }

    public int getAlpha() {
        return this.zzaqV.getAlpha();
    }

    public float getCenterX() {
        return this.centerX;
    }

    public float getCenterY() {
        return this.centerY;
    }

    @ColorInt
    public int getColor() {
        return this.zzaqV.getColor();
    }

    public int getOpacity() {
        return -3;
    }

    public void setAlpha(int i) {
        this.zzaqV.setAlpha(i);
        invalidateSelf();
    }

    public void setColor(@ColorInt int i) {
        this.zzaqV.setColor(i);
        this.zzarK = this.zzaqV.getAlpha();
        invalidateSelf();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.zzaqV.setColorFilter(colorFilter);
        invalidateSelf();
    }

    public void zzb(Rect rect, Rect rect2) {
        this.zzara.set(rect);
        this.zzarz.set(rect2);
        float exactCenterX = rect.exactCenterX();
        float exactCenterY = rect.exactCenterY();
        Rect bounds = getBounds();
        if (Math.min(exactCenterY - ((float) bounds.top), ((float) bounds.bottom) - exactCenterY) < ((float) this.zzarF)) {
            this.centerX = exactCenterX;
            this.centerY = exactCenterY;
        } else {
            this.centerX = ((exactCenterX > bounds.exactCenterX() ? 1 : (exactCenterX == bounds.exactCenterX() ? 0 : -1)) <= 0 ? 1 : null) != null ? rect2.exactCenterX() + ((float) this.zzarG) : rect2.exactCenterX() - ((float) this.zzarG);
            this.centerY = rect2.exactCenterY();
        }
        this.zzaqW = ((float) this.zzarH) + Math.max(zza(this.centerX, this.centerY, rect), zza(this.centerX, this.centerY, rect2));
        invalidateSelf();
    }

    public boolean zzd(float f, float f2) {
        return zzblj.zzb(f, f2, this.centerX, this.centerY) < this.zzaqW;
    }

    public Animator zze(float f, float f2) {
        PropertyValuesHolder ofFloat = PropertyValuesHolder.ofFloat("scale", new float[]{0.0f, TextTrackStyle.DEFAULT_FONT_SCALE});
        PropertyValuesHolder ofFloat2 = PropertyValuesHolder.ofFloat("translationX", new float[]{f, 0.0f});
        PropertyValuesHolder ofFloat3 = PropertyValuesHolder.ofFloat("translationY", new float[]{f2, 0.0f});
        PropertyValuesHolder ofInt = PropertyValuesHolder.ofInt("alpha", new int[]{0, this.zzarK});
        Animator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(this, new PropertyValuesHolder[]{ofFloat, ofFloat2, ofFloat3, ofInt});
        ofPropertyValuesHolder.setInterpolator(zzbli.zzUM());
        return ofPropertyValuesHolder.setDuration(350);
    }

    public Animator zzf(float f, float f2) {
        PropertyValuesHolder ofFloat = PropertyValuesHolder.ofFloat("scale", new float[]{0.0f});
        PropertyValuesHolder ofInt = PropertyValuesHolder.ofInt("alpha", new int[]{0});
        PropertyValuesHolder ofFloat2 = PropertyValuesHolder.ofFloat("translationX", new float[]{0.0f, f});
        PropertyValuesHolder ofFloat3 = PropertyValuesHolder.ofFloat("translationY", new float[]{0.0f, f2});
        Animator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(this, new PropertyValuesHolder[]{ofFloat, ofFloat2, ofFloat3, ofInt});
        ofPropertyValuesHolder.setInterpolator(zzbli.zzUN());
        return ofPropertyValuesHolder.setDuration(200);
    }

    public Animator zztm() {
        PropertyValuesHolder ofFloat = PropertyValuesHolder.ofFloat("scale", new float[]{1.125f});
        PropertyValuesHolder ofInt = PropertyValuesHolder.ofInt("alpha", new int[]{0});
        Animator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(this, new PropertyValuesHolder[]{ofFloat, ofInt});
        ofPropertyValuesHolder.setInterpolator(zzbli.zzUN());
        return ofPropertyValuesHolder.setDuration(200);
    }
}
