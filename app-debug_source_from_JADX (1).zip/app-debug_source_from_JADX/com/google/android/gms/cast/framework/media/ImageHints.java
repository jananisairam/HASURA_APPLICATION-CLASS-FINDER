package com.google.android.gms.cast.framework.media;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;

public class ImageHints extends zza {
    public static final Creator<ImageHints> CREATOR = new zzd();
    private final int zzakD;
    private final int zzarQ;
    private final int zzarR;

    public ImageHints(int i, int i2, int i3) {
        this.zzakD = i;
        this.zzarQ = i2;
        this.zzarR = i3;
    }

    public int getHeightInPixels() {
        return this.zzarR;
    }

    public int getType() {
        return this.zzakD;
    }

    public int getWidthInPixels() {
        return this.zzarQ;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzd.zza(this, parcel, i);
    }
}
