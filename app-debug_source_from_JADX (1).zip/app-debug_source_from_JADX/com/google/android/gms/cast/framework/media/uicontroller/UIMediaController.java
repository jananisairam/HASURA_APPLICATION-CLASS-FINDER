package com.google.android.gms.cast.framework.media.uicontroller;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import com.google.android.gms.C0355R;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.Session;
import com.google.android.gms.cast.framework.SessionManager;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.ImageHints;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.android.gms.cast.framework.media.RemoteMediaClient.Listener;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.internal.zzxl;
import com.google.android.gms.internal.zzxm;
import com.google.android.gms.internal.zzxn;
import com.google.android.gms.internal.zzxo;
import com.google.android.gms.internal.zzxq;
import com.google.android.gms.internal.zzxr;
import com.google.android.gms.internal.zzxs;
import com.google.android.gms.internal.zzxt;
import com.google.android.gms.internal.zzxu;
import com.google.android.gms.internal.zzxv;
import com.google.android.gms.internal.zzxw;
import com.google.android.gms.internal.zzxx;
import com.google.android.gms.internal.zzxy;
import com.google.android.gms.internal.zzxz;
import com.google.android.gms.internal.zzya;
import com.google.android.gms.internal.zzyb;
import com.google.android.gms.internal.zzyc;
import com.google.android.gms.internal.zzyd;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class UIMediaController implements SessionManagerListener<CastSession>, Listener {
    private final Activity mActivity;
    private final SessionManager zzapY;
    private RemoteMediaClient zzaqo;
    private final Map<View, List<UIController>> zzatt = new HashMap();
    private final Set<zzyb> zzatu = new HashSet();
    private Listener zzatv;

    class C05141 implements OnSeekBarChangeListener {
        final /* synthetic */ UIMediaController zzatw;

        C05141(UIMediaController uIMediaController) {
            this.zzatw = uIMediaController;
        }

        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            if (z) {
                for (zzyb zzE : this.zzatw.zzatu) {
                    zzE.zzE((long) i);
                }
            }
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
            for (zzyb zzap : this.zzatw.zzatu) {
                zzap.zzap(false);
            }
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            for (zzyb zzap : this.zzatw.zzatu) {
                zzap.zzap(true);
            }
        }
    }

    public UIMediaController(Activity activity) {
        this.mActivity = activity;
        this.zzapY = CastContext.getSharedInstance(activity).getSessionManager();
        this.zzapY.addSessionManagerListener(this, CastSession.class);
        zza(this.zzapY.getCurrentCastSession());
    }

    private void zza(View view, UIController uIController) {
        List list = (List) this.zzatt.get(view);
        if (list == null) {
            list = new ArrayList();
            this.zzatt.put(view, list);
        }
        list.add(uIController);
        if (isActive()) {
            uIController.onSessionConnected(this.zzapY.getCurrentCastSession());
            zztV();
        }
    }

    private void zza(Session session) {
        if (!isActive() && (session instanceof CastSession) && session.isConnected()) {
            CastSession castSession = (CastSession) session;
            this.zzaqo = castSession.getRemoteMediaClient();
            if (this.zzaqo != null) {
                this.zzaqo.addListener(this);
                for (List<UIController> it : this.zzatt.values()) {
                    for (UIController onSessionConnected : it) {
                        onSessionConnected.onSessionConnected(castSession);
                    }
                }
                zztV();
            }
        }
    }

    private void zztU() {
        if (isActive()) {
            for (List<UIController> it : this.zzatt.values()) {
                for (UIController onSessionEnded : it) {
                    onSessionEnded.onSessionEnded();
                }
            }
            this.zzaqo.removeListener(this);
            this.zzaqo = null;
        }
    }

    private void zztV() {
        for (List<UIController> it : this.zzatt.values()) {
            for (UIController onMediaStatusUpdated : it) {
                onMediaStatusUpdated.onMediaStatusUpdated();
            }
        }
    }

    @Deprecated
    public void bindImageViewToImageOfCurrentItem(ImageView imageView, int i, @DrawableRes int i2) {
        zzac.zzdj("Must be called from the main thread.");
        zza(imageView, new zzxn(imageView, this.mActivity, new ImageHints(i, 0, 0), i2, null));
    }

    @Deprecated
    public void bindImageViewToImageOfCurrentItem(ImageView imageView, int i, View view) {
        zzac.zzdj("Must be called from the main thread.");
        zza(imageView, new zzxn(imageView, this.mActivity, new ImageHints(i, 0, 0), 0, view));
    }

    public void bindImageViewToImageOfCurrentItem(ImageView imageView, @NonNull ImageHints imageHints, @DrawableRes int i) {
        zzac.zzdj("Must be called from the main thread.");
        zza(imageView, new zzxn(imageView, this.mActivity, imageHints, i, null));
    }

    public void bindImageViewToImageOfCurrentItem(ImageView imageView, @NonNull ImageHints imageHints, View view) {
        zzac.zzdj("Must be called from the main thread.");
        zza(imageView, new zzxn(imageView, this.mActivity, imageHints, 0, view));
    }

    @Deprecated
    public void bindImageViewToImageOfPreloadedItem(ImageView imageView, int i, @DrawableRes int i2) {
        zzac.zzdj("Must be called from the main thread.");
        zza(imageView, new zzxm(imageView, this.mActivity, new ImageHints(i, 0, 0), i2));
    }

    public void bindImageViewToImageOfPreloadedItem(ImageView imageView, @NonNull ImageHints imageHints, @DrawableRes int i) {
        zzac.zzdj("Must be called from the main thread.");
        zza(imageView, new zzxm(imageView, this.mActivity, imageHints, i));
    }

    public void bindImageViewToMuteToggle(ImageView imageView) {
        zzac.zzdj("Must be called from the main thread.");
        zza(imageView, new zzxt(imageView, this.mActivity));
    }

    public void bindImageViewToPlayPauseToggle(@NonNull ImageView imageView, @NonNull Drawable drawable, @NonNull Drawable drawable2, Drawable drawable3, View view, boolean z) {
        zzac.zzdj("Must be called from the main thread.");
        zza(imageView, new zzxu(imageView, this.mActivity, drawable, drawable2, drawable3, view, z));
    }

    public void bindProgressBar(ProgressBar progressBar) {
        bindProgressBar(progressBar, 1000);
    }

    public void bindProgressBar(ProgressBar progressBar, long j) {
        zzac.zzdj("Must be called from the main thread.");
        zza(progressBar, new zzxv(progressBar, j));
    }

    public void bindSeekBar(SeekBar seekBar) {
        bindSeekBar(seekBar, 1000);
    }

    public void bindSeekBar(SeekBar seekBar, long j) {
        zzac.zzdj("Must be called from the main thread.");
        zza(seekBar, new zzxw(seekBar, j, new C05141(this)));
    }

    public void bindTextViewToMetadataOfCurrentItem(TextView textView, String str) {
        zzac.zzdj("Must be called from the main thread.");
        bindTextViewToMetadataOfCurrentItem(textView, Collections.singletonList(str));
    }

    public void bindTextViewToMetadataOfCurrentItem(TextView textView, List<String> list) {
        zzac.zzdj("Must be called from the main thread.");
        zza(textView, new zzxs(textView, list));
    }

    public void bindTextViewToMetadataOfPreloadedItem(TextView textView, String str) {
        zzac.zzdj("Must be called from the main thread.");
        bindTextViewToMetadataOfPreloadedItem(textView, Collections.singletonList(str));
    }

    public void bindTextViewToMetadataOfPreloadedItem(TextView textView, List<String> list) {
        zzac.zzdj("Must be called from the main thread.");
        zza(textView, new zzxr(textView, list));
    }

    public void bindTextViewToStreamDuration(TextView textView) {
        zzac.zzdj("Must be called from the main thread.");
        zza(textView, new zzya(textView, this.mActivity.getString(C0355R.string.cast_invalid_stream_duration_text), null));
    }

    public void bindTextViewToStreamDuration(TextView textView, View view) {
        zzac.zzdj("Must be called from the main thread.");
        zza(textView, new zzya(textView, this.mActivity.getString(C0355R.string.cast_invalid_stream_duration_text), view));
    }

    public void bindTextViewToStreamPosition(TextView textView, boolean z) {
        bindTextViewToStreamPosition(textView, z, 1000);
    }

    public void bindTextViewToStreamPosition(TextView textView, boolean z, long j) {
        zzac.zzdj("Must be called from the main thread.");
        UIController com_google_android_gms_internal_zzyb = new zzyb(textView, j, this.mActivity.getString(C0355R.string.cast_invalid_stream_position_text));
        if (z) {
            this.zzatu.add(com_google_android_gms_internal_zzyb);
        }
        zza(textView, com_google_android_gms_internal_zzyb);
    }

    public void bindViewToClosedCaption(View view) {
        zzac.zzdj("Must be called from the main thread.");
        zza(view, new zzxl(view, this.mActivity));
    }

    public void bindViewToForward(View view, long j) {
        zzac.zzdj("Must be called from the main thread.");
        zza(view, new zzxx(view, j));
    }

    public void bindViewToLaunchExpandedController(View view) {
        zzac.zzdj("Must be called from the main thread.");
        zza(view, new zzxo(view, this.mActivity));
    }

    public void bindViewToLoadingIndicator(View view) {
        zzac.zzdj("Must be called from the main thread.");
        zza(view, new zzxq(view));
    }

    public void bindViewToRewind(View view, long j) {
        zzac.zzdj("Must be called from the main thread.");
        bindViewToForward(view, -j);
    }

    public void bindViewToSkipNext(View view, int i) {
        zzac.zzdj("Must be called from the main thread.");
        zza(view, new zzxy(view, i));
    }

    public void bindViewToSkipPrev(View view, int i) {
        zzac.zzdj("Must be called from the main thread.");
        zza(view, new zzxz(view, i));
    }

    public void bindViewToUIController(View view, UIController uIController) {
        zzac.zzdj("Must be called from the main thread.");
        zza(view, uIController);
    }

    public void bindViewVisibilityToMediaSession(View view, int i) {
        zzac.zzdj("Must be called from the main thread.");
        zza(view, new zzyd(view, i));
    }

    public void bindViewVisibilityToPreloadingEvent(View view, int i) {
        zzac.zzdj("Must be called from the main thread.");
        zza(view, new zzyc(view, i));
    }

    public void dispose() {
        zzac.zzdj("Must be called from the main thread.");
        zztU();
        this.zzatt.clear();
        this.zzapY.removeSessionManagerListener(this, CastSession.class);
        this.zzatv = null;
    }

    public RemoteMediaClient getRemoteMediaClient() {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzaqo;
    }

    public boolean isActive() {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzaqo != null;
    }

    public void onAdBreakStatusUpdated() {
        zztV();
        if (this.zzatv != null) {
            this.zzatv.onAdBreakStatusUpdated();
        }
    }

    public void onMetadataUpdated() {
        zztV();
        if (this.zzatv != null) {
            this.zzatv.onMetadataUpdated();
        }
    }

    public void onPreloadStatusUpdated() {
        zztV();
        if (this.zzatv != null) {
            this.zzatv.onPreloadStatusUpdated();
        }
    }

    public void onQueueStatusUpdated() {
        zztV();
        if (this.zzatv != null) {
            this.zzatv.onQueueStatusUpdated();
        }
    }

    public void onSendingRemoteMediaRequest() {
        for (List<UIController> it : this.zzatt.values()) {
            for (UIController onSendingRemoteMediaRequest : it) {
                onSendingRemoteMediaRequest.onSendingRemoteMediaRequest();
            }
        }
        if (this.zzatv != null) {
            this.zzatv.onSendingRemoteMediaRequest();
        }
    }

    public void onSessionEnded(CastSession castSession, int i) {
        zztU();
    }

    public void onSessionEnding(CastSession castSession) {
    }

    public void onSessionResumeFailed(CastSession castSession, int i) {
        zztU();
    }

    public void onSessionResumed(CastSession castSession, boolean z) {
        zza((Session) castSession);
    }

    public void onSessionResuming(CastSession castSession, String str) {
    }

    public void onSessionStartFailed(CastSession castSession, int i) {
        zztU();
    }

    public void onSessionStarted(CastSession castSession, String str) {
        zza((Session) castSession);
    }

    public void onSessionStarting(CastSession castSession) {
    }

    public void onSessionSuspended(CastSession castSession, int i) {
    }

    public void onStatusUpdated() {
        zztV();
        if (this.zzatv != null) {
            this.zzatv.onStatusUpdated();
        }
    }

    public void setPostRemoteMediaClientListener(Listener listener) {
        zzac.zzdj("Must be called from the main thread.");
        this.zzatv = listener;
    }
}
