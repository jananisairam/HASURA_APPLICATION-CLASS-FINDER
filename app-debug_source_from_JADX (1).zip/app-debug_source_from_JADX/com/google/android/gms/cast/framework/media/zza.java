package com.google.android.gms.cast.framework.media;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zza implements Creator<CastMediaOptions> {
    static void zza(CastMediaOptions castMediaOptions, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, castMediaOptions.getMediaIntentReceiverClassName(), false);
        zzc.zza(parcel, 3, castMediaOptions.getExpandedControllerActivityClassName(), false);
        zzc.zza(parcel, 4, castMediaOptions.zzto(), false);
        zzc.zza(parcel, 5, castMediaOptions.getNotificationOptions(), i, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzaC(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzcb(i);
    }

    public CastMediaOptions zzaC(Parcel parcel) {
        NotificationOptions notificationOptions = null;
        int zzaY = zzb.zzaY(parcel);
        IBinder iBinder = null;
        String str = null;
        String str2 = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 4:
                    iBinder = zzb.zzr(parcel, zzaX);
                    break;
                case 5:
                    notificationOptions = (NotificationOptions) zzb.zza(parcel, zzaX, NotificationOptions.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new CastMediaOptions(str2, str, iBinder, notificationOptions);
        }
        throw new com.google.android.gms.common.internal.safeparcel.zzb.zza("Overread allowed size end=" + zzaY, parcel);
    }

    public CastMediaOptions[] zzcb(int i) {
        return new CastMediaOptions[i];
    }
}
