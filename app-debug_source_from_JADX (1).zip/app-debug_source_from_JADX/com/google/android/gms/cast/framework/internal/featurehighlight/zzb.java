package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.support.annotation.Nullable;
import android.view.View;

public interface zzb {
    View asView();

    void setText(@Nullable CharSequence charSequence, @Nullable CharSequence charSequence2);
}
