package com.google.android.gms.cast.framework;

import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.zzd;

public class zza extends com.google.android.gms.cast.framework.zze.zza {
    private final AppVisibilityListener zzapU;

    public zza(AppVisibilityListener appVisibilityListener) {
        this.zzapU = appVisibilityListener;
    }

    public void onAppEnteredBackground() {
        this.zzapU.onAppEnteredBackground();
    }

    public void onAppEnteredForeground() {
        this.zzapU.onAppEnteredForeground();
    }

    public int zzsB() {
        return 10298208;
    }

    public IObjectWrapper zzsC() {
        return zzd.zzA(this.zzapU);
    }
}
