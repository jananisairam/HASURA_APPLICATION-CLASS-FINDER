package com.google.android.gms.cast.framework;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.cast.Cast.ApplicationConnectionResult;
import com.google.android.gms.cast.Cast.CastApi;
import com.google.android.gms.cast.Cast.Listener;
import com.google.android.gms.cast.Cast.MessageReceivedCallback;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.cast.LaunchOptions;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.internal.zzwv;
import com.google.android.gms.internal.zzwx;
import com.google.android.gms.internal.zzxj;
import com.google.android.gms.internal.zzyz;
import com.google.android.gms.internal.zzza;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class CastSession extends Session {
    private static final zzyz zzapV = new zzyz("CastSession");
    private final Context zzPB;
    private GoogleApiClient zzanE;
    private final CastOptions zzaqa;
    private final Set<Listener> zzaqj = new HashSet();
    private final zzh zzaqk;
    private final CastApi zzaql;
    private final zzwx zzaqm;
    private final zzxj zzaqn;
    private RemoteMediaClient zzaqo;
    private CastDevice zzaqp;
    private ApplicationConnectionResult zzaqq;

    private class zza implements ResultCallback<ApplicationConnectionResult> {
        String zzaqr;
        final /* synthetic */ CastSession zzaqs;

        zza(CastSession castSession, String str) {
            this.zzaqs = castSession;
            this.zzaqr = str;
        }

        public /* synthetic */ void onResult(@NonNull Result result) {
            zza((ApplicationConnectionResult) result);
        }

        public void zza(@NonNull ApplicationConnectionResult applicationConnectionResult) {
            this.zzaqs.zzaqq = applicationConnectionResult;
            try {
                if (applicationConnectionResult.getStatus().isSuccess()) {
                    CastSession.zzapV.zzb("%s() -> success result", this.zzaqr);
                    this.zzaqs.zzaqo = new RemoteMediaClient(new zzza(null), this.zzaqs.zzaql);
                    try {
                        this.zzaqs.zzaqo.zzd(this.zzaqs.zzanE);
                        this.zzaqs.zzaqo.zztF();
                        this.zzaqs.zzaqo.requestStatus();
                        this.zzaqs.zzaqn.zza(this.zzaqs.zzaqo, this.zzaqs.getCastDevice());
                    } catch (Throwable e) {
                        CastSession.zzapV.zza(e, "Exception when setting GoogleApiClient.", new Object[0]);
                        this.zzaqs.zzaqo = null;
                    }
                    this.zzaqs.zzaqk.zza(applicationConnectionResult.getApplicationMetadata(), applicationConnectionResult.getApplicationStatus(), applicationConnectionResult.getSessionId(), applicationConnectionResult.getWasLaunched());
                    return;
                }
                CastSession.zzapV.zzb("%s() -> failure result", this.zzaqr);
                this.zzaqs.zzaqk.zzbZ(applicationConnectionResult.getStatus().getStatusCode());
            } catch (Throwable e2) {
                CastSession.zzapV.zzb(e2, "Unable to call %s on %s.", "methods", zzh.class.getSimpleName());
            }
        }
    }

    private class zzb extends com.google.android.gms.cast.framework.zzf.zza {
        final /* synthetic */ CastSession zzaqs;

        private zzb(CastSession castSession) {
            this.zzaqs = castSession;
        }

        public void zza(String str, LaunchOptions launchOptions) {
            this.zzaqs.zzaql.launchApplication(this.zzaqs.zzanE, str, launchOptions).setResultCallback(new zza(this.zzaqs, "launchApplication"));
        }

        public void zzbY(int i) {
            this.zzaqs.zzbY(i);
        }

        public void zzcK(String str) {
            this.zzaqs.zzaql.stopApplication(this.zzaqs.zzanE, str);
        }

        public int zzsB() {
            return 10298208;
        }

        public void zzz(String str, String str2) {
            this.zzaqs.zzaql.joinApplication(this.zzaqs.zzanE, str, str2).setResultCallback(new zza(this.zzaqs, "joinApplication"));
        }
    }

    private class zzc extends Listener {
        final /* synthetic */ CastSession zzaqs;

        private zzc(CastSession castSession) {
            this.zzaqs = castSession;
        }

        public void onActiveInputStateChanged(int i) {
            for (Listener onActiveInputStateChanged : new HashSet(this.zzaqs.zzaqj)) {
                onActiveInputStateChanged.onActiveInputStateChanged(i);
            }
        }

        public void onApplicationDisconnected(int i) {
            this.zzaqs.zzbY(i);
            this.zzaqs.notifySessionEnded(i);
            for (Listener onApplicationDisconnected : new HashSet(this.zzaqs.zzaqj)) {
                onApplicationDisconnected.onApplicationDisconnected(i);
            }
        }

        public void onApplicationMetadataChanged(ApplicationMetadata applicationMetadata) {
            for (Listener onApplicationMetadataChanged : new HashSet(this.zzaqs.zzaqj)) {
                onApplicationMetadataChanged.onApplicationMetadataChanged(applicationMetadata);
            }
        }

        public void onApplicationStatusChanged() {
            for (Listener onApplicationStatusChanged : new HashSet(this.zzaqs.zzaqj)) {
                onApplicationStatusChanged.onApplicationStatusChanged();
            }
        }

        public void onStandbyStateChanged(int i) {
            for (Listener onStandbyStateChanged : new HashSet(this.zzaqs.zzaqj)) {
                onStandbyStateChanged.onStandbyStateChanged(i);
            }
        }

        public void onVolumeChanged() {
            for (Listener onVolumeChanged : new HashSet(this.zzaqs.zzaqj)) {
                onVolumeChanged.onVolumeChanged();
            }
        }
    }

    private class zzd implements ConnectionCallbacks, OnConnectionFailedListener {
        final /* synthetic */ CastSession zzaqs;

        private zzd(CastSession castSession) {
            this.zzaqs = castSession;
        }

        public void onConnected(Bundle bundle) {
            try {
                if (this.zzaqs.zzaqo != null) {
                    try {
                        this.zzaqs.zzaqo.zztF();
                        this.zzaqs.zzaqo.requestStatus();
                    } catch (Throwable e) {
                        CastSession.zzapV.zza(e, "Exception when setting GoogleApiClient.", new Object[0]);
                        this.zzaqs.zzaqo = null;
                    }
                }
                this.zzaqs.zzaqk.onConnected(bundle);
            } catch (Throwable e2) {
                CastSession.zzapV.zzb(e2, "Unable to call %s on %s.", "onConnected", zzh.class.getSimpleName());
            }
        }

        public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
            try {
                this.zzaqs.zzaqk.onConnectionFailed(connectionResult);
            } catch (Throwable e) {
                CastSession.zzapV.zzb(e, "Unable to call %s on %s.", "onConnectionFailed", zzh.class.getSimpleName());
            }
        }

        public void onConnectionSuspended(int i) {
            try {
                this.zzaqs.zzaqk.onConnectionSuspended(i);
            } catch (Throwable e) {
                CastSession.zzapV.zzb(e, "Unable to call %s on %s.", "onConnectionSuspended", zzh.class.getSimpleName());
            }
        }
    }

    public CastSession(Context context, String str, String str2, CastOptions castOptions, CastApi castApi, zzwx com_google_android_gms_internal_zzwx, zzxj com_google_android_gms_internal_zzxj) {
        super(context, str, str2);
        this.zzPB = context.getApplicationContext();
        this.zzaqa = castOptions;
        this.zzaql = castApi;
        this.zzaqm = com_google_android_gms_internal_zzwx;
        this.zzaqn = com_google_android_gms_internal_zzxj;
        this.zzaqk = zzwv.zza(context, castOptions, zzsN(), new zzb());
    }

    private void zzbY(int i) {
        this.zzaqn.zzce(i);
        if (this.zzanE != null) {
            this.zzanE.disconnect();
            this.zzanE = null;
        }
        this.zzaqp = null;
        if (this.zzaqo != null) {
            try {
                this.zzaqo.zzd(null);
            } catch (Throwable e) {
                zzapV.zza(e, "Exception when setting GoogleApiClient.", new Object[0]);
            }
            this.zzaqo = null;
        }
        this.zzaqq = null;
    }

    private void zzl(Bundle bundle) {
        this.zzaqp = CastDevice.getFromBundle(bundle);
        if (this.zzaqp != null) {
            if (this.zzanE != null) {
                this.zzanE.disconnect();
                this.zzanE = null;
            }
            zzapV.zzb("Acquiring a connection to Google Play Services for %s", this.zzaqp);
            ConnectionCallbacks com_google_android_gms_cast_framework_CastSession_zzd = new zzd();
            this.zzanE = this.zzaqm.zza(this.zzPB, this.zzaqp, this.zzaqa, new zzc(), com_google_android_gms_cast_framework_CastSession_zzd, com_google_android_gms_cast_framework_CastSession_zzd);
            this.zzanE.connect();
        } else if (isResuming()) {
            notifyFailedToResumeSession(8);
        } else {
            notifyFailedToStartSession(8);
        }
    }

    public void addCastListener(Listener listener) {
        zzac.zzdj("Must be called from the main thread.");
        if (listener != null) {
            this.zzaqj.add(listener);
        }
    }

    protected void end(boolean z) {
        try {
            this.zzaqk.zzb(z, 0);
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "disconnectFromDevice", zzh.class.getSimpleName());
        }
        notifySessionEnded(0);
    }

    public int getActiveInputState() throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzanE != null ? this.zzaql.getActiveInputState(this.zzanE) : -1;
    }

    public ApplicationConnectionResult getApplicationConnectionResult() {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzaqq;
    }

    public ApplicationMetadata getApplicationMetadata() throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzanE != null ? this.zzaql.getApplicationMetadata(this.zzanE) : null;
    }

    public String getApplicationStatus() throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzanE != null ? this.zzaql.getApplicationStatus(this.zzanE) : null;
    }

    public CastDevice getCastDevice() {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzaqp;
    }

    public RemoteMediaClient getRemoteMediaClient() {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzaqo;
    }

    public long getSessionRemainingTimeMs() {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzaqo == null ? 0 : this.zzaqo.getStreamDuration() - this.zzaqo.getApproximateStreamPosition();
    }

    public int getStandbyState() throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzanE != null ? this.zzaql.getStandbyState(this.zzanE) : -1;
    }

    public double getVolume() throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzanE != null ? this.zzaql.getVolume(this.zzanE) : 0.0d;
    }

    public boolean isMute() throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzanE != null ? this.zzaql.isMute(this.zzanE) : false;
    }

    public void removeCastListener(Listener listener) {
        zzac.zzdj("Must be called from the main thread.");
        if (listener != null) {
            this.zzaqj.remove(listener);
        }
    }

    public void removeMessageReceivedCallbacks(String str) throws IOException, IllegalArgumentException {
        zzac.zzdj("Must be called from the main thread.");
        if (this.zzanE != null) {
            this.zzaql.removeMessageReceivedCallbacks(this.zzanE, str);
        }
    }

    public void requestStatus() throws IOException, IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        if (this.zzanE != null) {
            this.zzaql.requestStatus(this.zzanE);
        }
    }

    protected void resume(Bundle bundle) {
        zzl(bundle);
    }

    public PendingResult<Status> sendMessage(String str, String str2) {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzanE != null ? this.zzaql.sendMessage(this.zzanE, str, str2) : null;
    }

    public void setMessageReceivedCallbacks(String str, MessageReceivedCallback messageReceivedCallback) throws IOException, IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        if (this.zzanE != null) {
            this.zzaql.setMessageReceivedCallbacks(this.zzanE, str, messageReceivedCallback);
        }
    }

    public void setMute(boolean z) throws IOException, IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        if (this.zzanE != null) {
            this.zzaql.setMute(this.zzanE, z);
        }
    }

    public void setVolume(double d) throws IOException {
        zzac.zzdj("Must be called from the main thread.");
        if (this.zzanE != null) {
            this.zzaql.setVolume(this.zzanE, d);
        }
    }

    protected void start(Bundle bundle) {
        zzl(bundle);
    }
}
