package com.google.android.gms.cast.framework;

public interface AppVisibilityListener {
    void onAppEnteredBackground();

    void onAppEnteredForeground();
}
