package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.annotation.ColorInt;
import android.support.annotation.Nullable;
import android.support.v4.view.GestureDetectorCompat;
import android.util.AttributeSet;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnLayoutChangeListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import com.google.android.gms.C0355R;
import com.google.android.gms.cast.TextTrackStyle;
import com.google.android.gms.internal.zzbli;
import com.google.android.gms.internal.zzbln;

public final class zza extends ViewGroup {
    private View targetView;
    private final int[] zzaqZ = new int[2];
    private final Rect zzara = new Rect();
    private final Rect zzarb = new Rect();
    private final zze zzarc;
    private final zzc zzard;
    private zzb zzare;
    @Nullable
    private View zzarf;
    @Nullable
    private Animator zzarg;
    private final zzd zzarh;
    private final GestureDetectorCompat zzari;
    @Nullable
    private GestureDetectorCompat zzarj;
    private zza zzark;
    private boolean zzarl;

    class C04931 extends SimpleOnGestureListener {
        final /* synthetic */ zza zzarm;

        C04931(zza com_google_android_gms_cast_framework_internal_featurehighlight_zza) {
            this.zzarm = com_google_android_gms_cast_framework_internal_featurehighlight_zza;
        }

        public boolean onSingleTapUp(MotionEvent motionEvent) {
            float x = motionEvent.getX();
            float y = motionEvent.getY();
            if (!(this.zzarm.zzc(x, y) && this.zzarm.zzarc.zzd(x, y))) {
                this.zzarm.zzark.dismiss();
            }
            return true;
        }
    }

    class C04964 extends AnimatorListenerAdapter {
        final /* synthetic */ zza zzarm;

        C04964(zza com_google_android_gms_cast_framework_internal_featurehighlight_zza) {
            this.zzarm = com_google_android_gms_cast_framework_internal_featurehighlight_zza;
        }

        public void onAnimationEnd(Animator animator) {
            this.zzarm.zzarg = this.zzarm.zztl();
            this.zzarm.zzarg.start();
        }
    }

    public interface zza {
        void dismiss();

        void zztc();
    }

    public zza(Context context) {
        super(context);
        setId(C0355R.id.cast_featurehighlight_view);
        setWillNotDraw(false);
        this.zzard = new zzc(context);
        this.zzard.setCallback(this);
        this.zzarc = new zze(context);
        this.zzarc.setCallback(this);
        this.zzarh = new zzd(this);
        this.zzari = new GestureDetectorCompat(context, new C04931(this));
        this.zzari.setIsLongpressEnabled(false);
        setVisibility(8);
    }

    private void zza(Animator animator) {
        if (this.zzarg != null) {
            this.zzarg.cancel();
        }
        this.zzarg = animator;
        this.zzarg.start();
    }

    private void zza(int[] iArr, View view) {
        getLocationInWindow(iArr);
        int i = iArr[0];
        int i2 = iArr[1];
        view.getLocationInWindow(iArr);
        iArr[0] = iArr[0] - i;
        iArr[1] = iArr[1] - i2;
    }

    private boolean zzc(float f, float f2) {
        return this.zzarb.contains(Math.round(f), Math.round(f2));
    }

    private Animator zzk(@Nullable final Runnable runnable) {
        ObjectAnimator.ofFloat(this.zzare.asView(), "alpha", new float[]{0.0f}).setDuration(200).setInterpolator(zzbli.zzUN());
        Animator zztm = this.zzarc.zztm();
        Animator zztm2 = this.zzard.zztm();
        Animator animatorSet = new AnimatorSet();
        animatorSet.playTogether(new Animator[]{r0, zztm, zztm2});
        animatorSet.addListener(new AnimatorListenerAdapter(this) {
            final /* synthetic */ zza zzarm;

            public void onAnimationEnd(Animator animator) {
                this.zzarm.setVisibility(8);
                this.zzarm.zzarg = null;
                if (runnable != null) {
                    runnable.run();
                }
            }
        });
        return animatorSet;
    }

    private Animator zzl(@Nullable final Runnable runnable) {
        ObjectAnimator.ofFloat(this.zzare.asView(), "alpha", new float[]{0.0f}).setDuration(200).setInterpolator(zzbli.zzUN());
        Animator zzf = this.zzarc.zzf(this.zzara.exactCenterX() - this.zzarc.getCenterX(), this.zzara.exactCenterY() - this.zzarc.getCenterY());
        Animator zztn = this.zzard.zztn();
        Animator animatorSet = new AnimatorSet();
        animatorSet.playTogether(new Animator[]{r0, zzf, zztn});
        animatorSet.addListener(new AnimatorListenerAdapter(this) {
            final /* synthetic */ zza zzarm;

            public void onAnimationEnd(Animator animator) {
                this.zzarm.setVisibility(8);
                this.zzarm.zzarg = null;
                if (runnable != null) {
                    runnable.run();
                }
            }
        });
        return animatorSet;
    }

    private Animator zztk() {
        ObjectAnimator.ofFloat(this.zzare.asView(), "alpha", new float[]{0.0f, TextTrackStyle.DEFAULT_FONT_SCALE}).setDuration(350).setInterpolator(zzbli.zzUM());
        Animator zze = this.zzarc.zze(this.zzara.exactCenterX() - this.zzarc.getCenterX(), this.zzara.exactCenterY() - this.zzarc.getCenterY());
        Animator zztk = this.zzard.zztk();
        Animator animatorSet = new AnimatorSet();
        animatorSet.playTogether(new Animator[]{r0, zze, zztk});
        animatorSet.addListener(new C04964(this));
        return animatorSet;
    }

    private Animator zztl() {
        return this.zzard.zztl();
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof MarginLayoutParams;
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new MarginLayoutParams(-2, -2);
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new MarginLayoutParams(getContext(), attributeSet);
    }

    protected LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return new MarginLayoutParams(layoutParams);
    }

    protected void onDraw(Canvas canvas) {
        canvas.save();
        if (this.zzarf != null) {
            canvas.clipRect(this.zzarb);
        }
        this.zzarc.draw(canvas);
        this.zzard.draw(canvas);
        if (this.targetView != null) {
            if (this.targetView.getParent() != null) {
                Bitmap createBitmap = Bitmap.createBitmap(this.targetView.getWidth(), this.targetView.getHeight(), Config.ARGB_8888);
                this.targetView.draw(new Canvas(createBitmap));
                int color = this.zzarc.getColor();
                int red = Color.red(color);
                int green = Color.green(color);
                int blue = Color.blue(color);
                for (color = 0; color < createBitmap.getHeight(); color++) {
                    for (int i = 0; i < createBitmap.getWidth(); i++) {
                        int pixel = createBitmap.getPixel(i, color);
                        if (Color.alpha(pixel) != 0) {
                            createBitmap.setPixel(i, color, Color.argb(Color.alpha(pixel), red, green, blue));
                        }
                    }
                }
                canvas.drawBitmap(createBitmap, (float) this.zzara.left, (float) this.zzara.top, null);
            }
            canvas.restore();
            return;
        }
        throw new IllegalStateException("Neither target view nor drawable was set");
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (this.targetView == null) {
            throw new IllegalStateException("Target view must be set before layout");
        }
        if (this.targetView.getParent() != null) {
            zza(this.zzaqZ, this.targetView);
        }
        this.zzara.set(this.zzaqZ[0], this.zzaqZ[1], this.zzaqZ[0] + this.targetView.getWidth(), this.zzaqZ[1] + this.targetView.getHeight());
        if (this.zzarf != null) {
            zza(this.zzaqZ, this.zzarf);
            this.zzarb.set(this.zzaqZ[0], this.zzaqZ[1], this.zzaqZ[0] + this.zzarf.getMeasuredWidth(), this.zzaqZ[1] + this.zzarf.getMeasuredHeight());
        } else {
            this.zzarb.set(i, i2, i3, i4);
        }
        this.zzarc.setBounds(this.zzarb);
        this.zzard.setBounds(this.zzarb);
        this.zzarh.zza(this.zzara, this.zzarb);
    }

    protected void onMeasure(int i, int i2) {
        setMeasuredDimension(resolveSize(MeasureSpec.getSize(i), i), resolveSize(MeasureSpec.getSize(i2), i2));
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.zzarl = this.zzara.contains((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        if (this.zzarl) {
            if (this.zzarj != null) {
                this.zzarj.onTouchEvent(motionEvent);
                if (actionMasked == 1) {
                    motionEvent = MotionEvent.obtain(motionEvent);
                    motionEvent.setAction(3);
                }
            }
            if (this.targetView.getParent() != null) {
                this.targetView.onTouchEvent(motionEvent);
            }
        } else {
            this.zzari.onTouchEvent(motionEvent);
        }
        return true;
    }

    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.zzarc || drawable == this.zzard || drawable == null;
    }

    public void zza(final View view, @Nullable View view2, final boolean z, final zza com_google_android_gms_cast_framework_internal_featurehighlight_zza_zza) {
        this.targetView = (View) zzbln.zzw(view);
        this.zzarf = view2;
        this.zzark = (zza) zzbln.zzw(com_google_android_gms_cast_framework_internal_featurehighlight_zza_zza);
        this.zzarj = new GestureDetectorCompat(getContext(), new SimpleOnGestureListener(this) {
            public boolean onSingleTapUp(MotionEvent motionEvent) {
                if (view.getParent() != null) {
                    view.performClick();
                }
                if (z) {
                    com_google_android_gms_cast_framework_internal_featurehighlight_zza_zza.zztc();
                }
                return true;
            }
        });
        this.zzarj.setIsLongpressEnabled(false);
        setVisibility(4);
    }

    public void zza(zzb com_google_android_gms_cast_framework_internal_featurehighlight_zzb) {
        this.zzare = (zzb) zzbln.zzw(com_google_android_gms_cast_framework_internal_featurehighlight_zzb);
        addView(com_google_android_gms_cast_framework_internal_featurehighlight_zzb.asView(), 0);
    }

    public void zzca(@ColorInt int i) {
        this.zzarc.setColor(i);
    }

    public void zzh(@Nullable final Runnable runnable) {
        addOnLayoutChangeListener(new OnLayoutChangeListener(this) {
            final /* synthetic */ zza zzarm;

            public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
                if (runnable != null) {
                    runnable.run();
                }
                this.zzarm.zztf();
                this.zzarm.removeOnLayoutChangeListener(this);
            }
        });
    }

    public void zzi(@Nullable Runnable runnable) {
        zza(zzl(runnable));
    }

    public void zzj(@Nullable Runnable runnable) {
        zza(zzk(runnable));
    }

    public void zztf() {
        if (this.targetView == null) {
            throw new IllegalStateException("Target view must be set before animation");
        }
        setVisibility(0);
        zza(zztk());
    }

    @Nullable
    Drawable zztg() {
        return null;
    }

    View zzth() {
        return this.zzare.asView();
    }

    zze zzti() {
        return this.zzarc;
    }

    zzc zztj() {
        return this.zzard;
    }
}
