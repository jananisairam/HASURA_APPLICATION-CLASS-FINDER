package com.google.android.gms.cast.framework;

import android.content.Context;
import android.os.IBinder;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.dynamic.IObjectWrapper;

public abstract class SessionProvider {
    private final String mCategory;
    private final zza zzaqJ = new zza();
    private final Context zzwi;

    private class zza extends com.google.android.gms.cast.framework.zzp.zza {
        final /* synthetic */ SessionProvider zzaqK;

        private zza(SessionProvider sessionProvider) {
            this.zzaqK = sessionProvider;
        }

        public String getCategory() {
            return this.zzaqK.getCategory();
        }

        public boolean isSessionRecoverable() {
            return this.zzaqK.isSessionRecoverable();
        }

        public IObjectWrapper zzcL(String str) {
            Session createSession = this.zzaqK.createSession(str);
            return createSession == null ? null : createSession.zzsN();
        }
    }

    protected SessionProvider(Context context, String str) {
        this.zzwi = ((Context) zzac.zzw(context)).getApplicationContext();
        this.mCategory = zzac.zzdr(str);
    }

    public abstract Session createSession(String str);

    public final String getCategory() {
        return this.mCategory;
    }

    public final Context getContext() {
        return this.zzwi;
    }

    public abstract boolean isSessionRecoverable();

    public IBinder zzsY() {
        return this.zzaqJ;
    }
}
