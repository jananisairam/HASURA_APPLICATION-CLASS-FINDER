package com.google.android.gms.cast.framework;

public interface DiscoveryManagerListener {
    void onDeviceAvailabilityChanged(boolean z);
}
