package com.google.android.gms.cast.framework;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v7.media.MediaRouteSelector;
import android.support.v7.media.MediaRouter;
import android.view.KeyEvent;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.common.util.zzt;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.zzwv;
import com.google.android.gms.internal.zzww;
import com.google.android.gms.internal.zzxe;
import com.google.android.gms.internal.zzyz;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class CastContext {
    public static final String OPTIONS_PROVIDER_CLASS_NAME_KEY = "com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME";
    private static final zzyz zzapV = new zzyz("CastContext");
    private static CastContext zzapW;
    private final Context zzPB;
    private final zzg zzapX;
    private final SessionManager zzapY;
    private final zzd zzapZ;
    private final CastOptions zzaqa;
    private zzxe zzaqb = new zzxe(MediaRouter.getInstance(this.zzPB));

    private CastContext(Context context, CastOptions castOptions, List<SessionProvider> list) {
        zzj zzsI;
        zzn zzsH;
        SessionManager sessionManager = null;
        this.zzPB = context.getApplicationContext();
        this.zzaqa = castOptions;
        Map hashMap = new HashMap();
        zzww com_google_android_gms_internal_zzww = new zzww(this.zzPB, castOptions, this.zzaqb);
        hashMap.put(com_google_android_gms_internal_zzww.getCategory(), com_google_android_gms_internal_zzww.zzsY());
        if (list != null) {
            for (Object obj : list) {
                zzac.zzb(obj, (Object) "Additional SessionProvider must not be null.");
                String zzh = zzac.zzh(obj.getCategory(), "Category for SessionProvider must not be null or empty string.");
                zzac.zzb(!hashMap.containsKey(zzh), String.format("SessionProvider for category %s already added", new Object[]{zzh}));
                hashMap.put(zzh, obj.zzsY());
            }
        }
        this.zzapX = zzwv.zza(this.zzPB, castOptions, this.zzaqb, hashMap);
        try {
            zzsI = this.zzapX.zzsI();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "getDiscoveryManagerImpl", zzg.class.getSimpleName());
            zzsI = null;
        }
        this.zzapZ = zzsI == null ? null : new zzd(zzsI);
        try {
            zzsH = this.zzapX.zzsH();
        } catch (Throwable e2) {
            zzapV.zzb(e2, "Unable to call %s on %s.", "getSessionManagerImpl", zzg.class.getSimpleName());
            zzsH = null;
        }
        if (zzsH != null) {
            sessionManager = new SessionManager(zzsH);
        }
        this.zzapY = sessionManager;
    }

    public static CastContext getSharedInstance(@NonNull Context context) throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        if (zzapW == null) {
            OptionsProvider zzat = zzat(context.getApplicationContext());
            zzapW = new CastContext(context, zzat.getCastOptions(context.getApplicationContext()), zzat.getAdditionalSessionProviders(context.getApplicationContext()));
        }
        return zzapW;
    }

    private boolean zza(CastSession castSession, double d, boolean z) {
        IllegalStateException e;
        double d2 = 1.0d;
        if (z) {
            try {
                double volume = castSession.getVolume() + d;
                if (volume <= 1.0d) {
                    d2 = volume;
                }
                castSession.setVolume(d2);
            } catch (IOException e2) {
                e = e2;
                zzapV.zzc("Unable to call CastSession.setVolume(double).", e);
                return true;
            } catch (IllegalStateException e3) {
                e = e3;
                zzapV.zzc("Unable to call CastSession.setVolume(double).", e);
                return true;
            }
        }
        return true;
    }

    private static OptionsProvider zzat(Context context) throws IllegalStateException {
        Throwable e;
        try {
            String string = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData.getString(OPTIONS_PROVIDER_CLASS_NAME_KEY);
            if (string != null) {
                return (OptionsProvider) Class.forName(string).newInstance();
            }
            throw new IllegalStateException("The fully qualified name of the implementation of OptionsProvider must be provided as a metadata in the AndroidManifest.xml with key com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME.");
        } catch (NameNotFoundException e2) {
            e = e2;
            throw new IllegalStateException("Failed to initialize CastContext.", e);
        } catch (ClassNotFoundException e3) {
            e = e3;
            throw new IllegalStateException("Failed to initialize CastContext.", e);
        } catch (NullPointerException e4) {
            e = e4;
            throw new IllegalStateException("Failed to initialize CastContext.", e);
        } catch (InstantiationException e5) {
            e = e5;
            throw new IllegalStateException("Failed to initialize CastContext.", e);
        } catch (IllegalAccessException e6) {
            e = e6;
            throw new IllegalStateException("Failed to initialize CastContext.", e);
        }
    }

    public void addAppVisibilityListener(AppVisibilityListener appVisibilityListener) throws IllegalStateException, NullPointerException {
        zzac.zzdj("Must be called from the main thread.");
        zzac.zzw(appVisibilityListener);
        try {
            this.zzapX.zza(new zza(appVisibilityListener));
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "addVisibilityChangeListener", zzg.class.getSimpleName());
        }
    }

    public void addCastStateListener(CastStateListener castStateListener) throws IllegalStateException, NullPointerException {
        zzac.zzdj("Must be called from the main thread.");
        zzac.zzw(castStateListener);
        this.zzapY.addCastStateListener(castStateListener);
    }

    public CastOptions getCastOptions() throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzaqa;
    }

    public int getCastState() {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzapY.getCastState();
    }

    public MediaRouteSelector getMergedSelector() throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        try {
            return MediaRouteSelector.fromBundle(this.zzapX.zzsG());
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "getMergedSelectorAsBundle", zzg.class.getSimpleName());
            return null;
        }
    }

    public SessionManager getSessionManager() throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzapY;
    }

    public boolean isAppVisible() throws IllegalStateException {
        boolean z = false;
        zzac.zzdj("Must be called from the main thread.");
        try {
            z = this.zzapX.isAppVisible();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "isApplicationVisible", zzg.class.getSimpleName());
        }
        return z;
    }

    public boolean onDispatchVolumeKeyEventBeforeJellyBean(KeyEvent keyEvent) {
        zzac.zzdj("Must be called from the main thread.");
        if (zzt.zzzi()) {
            return false;
        }
        CastSession currentCastSession = this.zzapY.getCurrentCastSession();
        if (currentCastSession == null || !currentCastSession.isConnected()) {
            return false;
        }
        double volumeDeltaBeforeIceCreamSandwich = getCastOptions().getVolumeDeltaBeforeIceCreamSandwich();
        boolean z = keyEvent.getAction() == 0;
        switch (keyEvent.getKeyCode()) {
            case 24:
                zza(currentCastSession, volumeDeltaBeforeIceCreamSandwich, z);
                return true;
            case 25:
                zza(currentCastSession, -volumeDeltaBeforeIceCreamSandwich, z);
                return true;
            default:
                return false;
        }
    }

    @Deprecated
    public void registerLifecycleCallbacksBeforeIceCreamSandwich(@NonNull FragmentActivity fragmentActivity, Bundle bundle) {
    }

    public void removeAppVisibilityListener(AppVisibilityListener appVisibilityListener) throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        if (appVisibilityListener != null) {
            try {
                this.zzapX.zzb(new zza(appVisibilityListener));
            } catch (Throwable e) {
                zzapV.zzb(e, "Unable to call %s on %s.", "addVisibilityChangeListener", zzg.class.getSimpleName());
            }
        }
    }

    public void removeCastStateListener(CastStateListener castStateListener) throws IllegalStateException {
        zzac.zzdj("Must be called from the main thread.");
        if (castStateListener != null) {
            this.zzapY.removeCastStateListener(castStateListener);
        }
    }

    public zzd zzsD() {
        zzac.zzdj("Must be called from the main thread.");
        return this.zzapZ;
    }

    public IObjectWrapper zzsE() {
        try {
            return this.zzapX.zzsJ();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "getWrappedThis", zzg.class.getSimpleName());
            return null;
        }
    }
}
