package com.google.android.gms.cast.framework;

import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.internal.zzyz;

public class zzd {
    private static final zzyz zzapV = new zzyz("DiscoveryManager");
    private final zzj zzaqu;

    zzd(zzj com_google_android_gms_cast_framework_zzj) {
        this.zzaqu = com_google_android_gms_cast_framework_zzj;
    }

    public IObjectWrapper zzsE() {
        try {
            return this.zzaqu.zzsJ();
        } catch (Throwable e) {
            zzapV.zzb(e, "Unable to call %s on %s.", "getWrappedThis", zzj.class.getSimpleName());
            return null;
        }
    }
}
