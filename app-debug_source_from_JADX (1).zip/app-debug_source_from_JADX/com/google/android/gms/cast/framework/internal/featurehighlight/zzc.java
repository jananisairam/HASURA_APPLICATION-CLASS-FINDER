package com.google.android.gms.cast.framework.internal.featurehighlight;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.annotation.ColorInt;
import com.google.android.gms.C0355R;
import com.google.android.gms.cast.TextTrackStyle;
import com.google.android.gms.internal.zzblg;
import com.google.android.gms.internal.zzbli;

class zzc extends Drawable {
    private float centerX;
    private float centerY;
    private final Paint zzaqV = new Paint();
    private float zzaqW;
    private final Rect zzara = new Rect();
    private final Paint zzarv = new Paint();
    private final int zzarw;
    private final int zzarx;
    private float zzary = TextTrackStyle.DEFAULT_FONT_SCALE;

    public zzc(Context context) {
        Resources resources = context.getResources();
        this.zzarw = resources.getDimensionPixelSize(C0355R.dimen.cast_libraries_material_featurehighlight_inner_radius);
        this.zzarx = resources.getInteger(C0355R.integer.cast_libraries_material_featurehighlight_pulse_base_alpha);
        this.zzaqV.setAntiAlias(true);
        this.zzaqV.setStyle(Style.FILL);
        this.zzarv.setAntiAlias(true);
        this.zzarv.setStyle(Style.FILL);
        setColor(-1);
    }

    public void draw(Canvas canvas) {
        canvas.drawCircle(this.centerX, this.centerY, this.zzaqW * this.zzary, this.zzaqV);
    }

    public int getOpacity() {
        return -3;
    }

    public void setAlpha(int i) {
        this.zzaqV.setAlpha(i);
        invalidateSelf();
    }

    public void setColor(@ColorInt int i) {
        this.zzaqV.setColor(i);
        this.zzarv.setColor(i);
        invalidateSelf();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.zzaqV.setColorFilter(colorFilter);
        invalidateSelf();
    }

    public void zzc(Rect rect) {
        this.zzara.set(rect);
        this.centerX = this.zzara.exactCenterX();
        this.centerY = this.zzara.exactCenterY();
        this.zzaqW = Math.max((float) this.zzarw, Math.max(((float) this.zzara.width()) / 2.0f, ((float) this.zzara.height()) / 2.0f));
        invalidateSelf();
    }

    public Animator zztk() {
        PropertyValuesHolder ofFloat = PropertyValuesHolder.ofFloat("scale", new float[]{0.0f, TextTrackStyle.DEFAULT_FONT_SCALE});
        PropertyValuesHolder ofFloat2 = PropertyValuesHolder.ofFloat("alpha", new float[]{0.0f, TextTrackStyle.DEFAULT_FONT_SCALE});
        Animator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(this, new PropertyValuesHolder[]{ofFloat, ofFloat2});
        ofPropertyValuesHolder.setInterpolator(zzbli.zzUM());
        return ofPropertyValuesHolder.setDuration(350);
    }

    public Animator zztl() {
        Animator animatorSet = new AnimatorSet();
        Animator duration = ObjectAnimator.ofFloat(this, "scale", new float[]{TextTrackStyle.DEFAULT_FONT_SCALE, 1.1f}).setDuration(500);
        Animator duration2 = ObjectAnimator.ofFloat(this, "scale", new float[]{1.1f, TextTrackStyle.DEFAULT_FONT_SCALE}).setDuration(500);
        PropertyValuesHolder ofFloat = PropertyValuesHolder.ofFloat("pulseScale", new float[]{1.1f, 2.0f});
        PropertyValuesHolder ofFloat2 = PropertyValuesHolder.ofFloat("pulseAlpha", new float[]{TextTrackStyle.DEFAULT_FONT_SCALE, 0.0f});
        Animator duration3 = ObjectAnimator.ofPropertyValuesHolder(this, new PropertyValuesHolder[]{ofFloat, ofFloat2}).setDuration(500);
        animatorSet.play(duration);
        animatorSet.play(duration2).with(duration3).after(duration);
        animatorSet.setInterpolator(zzbli.zzUO());
        animatorSet.setStartDelay(500);
        zzblg.zzc(animatorSet);
        return animatorSet;
    }

    public Animator zztm() {
        return zztn();
    }

    public Animator zztn() {
        PropertyValuesHolder ofFloat = PropertyValuesHolder.ofFloat("scale", new float[]{0.0f});
        PropertyValuesHolder ofFloat2 = PropertyValuesHolder.ofFloat("alpha", new float[]{0.0f});
        PropertyValuesHolder ofFloat3 = PropertyValuesHolder.ofFloat("pulseScale", new float[]{0.0f});
        PropertyValuesHolder ofFloat4 = PropertyValuesHolder.ofFloat("pulseAlpha", new float[]{0.0f});
        Animator ofPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(this, new PropertyValuesHolder[]{ofFloat, ofFloat2, ofFloat3, ofFloat4});
        ofPropertyValuesHolder.setInterpolator(zzbli.zzUN());
        return ofPropertyValuesHolder.setDuration(200);
    }
}
