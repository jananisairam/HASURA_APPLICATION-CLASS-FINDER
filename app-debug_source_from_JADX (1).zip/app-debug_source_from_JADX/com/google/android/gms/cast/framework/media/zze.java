package com.google.android.gms.cast.framework.media;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import java.util.List;

public class zze implements Creator<NotificationOptions> {
    static void zza(NotificationOptions notificationOptions, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzb(parcel, 2, notificationOptions.getActions(), false);
        zzc.zza(parcel, 3, notificationOptions.getCompatActionIndices(), false);
        zzc.zza(parcel, 4, notificationOptions.getSkipStepMs());
        zzc.zza(parcel, 5, notificationOptions.getTargetActivityClassName(), false);
        zzc.zzc(parcel, 6, notificationOptions.getSmallIconDrawableResId());
        zzc.zzc(parcel, 7, notificationOptions.getStopLiveStreamDrawableResId());
        zzc.zzc(parcel, 8, notificationOptions.getPauseDrawableResId());
        zzc.zzc(parcel, 9, notificationOptions.getPlayDrawableResId());
        zzc.zzc(parcel, 10, notificationOptions.getSkipNextDrawableResId());
        zzc.zzc(parcel, 11, notificationOptions.getSkipPrevDrawableResId());
        zzc.zzc(parcel, 12, notificationOptions.getForwardDrawableResId());
        zzc.zzc(parcel, 13, notificationOptions.getForward10DrawableResId());
        zzc.zzc(parcel, 14, notificationOptions.getForward30DrawableResId());
        zzc.zzc(parcel, 15, notificationOptions.getRewindDrawableResId());
        zzc.zzc(parcel, 16, notificationOptions.getRewind10DrawableResId());
        zzc.zzc(parcel, 17, notificationOptions.getRewind30DrawableResId());
        zzc.zzc(parcel, 18, notificationOptions.getDisconnectDrawableResId());
        zzc.zzc(parcel, 19, notificationOptions.zztr());
        zzc.zzc(parcel, 20, notificationOptions.getCastingToDeviceStringResId());
        zzc.zzc(parcel, 21, notificationOptions.getStopLiveStreamTitleResId());
        zzc.zzc(parcel, 22, notificationOptions.zzts());
        zzc.zzc(parcel, 23, notificationOptions.zztt());
        zzc.zzc(parcel, 24, notificationOptions.zztu());
        zzc.zzc(parcel, 25, notificationOptions.zztv());
        zzc.zzc(parcel, 26, notificationOptions.zztw());
        zzc.zzc(parcel, 27, notificationOptions.zztx());
        zzc.zzc(parcel, 28, notificationOptions.zzty());
        zzc.zzc(parcel, 29, notificationOptions.zztz());
        zzc.zzc(parcel, 30, notificationOptions.zztA());
        zzc.zzc(parcel, 31, notificationOptions.zztB());
        zzc.zzc(parcel, 32, notificationOptions.zztC());
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzaE(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzcd(i);
    }

    public NotificationOptions zzaE(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        List list = null;
        int[] iArr = null;
        long j = 0;
        String str = null;
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        int i10 = 0;
        int i11 = 0;
        int i12 = 0;
        int i13 = 0;
        int i14 = 0;
        int i15 = 0;
        int i16 = 0;
        int i17 = 0;
        int i18 = 0;
        int i19 = 0;
        int i20 = 0;
        int i21 = 0;
        int i22 = 0;
        int i23 = 0;
        int i24 = 0;
        int i25 = 0;
        int i26 = 0;
        int i27 = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    list = zzb.zzE(parcel, zzaX);
                    break;
                case 3:
                    iArr = zzb.zzw(parcel, zzaX);
                    break;
                case 4:
                    j = zzb.zzi(parcel, zzaX);
                    break;
                case 5:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 6:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 7:
                    i2 = zzb.zzg(parcel, zzaX);
                    break;
                case 8:
                    i3 = zzb.zzg(parcel, zzaX);
                    break;
                case 9:
                    i4 = zzb.zzg(parcel, zzaX);
                    break;
                case 10:
                    i5 = zzb.zzg(parcel, zzaX);
                    break;
                case 11:
                    i6 = zzb.zzg(parcel, zzaX);
                    break;
                case 12:
                    i7 = zzb.zzg(parcel, zzaX);
                    break;
                case 13:
                    i8 = zzb.zzg(parcel, zzaX);
                    break;
                case 14:
                    i9 = zzb.zzg(parcel, zzaX);
                    break;
                case 15:
                    i10 = zzb.zzg(parcel, zzaX);
                    break;
                case 16:
                    i11 = zzb.zzg(parcel, zzaX);
                    break;
                case 17:
                    i12 = zzb.zzg(parcel, zzaX);
                    break;
                case 18:
                    i13 = zzb.zzg(parcel, zzaX);
                    break;
                case 19:
                    i14 = zzb.zzg(parcel, zzaX);
                    break;
                case 20:
                    i15 = zzb.zzg(parcel, zzaX);
                    break;
                case 21:
                    i16 = zzb.zzg(parcel, zzaX);
                    break;
                case 22:
                    i17 = zzb.zzg(parcel, zzaX);
                    break;
                case 23:
                    i18 = zzb.zzg(parcel, zzaX);
                    break;
                case 24:
                    i19 = zzb.zzg(parcel, zzaX);
                    break;
                case 25:
                    i20 = zzb.zzg(parcel, zzaX);
                    break;
                case 26:
                    i21 = zzb.zzg(parcel, zzaX);
                    break;
                case 27:
                    i22 = zzb.zzg(parcel, zzaX);
                    break;
                case 28:
                    i23 = zzb.zzg(parcel, zzaX);
                    break;
                case 29:
                    i24 = zzb.zzg(parcel, zzaX);
                    break;
                case 30:
                    i25 = zzb.zzg(parcel, zzaX);
                    break;
                case 31:
                    i26 = zzb.zzg(parcel, zzaX);
                    break;
                case 32:
                    i27 = zzb.zzg(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new NotificationOptions(list, iArr, j, str, i, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12, i13, i14, i15, i16, i17, i18, i19, i20, i21, i22, i23, i24, i25, i26, i27);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public NotificationOptions[] zzcd(int i) {
        return new NotificationOptions[i];
    }
}
