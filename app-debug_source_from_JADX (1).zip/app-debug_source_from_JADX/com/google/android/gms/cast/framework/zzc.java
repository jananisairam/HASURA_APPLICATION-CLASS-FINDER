package com.google.android.gms.cast.framework;

import com.google.android.gms.cast.framework.zzi.zza;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.zzd;

public class zzc extends zza {
    private final CastStateListener zzaqt;

    public zzc(CastStateListener castStateListener) {
        this.zzaqt = castStateListener;
    }

    public void onCastStateChanged(int i) {
        this.zzaqt.onCastStateChanged(i);
    }

    public int zzsB() {
        return 10298208;
    }

    public IObjectWrapper zzsC() {
        return zzd.zzA(this.zzaqt);
    }
}
