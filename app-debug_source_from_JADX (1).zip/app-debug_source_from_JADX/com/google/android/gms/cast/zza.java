package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zza implements Creator<AdBreakClipInfo> {
    static void zza(AdBreakClipInfo adBreakClipInfo, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, adBreakClipInfo.getId(), false);
        zzc.zza(parcel, 3, adBreakClipInfo.getTitle(), false);
        zzc.zza(parcel, 4, adBreakClipInfo.getDurationInMs());
        zzc.zza(parcel, 5, adBreakClipInfo.getContentUrl(), false);
        zzc.zza(parcel, 6, adBreakClipInfo.getMimeType(), false);
        zzc.zza(parcel, 7, adBreakClipInfo.getClickThroughUrl(), false);
        zzc.zza(parcel, 8, adBreakClipInfo.zzsf(), false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzan(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzbG(i);
    }

    public AdBreakClipInfo zzan(Parcel parcel) {
        String str = null;
        int zzaY = zzb.zzaY(parcel);
        long j = 0;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    str6 = zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    str5 = zzb.zzq(parcel, zzaX);
                    break;
                case 4:
                    j = zzb.zzi(parcel, zzaX);
                    break;
                case 5:
                    str4 = zzb.zzq(parcel, zzaX);
                    break;
                case 6:
                    str3 = zzb.zzq(parcel, zzaX);
                    break;
                case 7:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 8:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new AdBreakClipInfo(str6, str5, j, str4, str3, str2, str);
        }
        throw new com.google.android.gms.common.internal.safeparcel.zzb.zza("Overread allowed size end=" + zzaY, parcel);
    }

    public AdBreakClipInfo[] zzbG(int i) {
        return new AdBreakClipInfo[i];
    }
}
