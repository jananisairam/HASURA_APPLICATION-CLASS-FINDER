package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import java.util.List;

public class zzl implements Creator<MediaStatus> {
    static void zza(MediaStatus mediaStatus, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, mediaStatus.getMediaInfo(), i, false);
        zzc.zza(parcel, 3, mediaStatus.zzsy());
        zzc.zzc(parcel, 4, mediaStatus.getCurrentItemId());
        zzc.zza(parcel, 5, mediaStatus.getPlaybackRate());
        zzc.zzc(parcel, 6, mediaStatus.getPlayerState());
        zzc.zzc(parcel, 7, mediaStatus.getIdleReason());
        zzc.zza(parcel, 8, mediaStatus.getStreamPosition());
        zzc.zza(parcel, 9, mediaStatus.zzaoM);
        zzc.zza(parcel, 10, mediaStatus.getStreamVolume());
        zzc.zza(parcel, 11, mediaStatus.isMute());
        zzc.zza(parcel, 12, mediaStatus.getActiveTrackIds(), false);
        zzc.zzc(parcel, 13, mediaStatus.getLoadingItemId());
        zzc.zzc(parcel, 14, mediaStatus.getPreloadedItemId());
        zzc.zza(parcel, 15, mediaStatus.zzamN, false);
        zzc.zzc(parcel, 16, mediaStatus.zzaoR);
        zzc.zzc(parcel, 17, mediaStatus.zzaoS, false);
        zzc.zza(parcel, 18, mediaStatus.isPlayingAd());
        zzc.zza(parcel, 19, mediaStatus.getAdBreakStatus(), i, false);
        zzc.zza(parcel, 20, mediaStatus.getVideoInfo(), i, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzax(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzbR(i);
    }

    public MediaStatus zzax(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        MediaInfo mediaInfo = null;
        long j = 0;
        int i = 0;
        double d = 0.0d;
        int i2 = 0;
        int i3 = 0;
        long j2 = 0;
        long j3 = 0;
        double d2 = 0.0d;
        boolean z = false;
        long[] jArr = null;
        int i4 = 0;
        int i5 = 0;
        String str = null;
        int i6 = 0;
        List list = null;
        boolean z2 = false;
        AdBreakStatus adBreakStatus = null;
        VideoInfo videoInfo = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    mediaInfo = (MediaInfo) zzb.zza(parcel, zzaX, MediaInfo.CREATOR);
                    break;
                case 3:
                    j = zzb.zzi(parcel, zzaX);
                    break;
                case 4:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 5:
                    d = zzb.zzn(parcel, zzaX);
                    break;
                case 6:
                    i2 = zzb.zzg(parcel, zzaX);
                    break;
                case 7:
                    i3 = zzb.zzg(parcel, zzaX);
                    break;
                case 8:
                    j2 = zzb.zzi(parcel, zzaX);
                    break;
                case 9:
                    j3 = zzb.zzi(parcel, zzaX);
                    break;
                case 10:
                    d2 = zzb.zzn(parcel, zzaX);
                    break;
                case 11:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                case 12:
                    jArr = zzb.zzx(parcel, zzaX);
                    break;
                case 13:
                    i4 = zzb.zzg(parcel, zzaX);
                    break;
                case 14:
                    i5 = zzb.zzg(parcel, zzaX);
                    break;
                case 15:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 16:
                    i6 = zzb.zzg(parcel, zzaX);
                    break;
                case 17:
                    list = zzb.zzc(parcel, zzaX, MediaQueueItem.CREATOR);
                    break;
                case 18:
                    z2 = zzb.zzc(parcel, zzaX);
                    break;
                case 19:
                    adBreakStatus = (AdBreakStatus) zzb.zza(parcel, zzaX, AdBreakStatus.CREATOR);
                    break;
                case 20:
                    videoInfo = (VideoInfo) zzb.zza(parcel, zzaX, VideoInfo.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new MediaStatus(mediaInfo, j, i, d, i2, i3, j2, j3, d2, z, jArr, i4, i5, str, i6, list, z2, adBreakStatus, videoInfo);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public MediaStatus[] zzbR(int i) {
        return new MediaStatus[i];
    }
}
