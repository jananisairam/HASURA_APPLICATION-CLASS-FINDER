package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import java.util.List;

public class zzi implements Creator<MediaInfo> {
    static void zza(MediaInfo mediaInfo, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, mediaInfo.getContentId(), false);
        zzc.zzc(parcel, 3, mediaInfo.getStreamType());
        zzc.zza(parcel, 4, mediaInfo.getContentType(), false);
        zzc.zza(parcel, 5, mediaInfo.getMetadata(), i, false);
        zzc.zza(parcel, 6, mediaInfo.getStreamDuration());
        zzc.zzc(parcel, 7, mediaInfo.getMediaTracks(), false);
        zzc.zza(parcel, 8, mediaInfo.getTextTrackStyle(), i, false);
        zzc.zza(parcel, 9, mediaInfo.zzamN, false);
        zzc.zzc(parcel, 10, mediaInfo.getAdBreaks(), false);
        zzc.zzc(parcel, 11, mediaInfo.getAdBreakClips(), false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzau(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzbN(i);
    }

    public MediaInfo zzau(Parcel parcel) {
        List list = null;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        long j = 0;
        List list2 = null;
        String str = null;
        TextTrackStyle textTrackStyle = null;
        List list3 = null;
        MediaMetadata mediaMetadata = null;
        String str2 = null;
        String str3 = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    str3 = zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 4:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 5:
                    mediaMetadata = (MediaMetadata) zzb.zza(parcel, zzaX, MediaMetadata.CREATOR);
                    break;
                case 6:
                    j = zzb.zzi(parcel, zzaX);
                    break;
                case 7:
                    list3 = zzb.zzc(parcel, zzaX, MediaTrack.CREATOR);
                    break;
                case 8:
                    textTrackStyle = (TextTrackStyle) zzb.zza(parcel, zzaX, TextTrackStyle.CREATOR);
                    break;
                case 9:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 10:
                    list2 = zzb.zzc(parcel, zzaX, AdBreakInfo.CREATOR);
                    break;
                case 11:
                    list = zzb.zzc(parcel, zzaX, AdBreakClipInfo.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new MediaInfo(str3, i, str2, mediaMetadata, j, list3, textTrackStyle, str, list2, list);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public MediaInfo[] zzbN(int i) {
        return new MediaInfo[i];
    }
}
