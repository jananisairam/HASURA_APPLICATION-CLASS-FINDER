package com.google.android.gms.cast;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.view.Display;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.HasOptions;
import com.google.android.gms.common.api.Api.zza;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.common.internal.zzg;
import com.google.android.gms.internal.zzyu;
import com.google.android.gms.internal.zzyy;
import com.google.android.gms.internal.zzzf;
import com.google.android.gms.internal.zzzg;

public final class CastRemoteDisplay {
    public static final Api<CastRemoteDisplayOptions> API = new Api("CastRemoteDisplay.API", zzaie, zzyy.zzawz);
    public static final int CONFIGURATION_INTERACTIVE_NONREALTIME = 2;
    public static final int CONFIGURATION_INTERACTIVE_REALTIME = 1;
    public static final int CONFIGURATION_NONINTERACTIVE = 3;
    public static final CastRemoteDisplayApi CastRemoteDisplayApi = new zzzf(API);
    private static final zza<zzzg, CastRemoteDisplayOptions> zzaie = new C04661();

    class C04661 extends zza<zzzg, CastRemoteDisplayOptions> {
        C04661() {
        }

        public zzzg zza(Context context, Looper looper, zzg com_google_android_gms_common_internal_zzg, CastRemoteDisplayOptions castRemoteDisplayOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            Bundle bundle = new Bundle();
            bundle.putInt("configuration", castRemoteDisplayOptions.zzanx);
            return new zzzg(context, looper, com_google_android_gms_common_internal_zzg, castRemoteDisplayOptions.zzanf, bundle, castRemoteDisplayOptions.zzanw, connectionCallbacks, onConnectionFailedListener);
        }
    }

    public static final class CastRemoteDisplayOptions implements HasOptions {
        final CastDevice zzanf;
        final CastRemoteDisplaySessionCallbacks zzanw;
        final int zzanx;

        public static final class Builder {
            CastDevice zzani;
            CastRemoteDisplaySessionCallbacks zzany;
            int zzanz = 2;

            public Builder(CastDevice castDevice, CastRemoteDisplaySessionCallbacks castRemoteDisplaySessionCallbacks) {
                zzac.zzb((Object) castDevice, (Object) "CastDevice parameter cannot be null");
                this.zzani = castDevice;
                this.zzany = castRemoteDisplaySessionCallbacks;
            }

            public CastRemoteDisplayOptions build() {
                return new CastRemoteDisplayOptions();
            }

            public Builder setConfigPreset(@Configuration int i) {
                this.zzanz = i;
                return this;
            }
        }

        private CastRemoteDisplayOptions(Builder builder) {
            this.zzanf = builder.zzani;
            this.zzanw = builder.zzany;
            this.zzanx = builder.zzanz;
        }
    }

    public interface CastRemoteDisplaySessionCallbacks {
        void onRemoteDisplayEnded(Status status);
    }

    public interface CastRemoteDisplaySessionResult extends Result {
        Display getPresentationDisplay();
    }

    public @interface Configuration {
    }

    private CastRemoteDisplay() {
    }

    public static final boolean isRemoteDisplaySdkSupported(Context context) {
        zzyu.initialize(context);
        return ((Boolean) zzyu.zzawx.get()).booleanValue();
    }
}
