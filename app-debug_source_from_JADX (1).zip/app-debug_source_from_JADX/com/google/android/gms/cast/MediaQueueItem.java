package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.util.zzq;
import com.google.android.gms.internal.zzyr;
import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaQueueItem extends zza {
    public static final Creator<MediaQueueItem> CREATOR = new zzk();
    public static final double DEFAULT_PLAYBACK_DURATION = Double.POSITIVE_INFINITY;
    public static final int INVALID_ITEM_ID = 0;
    String zzamN;
    private JSONObject zzamO;
    private boolean zzaoA;
    private double zzaoB;
    private double zzaoC;
    private double zzaoD;
    private long[] zzaoE;
    private MediaInfo zzaoy;
    private int zzaoz;

    public static class Builder {
        private final MediaQueueItem zzaoF;

        public Builder(MediaInfo mediaInfo) throws IllegalArgumentException {
            this.zzaoF = new MediaQueueItem(mediaInfo);
        }

        public Builder(MediaQueueItem mediaQueueItem) throws IllegalArgumentException {
            this.zzaoF = new MediaQueueItem();
        }

        public Builder(JSONObject jSONObject) throws JSONException {
            this.zzaoF = new MediaQueueItem(jSONObject);
        }

        public MediaQueueItem build() {
            this.zzaoF.zzsx();
            return this.zzaoF;
        }

        public Builder clearItemId() {
            this.zzaoF.zzbP(0);
            return this;
        }

        public Builder setActiveTrackIds(long[] jArr) {
            this.zzaoF.zza(jArr);
            return this;
        }

        public Builder setAutoplay(boolean z) {
            this.zzaoF.zzal(z);
            return this;
        }

        public Builder setCustomData(JSONObject jSONObject) {
            this.zzaoF.setCustomData(jSONObject);
            return this;
        }

        public Builder setPlaybackDuration(double d) {
            this.zzaoF.zzd(d);
            return this;
        }

        public Builder setPreloadTime(double d) throws IllegalArgumentException {
            this.zzaoF.zze(d);
            return this;
        }

        public Builder setStartTime(double d) throws IllegalArgumentException {
            this.zzaoF.zzc(d);
            return this;
        }
    }

    private MediaQueueItem(MediaInfo mediaInfo) throws IllegalArgumentException {
        this(mediaInfo, 0, true, 0.0d, DEFAULT_PLAYBACK_DURATION, 0.0d, null, null);
        if (mediaInfo == null) {
            throw new IllegalArgumentException("media cannot be null.");
        }
    }

    MediaQueueItem(MediaInfo mediaInfo, int i, boolean z, double d, double d2, double d3, long[] jArr, String str) {
        this.zzaoy = mediaInfo;
        this.zzaoz = i;
        this.zzaoA = z;
        this.zzaoB = d;
        this.zzaoC = d2;
        this.zzaoD = d3;
        this.zzaoE = jArr;
        this.zzamN = str;
        if (this.zzamN != null) {
            try {
                this.zzamO = new JSONObject(this.zzamN);
                return;
            } catch (JSONException e) {
                this.zzamO = null;
                this.zzamN = null;
                return;
            }
        }
        this.zzamO = null;
    }

    private MediaQueueItem(MediaQueueItem mediaQueueItem) throws IllegalArgumentException {
        this(mediaQueueItem.getMedia(), mediaQueueItem.getItemId(), mediaQueueItem.getAutoplay(), mediaQueueItem.getStartTime(), mediaQueueItem.getPlaybackDuration(), mediaQueueItem.getPreloadTime(), mediaQueueItem.getActiveTrackIds(), null);
        if (this.zzaoy == null) {
            throw new IllegalArgumentException("media cannot be null.");
        }
        this.zzamO = mediaQueueItem.getCustomData();
    }

    MediaQueueItem(JSONObject jSONObject) throws JSONException {
        this(null, 0, true, 0.0d, DEFAULT_PLAYBACK_DURATION, 0.0d, null, null);
        zzo(jSONObject);
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaQueueItem)) {
            return false;
        }
        MediaQueueItem mediaQueueItem = (MediaQueueItem) obj;
        if ((this.zzamO == null) != (mediaQueueItem.zzamO == null)) {
            return false;
        }
        if (this.zzamO != null && mediaQueueItem.zzamO != null && !zzq.zze(this.zzamO, mediaQueueItem.zzamO)) {
            return false;
        }
        if (!(zzyr.zza(this.zzaoy, mediaQueueItem.zzaoy) && this.zzaoz == mediaQueueItem.zzaoz && this.zzaoA == mediaQueueItem.zzaoA && this.zzaoB == mediaQueueItem.zzaoB && this.zzaoC == mediaQueueItem.zzaoC && this.zzaoD == mediaQueueItem.zzaoD && Arrays.equals(this.zzaoE, mediaQueueItem.zzaoE))) {
            z = false;
        }
        return z;
    }

    public long[] getActiveTrackIds() {
        return this.zzaoE;
    }

    public boolean getAutoplay() {
        return this.zzaoA;
    }

    public JSONObject getCustomData() {
        return this.zzamO;
    }

    public int getItemId() {
        return this.zzaoz;
    }

    public MediaInfo getMedia() {
        return this.zzaoy;
    }

    public double getPlaybackDuration() {
        return this.zzaoC;
    }

    public double getPreloadTime() {
        return this.zzaoD;
    }

    public double getStartTime() {
        return this.zzaoB;
    }

    public int hashCode() {
        return zzaa.hashCode(this.zzaoy, Integer.valueOf(this.zzaoz), Boolean.valueOf(this.zzaoA), Double.valueOf(this.zzaoB), Double.valueOf(this.zzaoC), Double.valueOf(this.zzaoD), Integer.valueOf(Arrays.hashCode(this.zzaoE)), String.valueOf(this.zzamO));
    }

    void setCustomData(JSONObject jSONObject) {
        this.zzamO = jSONObject;
    }

    public JSONObject toJson() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("media", this.zzaoy.toJson());
            if (this.zzaoz != 0) {
                jSONObject.put("itemId", this.zzaoz);
            }
            jSONObject.put("autoplay", this.zzaoA);
            jSONObject.put("startTime", this.zzaoB);
            if (this.zzaoC != DEFAULT_PLAYBACK_DURATION) {
                jSONObject.put("playbackDuration", this.zzaoC);
            }
            jSONObject.put("preloadTime", this.zzaoD);
            if (this.zzaoE != null) {
                JSONArray jSONArray = new JSONArray();
                for (long put : this.zzaoE) {
                    jSONArray.put(put);
                }
                jSONObject.put("activeTrackIds", jSONArray);
            }
            if (this.zzamO != null) {
                jSONObject.put("customData", this.zzamO);
            }
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i) {
        this.zzamN = this.zzamO == null ? null : this.zzamO.toString();
        zzk.zza(this, parcel, i);
    }

    void zza(long[] jArr) {
        this.zzaoE = jArr;
    }

    void zzal(boolean z) {
        this.zzaoA = z;
    }

    void zzbP(int i) {
        this.zzaoz = i;
    }

    void zzc(double d) throws IllegalArgumentException {
        if (Double.isNaN(d) || d < 0.0d) {
            throw new IllegalArgumentException("startTime cannot be negative or NaN.");
        }
        this.zzaoB = d;
    }

    void zzd(double d) throws IllegalArgumentException {
        if (Double.isNaN(d)) {
            throw new IllegalArgumentException("playbackDuration cannot be NaN.");
        }
        this.zzaoC = d;
    }

    void zze(double d) throws IllegalArgumentException {
        if (Double.isNaN(d) || d < 0.0d) {
            throw new IllegalArgumentException("preloadTime cannot be negative or NaN.");
        }
        this.zzaoD = d;
    }

    public boolean zzo(JSONObject jSONObject) throws JSONException {
        boolean z;
        boolean z2;
        double d;
        long[] jArr;
        if (jSONObject.has("media")) {
            this.zzaoy = new MediaInfo(jSONObject.getJSONObject("media"));
            z = true;
        } else {
            z = false;
        }
        if (jSONObject.has("itemId")) {
            int i = jSONObject.getInt("itemId");
            if (this.zzaoz != i) {
                this.zzaoz = i;
                z = true;
            }
        }
        if (jSONObject.has("autoplay")) {
            z2 = jSONObject.getBoolean("autoplay");
            if (this.zzaoA != z2) {
                this.zzaoA = z2;
                z = true;
            }
        }
        if (jSONObject.has("startTime")) {
            d = jSONObject.getDouble("startTime");
            if (Math.abs(d - this.zzaoB) > 1.0E-7d) {
                this.zzaoB = d;
                z = true;
            }
        }
        if (jSONObject.has("playbackDuration")) {
            d = jSONObject.getDouble("playbackDuration");
            if (Math.abs(d - this.zzaoC) > 1.0E-7d) {
                this.zzaoC = d;
                z = true;
            }
        }
        if (jSONObject.has("preloadTime")) {
            d = jSONObject.getDouble("preloadTime");
            if (Math.abs(d - this.zzaoD) > 1.0E-7d) {
                this.zzaoD = d;
                z = true;
            }
        }
        if (jSONObject.has("activeTrackIds")) {
            int i2;
            JSONArray jSONArray = jSONObject.getJSONArray("activeTrackIds");
            int length = jSONArray.length();
            long[] jArr2 = new long[length];
            for (i2 = 0; i2 < length; i2++) {
                jArr2[i2] = jSONArray.getLong(i2);
            }
            if (this.zzaoE == null) {
                jArr = jArr2;
                z2 = true;
            } else if (this.zzaoE.length != length) {
                jArr = jArr2;
                z2 = true;
            } else {
                for (i2 = 0; i2 < length; i2++) {
                    if (this.zzaoE[i2] != jArr2[i2]) {
                        jArr = jArr2;
                        z2 = true;
                        break;
                    }
                }
                long[] jArr3 = jArr2;
                z2 = false;
                jArr = jArr3;
            }
        } else {
            z2 = false;
            jArr = null;
        }
        if (z2) {
            this.zzaoE = jArr;
            z = true;
        }
        if (!jSONObject.has("customData")) {
            return z;
        }
        this.zzamO = jSONObject.getJSONObject("customData");
        return true;
    }

    void zzsx() throws IllegalArgumentException {
        if (this.zzaoy == null) {
            throw new IllegalArgumentException("media cannot be null.");
        } else if (Double.isNaN(this.zzaoB) || this.zzaoB < 0.0d) {
            throw new IllegalArgumentException("startTime cannot be negative or NaN.");
        } else if (Double.isNaN(this.zzaoC)) {
            throw new IllegalArgumentException("playbackDuration cannot be NaN.");
        } else if (Double.isNaN(this.zzaoD) || this.zzaoD < 0.0d) {
            throw new IllegalArgumentException("preloadTime cannot be negative or Nan.");
        }
    }
}
