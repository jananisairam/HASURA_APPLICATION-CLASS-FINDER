package com.google.android.gms.cast;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ServiceInfo;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.app.NotificationCompat;
import android.support.v7.media.MediaRouter;
import android.support.v7.media.MediaRouter.Callback;
import android.support.v7.media.MediaRouter.RouteInfo;
import android.text.TextUtils;
import android.view.Display;
import com.google.android.gms.C0355R;
import com.google.android.gms.cast.CastRemoteDisplay.CastRemoteDisplayOptions.Builder;
import com.google.android.gms.cast.CastRemoteDisplay.CastRemoteDisplaySessionCallbacks;
import com.google.android.gms.cast.CastRemoteDisplay.CastRemoteDisplaySessionResult;
import com.google.android.gms.cast.CastRemoteDisplay.Configuration;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.internal.zzyz;
import java.util.concurrent.atomic.AtomicBoolean;

@TargetApi(19)
public abstract class CastRemoteDisplayLocalService extends Service {
    private static final zzyz zzanA = new zzyz("CastRemoteDisplayLocalService");
    private static final int zzanB = zzsk();
    private static final Object zzanC = new Object();
    private static AtomicBoolean zzanD = new AtomicBoolean(false);
    private static CastRemoteDisplayLocalService zzanR;
    private Handler mHandler;
    private Notification mNotification;
    private Display zzOq;
    private String zzamX;
    private GoogleApiClient zzanE;
    private CastRemoteDisplaySessionCallbacks zzanF;
    private Callbacks zzanG;
    private zzb zzanH;
    private NotificationSettings zzanI;
    private boolean zzanJ;
    private PendingIntent zzanK;
    private CastDevice zzanL;
    private Context zzanM;
    private ServiceConnection zzanN;
    private MediaRouter zzanO;
    private boolean zzanP = false;
    private final Callback zzanQ = new C04671(this);
    private final IBinder zzanS = new zza();

    class C04671 extends Callback {
        final /* synthetic */ CastRemoteDisplayLocalService zzanT;

        C04671(CastRemoteDisplayLocalService castRemoteDisplayLocalService) {
            this.zzanT = castRemoteDisplayLocalService;
        }

        public void onRouteUnselected(MediaRouter mediaRouter, RouteInfo routeInfo) {
            this.zzanT.zzbQ("onRouteUnselected");
            if (this.zzanT.zzanL == null) {
                this.zzanT.zzbQ("onRouteUnselected, no device was selected");
            } else if (CastDevice.getFromBundle(routeInfo.getExtras()).getDeviceId().equals(this.zzanT.zzanL.getDeviceId())) {
                CastRemoteDisplayLocalService.stopService();
            } else {
                this.zzanT.zzbQ("onRouteUnselected, device does not match");
            }
        }
    }

    class C04682 implements OnConnectionFailedListener {
        final /* synthetic */ CastRemoteDisplayLocalService zzanT;

        C04682(CastRemoteDisplayLocalService castRemoteDisplayLocalService) {
            this.zzanT = castRemoteDisplayLocalService;
        }

        public void onConnectionFailed(ConnectionResult connectionResult) {
            CastRemoteDisplayLocalService castRemoteDisplayLocalService = this.zzanT;
            String valueOf = String.valueOf(connectionResult);
            castRemoteDisplayLocalService.zzbT(new StringBuilder(String.valueOf(valueOf).length() + 19).append("Connection failed: ").append(valueOf).toString());
            this.zzanT.zzso();
        }
    }

    class C04693 implements Runnable {
        final /* synthetic */ CastRemoteDisplayLocalService zzanT;

        C04693(CastRemoteDisplayLocalService castRemoteDisplayLocalService) {
            this.zzanT = castRemoteDisplayLocalService;
        }

        public void run() {
            this.zzanT.zzbQ("onCreate after delay. The local service been started: " + this.zzanT.zzanP);
            if (!this.zzanT.zzanP) {
                this.zzanT.zzbT("The local service has not been been started, stopping it");
                this.zzanT.stopSelf();
            }
        }
    }

    class C04704 implements ServiceConnection {
        final /* synthetic */ CastDevice zzanU;
        final /* synthetic */ Options zzanV;
        final /* synthetic */ NotificationSettings zzanW;
        final /* synthetic */ Context zzanX;
        final /* synthetic */ Callbacks zzanY;
        final /* synthetic */ String zzanc;

        C04704(String str, CastDevice castDevice, Options options, NotificationSettings notificationSettings, Context context, Callbacks callbacks) {
            this.zzanc = str;
            this.zzanU = castDevice;
            this.zzanV = options;
            this.zzanW = notificationSettings;
            this.zzanX = context;
            this.zzanY = callbacks;
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            CastRemoteDisplayLocalService zzsw = ((zza) iBinder).zzsw();
            if (zzsw == null || !zzsw.zza(this.zzanc, this.zzanU, this.zzanV, this.zzanW, this.zzanX, this, this.zzanY)) {
                CastRemoteDisplayLocalService.zzanA.zzc("Connected but unable to get the service instance", new Object[0]);
                this.zzanY.onRemoteDisplaySessionError(new Status(CastStatusCodes.ERROR_SERVICE_CREATION_FAILED));
                CastRemoteDisplayLocalService.zzanD.set(false);
                try {
                    this.zzanX.unbindService(this);
                } catch (IllegalArgumentException e) {
                    CastRemoteDisplayLocalService.zzanA.zzb("No need to unbind service, already unbound", new Object[0]);
                }
            }
        }

        public void onServiceDisconnected(ComponentName componentName) {
            CastRemoteDisplayLocalService.zzanA.zzb("onServiceDisconnected", new Object[0]);
            this.zzanY.onRemoteDisplaySessionError(new Status(CastStatusCodes.ERROR_SERVICE_DISCONNECTED, "Service Disconnected"));
            CastRemoteDisplayLocalService.zzanD.set(false);
            try {
                this.zzanX.unbindService(this);
            } catch (IllegalArgumentException e) {
                CastRemoteDisplayLocalService.zzanA.zzb("No need to unbind service, already unbound", new Object[0]);
            }
        }
    }

    class C04737 implements CastRemoteDisplaySessionCallbacks {
        C04737(CastRemoteDisplayLocalService castRemoteDisplayLocalService) {
        }

        public void onRemoteDisplayEnded(Status status) {
            CastRemoteDisplayLocalService.zzanA.zzb(String.format("Cast screen has ended: %d", new Object[]{Integer.valueOf(status.getStatusCode())}), new Object[0]);
            CastRemoteDisplayLocalService.zzai(false);
        }
    }

    class C04748 implements ResultCallback<CastRemoteDisplaySessionResult> {
        final /* synthetic */ CastRemoteDisplayLocalService zzanT;

        C04748(CastRemoteDisplayLocalService castRemoteDisplayLocalService) {
            this.zzanT = castRemoteDisplayLocalService;
        }

        public /* synthetic */ void onResult(Result result) {
            zza((CastRemoteDisplaySessionResult) result);
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void zza(com.google.android.gms.cast.CastRemoteDisplay.CastRemoteDisplaySessionResult r6) {
            /*
            r5 = this;
            r4 = 0;
            r3 = 0;
            r0 = r6.getStatus();
            r0 = r0.isSuccess();
            if (r0 != 0) goto L_0x001d;
        L_0x000c:
            r0 = com.google.android.gms.cast.CastRemoteDisplayLocalService.zzanA;
            r1 = "Connection was not successful";
            r2 = new java.lang.Object[r3];
            r0.zzc(r1, r2);
            r0 = r5.zzanT;
            r0.zzso();
        L_0x001c:
            return;
        L_0x001d:
            r0 = com.google.android.gms.cast.CastRemoteDisplayLocalService.zzanA;
            r1 = "startRemoteDisplay successful";
            r2 = new java.lang.Object[r3];
            r0.zzb(r1, r2);
            r1 = com.google.android.gms.cast.CastRemoteDisplayLocalService.zzanC;
            monitor-enter(r1);
            r0 = com.google.android.gms.cast.CastRemoteDisplayLocalService.zzanR;	 Catch:{ all -> 0x0046 }
            if (r0 != 0) goto L_0x0049;
        L_0x0033:
            r0 = com.google.android.gms.cast.CastRemoteDisplayLocalService.zzanA;	 Catch:{ all -> 0x0046 }
            r2 = "Remote Display started but session already cancelled";
            r3 = 0;
            r3 = new java.lang.Object[r3];	 Catch:{ all -> 0x0046 }
            r0.zzb(r2, r3);	 Catch:{ all -> 0x0046 }
            r0 = r5.zzanT;	 Catch:{ all -> 0x0046 }
            r0.zzso();	 Catch:{ all -> 0x0046 }
            monitor-exit(r1);	 Catch:{ all -> 0x0046 }
            goto L_0x001c;
        L_0x0046:
            r0 = move-exception;
            monitor-exit(r1);	 Catch:{ all -> 0x0046 }
            throw r0;
        L_0x0049:
            monitor-exit(r1);	 Catch:{ all -> 0x0046 }
            r0 = r6.getPresentationDisplay();
            if (r0 == 0) goto L_0x0086;
        L_0x0050:
            r1 = r5.zzanT;
            r1.zza(r0);
        L_0x0055:
            r0 = com.google.android.gms.cast.CastRemoteDisplayLocalService.zzanD;
            r0.set(r3);
            r0 = r5.zzanT;
            r0 = r0.zzanM;
            if (r0 == 0) goto L_0x001c;
        L_0x0064:
            r0 = r5.zzanT;
            r0 = r0.zzanN;
            if (r0 == 0) goto L_0x001c;
        L_0x006c:
            r0 = r5.zzanT;	 Catch:{ IllegalArgumentException -> 0x0092 }
            r0 = r0.zzanM;	 Catch:{ IllegalArgumentException -> 0x0092 }
            r1 = r5.zzanT;	 Catch:{ IllegalArgumentException -> 0x0092 }
            r1 = r1.zzanN;	 Catch:{ IllegalArgumentException -> 0x0092 }
            r0.unbindService(r1);	 Catch:{ IllegalArgumentException -> 0x0092 }
        L_0x007b:
            r0 = r5.zzanT;
            r0.zzanN = r4;
            r0 = r5.zzanT;
            r0.zzanM = r4;
            goto L_0x001c;
        L_0x0086:
            r0 = com.google.android.gms.cast.CastRemoteDisplayLocalService.zzanA;
            r1 = "Cast Remote Display session created without display";
            r2 = new java.lang.Object[r3];
            r0.zzc(r1, r2);
            goto L_0x0055;
        L_0x0092:
            r0 = move-exception;
            r0 = com.google.android.gms.cast.CastRemoteDisplayLocalService.zzanA;
            r1 = "No need to unbind service, already unbound";
            r2 = new java.lang.Object[r3];
            r0.zzb(r1, r2);
            goto L_0x007b;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.CastRemoteDisplayLocalService.8.zza(com.google.android.gms.cast.CastRemoteDisplay$CastRemoteDisplaySessionResult):void");
        }
    }

    class C04759 implements ResultCallback<CastRemoteDisplaySessionResult> {
        final /* synthetic */ CastRemoteDisplayLocalService zzanT;

        C04759(CastRemoteDisplayLocalService castRemoteDisplayLocalService) {
            this.zzanT = castRemoteDisplayLocalService;
        }

        public /* synthetic */ void onResult(Result result) {
            zza((CastRemoteDisplaySessionResult) result);
        }

        public void zza(CastRemoteDisplaySessionResult castRemoteDisplaySessionResult) {
            if (castRemoteDisplaySessionResult.getStatus().isSuccess()) {
                this.zzanT.zzbQ("remote display stopped");
            } else {
                this.zzanT.zzbQ("Unable to stop the remote display, result unsuccessful");
            }
            this.zzanT.zzOq = null;
        }
    }

    public interface Callbacks {
        void onRemoteDisplaySessionError(Status status);

        void onRemoteDisplaySessionStarted(CastRemoteDisplayLocalService castRemoteDisplayLocalService);

        void onServiceCreated(CastRemoteDisplayLocalService castRemoteDisplayLocalService);
    }

    public static final class NotificationSettings {
        private Notification mNotification;
        private PendingIntent zzaoa;
        private String zzaob;
        private String zzaoc;

        public static final class Builder {
            private NotificationSettings zzaod = new NotificationSettings();

            public NotificationSettings build() {
                if (this.zzaod.mNotification != null) {
                    if (!TextUtils.isEmpty(this.zzaod.zzaob)) {
                        throw new IllegalArgumentException("notificationTitle requires using the default notification");
                    } else if (!TextUtils.isEmpty(this.zzaod.zzaoc)) {
                        throw new IllegalArgumentException("notificationText requires using the default notification");
                    } else if (this.zzaod.zzaoa != null) {
                        throw new IllegalArgumentException("notificationPendingIntent requires using the default notification");
                    }
                } else if (TextUtils.isEmpty(this.zzaod.zzaob) && TextUtils.isEmpty(this.zzaod.zzaoc) && this.zzaod.zzaoa == null) {
                    throw new IllegalArgumentException("At least an argument must be provided");
                }
                return this.zzaod;
            }

            public Builder setNotification(Notification notification) {
                this.zzaod.mNotification = notification;
                return this;
            }

            public Builder setNotificationPendingIntent(PendingIntent pendingIntent) {
                this.zzaod.zzaoa = pendingIntent;
                return this;
            }

            public Builder setNotificationText(String str) {
                this.zzaod.zzaoc = str;
                return this;
            }

            public Builder setNotificationTitle(String str) {
                this.zzaod.zzaob = str;
                return this;
            }
        }

        private NotificationSettings() {
        }

        private NotificationSettings(NotificationSettings notificationSettings) {
            this.mNotification = notificationSettings.mNotification;
            this.zzaoa = notificationSettings.zzaoa;
            this.zzaob = notificationSettings.zzaob;
            this.zzaoc = notificationSettings.zzaoc;
        }
    }

    public static class Options {
        @Configuration
        int zzanx = 2;

        public int getConfigPreset() {
            return this.zzanx;
        }

        public void setConfigPreset(@Configuration int i) {
            this.zzanx = i;
        }
    }

    private class zza extends Binder {
        final /* synthetic */ CastRemoteDisplayLocalService zzanT;

        private zza(CastRemoteDisplayLocalService castRemoteDisplayLocalService) {
            this.zzanT = castRemoteDisplayLocalService;
        }

        CastRemoteDisplayLocalService zzsw() {
            return this.zzanT;
        }
    }

    private static final class zzb extends BroadcastReceiver {
        private zzb() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("com.google.android.gms.cast.remote_display.ACTION_NOTIFICATION_DISCONNECT")) {
                CastRemoteDisplayLocalService.zzanA.zzb("disconnecting", new Object[0]);
                CastRemoteDisplayLocalService.stopService();
            }
        }
    }

    public static CastRemoteDisplayLocalService getInstance() {
        CastRemoteDisplayLocalService castRemoteDisplayLocalService;
        synchronized (zzanC) {
            castRemoteDisplayLocalService = zzanR;
        }
        return castRemoteDisplayLocalService;
    }

    protected static void setDebugEnabled() {
        zzanA.zzar(true);
    }

    public static void startService(Context context, Class<? extends CastRemoteDisplayLocalService> cls, String str, CastDevice castDevice, NotificationSettings notificationSettings, Callbacks callbacks) {
        startServiceWithOptions(context, cls, str, castDevice, new Options(), notificationSettings, callbacks);
    }

    public static void startServiceWithOptions(@NonNull Context context, @NonNull Class<? extends CastRemoteDisplayLocalService> cls, @NonNull String str, @NonNull CastDevice castDevice, @NonNull Options options, @NonNull NotificationSettings notificationSettings, @NonNull Callbacks callbacks) {
        zzanA.zzb("Starting Service", new Object[0]);
        synchronized (zzanC) {
            if (zzanR != null) {
                zzanA.zzf("An existing service had not been stopped before starting one", new Object[0]);
                zzai(true);
            }
        }
        zza(context, (Class) cls);
        zzac.zzb((Object) context, (Object) "activityContext is required.");
        zzac.zzb((Object) cls, (Object) "serviceClass is required.");
        zzac.zzb((Object) str, (Object) "applicationId is required.");
        zzac.zzb((Object) castDevice, (Object) "device is required.");
        zzac.zzb((Object) options, (Object) "options is required.");
        zzac.zzb((Object) notificationSettings, (Object) "notificationSettings is required.");
        zzac.zzb((Object) callbacks, (Object) "callbacks is required.");
        if (notificationSettings.mNotification == null && notificationSettings.zzaoa == null) {
            throw new IllegalArgumentException("notificationSettings: Either the notification or the notificationPendingIntent must be provided");
        } else if (zzanD.getAndSet(true)) {
            zzanA.zzc("Service is already being started, startService has been called twice", new Object[0]);
        } else {
            Intent intent = new Intent(context, cls);
            context.startService(intent);
            context.bindService(intent, new C04704(str, castDevice, options, notificationSettings, context, callbacks), 64);
        }
    }

    public static void stopService() {
        zzai(false);
    }

    private GoogleApiClient zza(CastDevice castDevice, Options options) {
        Builder builder = new Builder(castDevice, this.zzanF);
        if (options != null) {
            builder.setConfigPreset(options.zzanx);
        }
        return new GoogleApiClient.Builder(this, new ConnectionCallbacks(this) {
            final /* synthetic */ CastRemoteDisplayLocalService zzanT;

            {
                this.zzanT = r1;
            }

            public void onConnected(Bundle bundle) {
                this.zzanT.zzbQ("onConnected");
                this.zzanT.zzsm();
            }

            public void onConnectionSuspended(int i) {
                CastRemoteDisplayLocalService.zzanA.zzf(String.format("[Instance: %s] ConnectionSuspended %d", new Object[]{this, Integer.valueOf(i)}), new Object[0]);
            }
        }, new C04682(this)).addApi(CastRemoteDisplay.API, builder.build()).build();
    }

    private static void zza(Context context, Class<? extends CastRemoteDisplayLocalService> cls) {
        try {
            ServiceInfo serviceInfo = context.getPackageManager().getServiceInfo(new ComponentName(context, cls), 128);
            if (serviceInfo != null && serviceInfo.exported) {
                throw new IllegalStateException("The service must not be exported, verify the manifest configuration");
            }
        } catch (NameNotFoundException e) {
            throw new IllegalStateException("Service not found, did you forget to configure it in the manifest?");
        }
    }

    private void zza(Display display) {
        this.zzOq = display;
        if (this.zzanJ) {
            this.mNotification = zzaj(true);
            startForeground(zzanB, this.mNotification);
        }
        if (this.zzanG != null) {
            this.zzanG.onRemoteDisplaySessionStarted(this);
            this.zzanG = null;
        }
        onCreatePresentation(this.zzOq);
    }

    private void zza(NotificationSettings notificationSettings) {
        zzac.zzdj("updateNotificationSettingsInternal must be called on the main thread");
        if (this.zzanI == null) {
            throw new IllegalStateException("No current notification settings to update");
        }
        if (!this.zzanJ) {
            zzac.zzb(notificationSettings.mNotification, (Object) "notification is required.");
            this.mNotification = notificationSettings.mNotification;
            this.zzanI.mNotification = this.mNotification;
        } else if (notificationSettings.mNotification != null) {
            throw new IllegalStateException("Current mode is default notification, notification attribute must not be provided");
        } else {
            if (notificationSettings.zzaoa != null) {
                this.zzanI.zzaoa = notificationSettings.zzaoa;
            }
            if (!TextUtils.isEmpty(notificationSettings.zzaob)) {
                this.zzanI.zzaob = notificationSettings.zzaob;
            }
            if (!TextUtils.isEmpty(notificationSettings.zzaoc)) {
                this.zzanI.zzaoc = notificationSettings.zzaoc;
            }
            this.mNotification = zzaj(true);
        }
        startForeground(zzanB, this.mNotification);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean zza(java.lang.String r8, com.google.android.gms.cast.CastDevice r9, com.google.android.gms.cast.CastRemoteDisplayLocalService.Options r10, com.google.android.gms.cast.CastRemoteDisplayLocalService.NotificationSettings r11, android.content.Context r12, android.content.ServiceConnection r13, com.google.android.gms.cast.CastRemoteDisplayLocalService.Callbacks r14) {
        /*
        r7 = this;
        r6 = 0;
        r1 = 1;
        r0 = 0;
        r2 = "startRemoteDisplaySession";
        r7.zzbQ(r2);
        r2 = "Starting the Cast Remote Display must be done on the main thread";
        com.google.android.gms.common.internal.zzac.zzdj(r2);
        r2 = zzanC;
        monitor-enter(r2);
        r3 = zzanR;	 Catch:{ all -> 0x00ac }
        if (r3 == 0) goto L_0x0020;
    L_0x0014:
        r1 = zzanA;	 Catch:{ all -> 0x00ac }
        r3 = "An existing service had not been stopped before starting one";
        r4 = 0;
        r4 = new java.lang.Object[r4];	 Catch:{ all -> 0x00ac }
        r1.zzf(r3, r4);	 Catch:{ all -> 0x00ac }
        monitor-exit(r2);	 Catch:{ all -> 0x00ac }
    L_0x001f:
        return r0;
    L_0x0020:
        zzanR = r7;	 Catch:{ all -> 0x00ac }
        monitor-exit(r2);	 Catch:{ all -> 0x00ac }
        r7.zzanG = r14;
        r7.zzamX = r8;
        r7.zzanL = r9;
        r7.zzanM = r12;
        r7.zzanN = r13;
        r2 = r7.getApplicationContext();
        r2 = android.support.v7.media.MediaRouter.getInstance(r2);
        r7.zzanO = r2;
        r2 = new android.support.v7.media.MediaRouteSelector$Builder;
        r2.<init>();
        r3 = r7.zzamX;
        r3 = com.google.android.gms.cast.CastMediaControlIntent.categoryForCast(r3);
        r2 = r2.addControlCategory(r3);
        r2 = r2.build();
        r3 = "addMediaRouterCallback";
        r7.zzbQ(r3);
        r3 = r7.zzanO;
        r4 = r7.zzanQ;
        r5 = 4;
        r3.addCallback(r2, r4, r5);
        r2 = new com.google.android.gms.cast.CastRemoteDisplayLocalService$7;
        r2.<init>(r7);
        r7.zzanF = r2;
        r2 = r11.mNotification;
        r7.mNotification = r2;
        r2 = new com.google.android.gms.cast.CastRemoteDisplayLocalService$zzb;
        r2.<init>();
        r7.zzanH = r2;
        r2 = r7.zzanH;
        r3 = new android.content.IntentFilter;
        r4 = "com.google.android.gms.cast.remote_display.ACTION_NOTIFICATION_DISCONNECT";
        r3.<init>(r4);
        r7.registerReceiver(r2, r3);
        r2 = new com.google.android.gms.cast.CastRemoteDisplayLocalService$NotificationSettings;
        r2.<init>(r11);
        r7.zzanI = r2;
        r2 = r7.zzanI;
        r2 = r2.mNotification;
        if (r2 != 0) goto L_0x00af;
    L_0x0086:
        r7.zzanJ = r1;
        r0 = r7.zzaj(r0);
        r7.mNotification = r0;
    L_0x008e:
        r0 = zzanB;
        r2 = r7.mNotification;
        r7.startForeground(r0, r2);
        r0 = r7.zza(r9, r10);
        r7.zzanE = r0;
        r0 = r7.zzanE;
        r0.connect();
        r0 = r7.zzanG;
        if (r0 == 0) goto L_0x00a9;
    L_0x00a4:
        r0 = r7.zzanG;
        r0.onServiceCreated(r7);
    L_0x00a9:
        r0 = r1;
        goto L_0x001f;
    L_0x00ac:
        r0 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x00ac }
        throw r0;
    L_0x00af:
        r7.zzanJ = r0;
        r0 = r7.zzanI;
        r0 = r0.mNotification;
        r7.mNotification = r0;
        goto L_0x008e;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.CastRemoteDisplayLocalService.zza(java.lang.String, com.google.android.gms.cast.CastDevice, com.google.android.gms.cast.CastRemoteDisplayLocalService$Options, com.google.android.gms.cast.CastRemoteDisplayLocalService$NotificationSettings, android.content.Context, android.content.ServiceConnection, com.google.android.gms.cast.CastRemoteDisplayLocalService$Callbacks):boolean");
    }

    private void zzag(final boolean z) {
        if (this.mHandler == null) {
            return;
        }
        if (Looper.myLooper() != Looper.getMainLooper()) {
            this.mHandler.post(new Runnable(this) {
                final /* synthetic */ CastRemoteDisplayLocalService zzanT;

                public void run() {
                    this.zzanT.zzah(z);
                }
            });
        } else {
            zzah(z);
        }
    }

    private void zzah(boolean z) {
        zzbQ("Stopping Service");
        zzac.zzdj("stopServiceInstanceInternal must be called on the main thread");
        if (!(z || this.zzanO == null)) {
            zzbQ("Setting default route");
            this.zzanO.selectRoute(this.zzanO.getDefaultRoute());
        }
        if (this.zzanH != null) {
            zzbQ("Unregistering notification receiver");
            unregisterReceiver(this.zzanH);
        }
        zzsp();
        zzsq();
        zzsl();
        if (this.zzanE != null) {
            this.zzanE.disconnect();
            this.zzanE = null;
        }
        if (!(this.zzanM == null || this.zzanN == null)) {
            try {
                this.zzanM.unbindService(this.zzanN);
            } catch (IllegalArgumentException e) {
                zzbQ("No need to unbind service, already unbound");
            }
            this.zzanN = null;
            this.zzanM = null;
        }
        this.zzamX = null;
        this.zzanE = null;
        this.mNotification = null;
        this.zzOq = null;
    }

    private static void zzai(boolean z) {
        zzanA.zzb("Stopping Service", new Object[0]);
        zzanD.set(false);
        synchronized (zzanC) {
            if (zzanR == null) {
                zzanA.zzc("Service is already being stopped", new Object[0]);
                return;
            }
            CastRemoteDisplayLocalService castRemoteDisplayLocalService = zzanR;
            zzanR = null;
            castRemoteDisplayLocalService.zzag(z);
        }
    }

    private Notification zzaj(boolean z) {
        int i;
        int i2;
        CharSequence string;
        zzbQ("createDefaultNotification");
        int i3 = getApplicationInfo().labelRes;
        CharSequence zzc = this.zzanI.zzaob;
        CharSequence zzd = this.zzanI.zzaoc;
        if (z) {
            i = C0355R.string.cast_notification_connected_message;
            i2 = C0355R.drawable.cast_ic_notification_on;
        } else {
            i = C0355R.string.cast_notification_connecting_message;
            i2 = C0355R.drawable.cast_ic_notification_connecting;
        }
        if (TextUtils.isEmpty(zzc)) {
            zzc = getString(i3);
        }
        if (TextUtils.isEmpty(zzd)) {
            string = getString(i, new Object[]{this.zzanL.getFriendlyName()});
        } else {
            string = zzd;
        }
        return new NotificationCompat.Builder(this).setContentTitle(zzc).setContentText(string).setContentIntent(this.zzanI.zzaoa).setSmallIcon(i2).setOngoing(true).addAction(17301560, getString(C0355R.string.cast_notification_disconnect), zzsr()).build();
    }

    private void zzbQ(String str) {
        zzanA.zzb("[Instance: %s] %s", this, str);
    }

    private void zzbT(String str) {
        zzanA.zzc("[Instance: %s] %s", this, str);
    }

    private static int zzsk() {
        return C0355R.id.cast_notification_id;
    }

    private void zzsl() {
        if (this.zzanO != null) {
            zzac.zzdj("CastRemoteDisplayLocalService calls must be done on the main thread");
            zzbQ("removeMediaRouterCallback");
            this.zzanO.removeCallback(this.zzanQ);
        }
    }

    private void zzsm() {
        zzbQ("startRemoteDisplay");
        if (this.zzanE == null || !this.zzanE.isConnected()) {
            zzanA.zzc("Unable to start the remote display as the API client is not ready", new Object[0]);
        } else {
            CastRemoteDisplay.CastRemoteDisplayApi.startRemoteDisplay(this.zzanE, this.zzamX).setResultCallback(new C04748(this));
        }
    }

    private void zzsn() {
        zzbQ("stopRemoteDisplay");
        if (this.zzanE == null || !this.zzanE.isConnected()) {
            zzanA.zzc("Unable to stop the remote display as the API client is not ready", new Object[0]);
        } else {
            CastRemoteDisplay.CastRemoteDisplayApi.stopRemoteDisplay(this.zzanE).setResultCallback(new C04759(this));
        }
    }

    private void zzso() {
        if (this.zzanG != null) {
            this.zzanG.onRemoteDisplaySessionError(new Status(CastStatusCodes.ERROR_SERVICE_CREATION_FAILED));
            this.zzanG = null;
        }
        stopService();
    }

    private void zzsp() {
        zzbQ("stopRemoteDisplaySession");
        zzsn();
        onDismissPresentation();
    }

    private void zzsq() {
        zzbQ("Stopping the remote display Service");
        stopForeground(true);
        stopSelf();
    }

    private PendingIntent zzsr() {
        if (this.zzanK == null) {
            Intent intent = new Intent("com.google.android.gms.cast.remote_display.ACTION_NOTIFICATION_DISCONNECT");
            intent.setPackage(this.zzanM.getPackageName());
            this.zzanK = PendingIntent.getBroadcast(this, 0, intent, DriveFile.MODE_READ_ONLY);
        }
        return this.zzanK;
    }

    protected Display getDisplay() {
        return this.zzOq;
    }

    public IBinder onBind(Intent intent) {
        zzbQ("onBind");
        return this.zzanS;
    }

    public void onCreate() {
        zzbQ("onCreate");
        super.onCreate();
        this.mHandler = new Handler(getMainLooper());
        this.mHandler.postDelayed(new C04693(this), 100);
    }

    public abstract void onCreatePresentation(Display display);

    public abstract void onDismissPresentation();

    public int onStartCommand(Intent intent, int i, int i2) {
        zzbQ("onStartCommand");
        this.zzanP = true;
        return 2;
    }

    public void updateNotificationSettings(final NotificationSettings notificationSettings) {
        zzac.zzb((Object) notificationSettings, (Object) "notificationSettings is required.");
        zzac.zzb(this.mHandler, (Object) "Service is not ready yet.");
        this.mHandler.post(new Runnable(this) {
            final /* synthetic */ CastRemoteDisplayLocalService zzanT;

            public void run() {
                this.zzanT.zza(notificationSettings);
            }
        });
    }
}
