package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.SparseArray;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.util.zzq;
import com.google.android.gms.internal.zzyr;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaStatus extends zza {
    public static final long COMMAND_PAUSE = 1;
    public static final long COMMAND_SEEK = 2;
    public static final long COMMAND_SET_VOLUME = 4;
    public static final long COMMAND_SKIP_BACKWARD = 32;
    public static final long COMMAND_SKIP_FORWARD = 16;
    public static final long COMMAND_TOGGLE_MUTE = 8;
    public static final Creator<MediaStatus> CREATOR = new zzl();
    public static final int IDLE_REASON_CANCELED = 2;
    public static final int IDLE_REASON_ERROR = 4;
    public static final int IDLE_REASON_FINISHED = 1;
    public static final int IDLE_REASON_INTERRUPTED = 3;
    public static final int IDLE_REASON_NONE = 0;
    public static final int PLAYER_STATE_BUFFERING = 4;
    public static final int PLAYER_STATE_IDLE = 1;
    public static final int PLAYER_STATE_PAUSED = 3;
    public static final int PLAYER_STATE_PLAYING = 2;
    public static final int PLAYER_STATE_UNKNOWN = 0;
    public static final int REPEAT_MODE_REPEAT_ALL = 1;
    public static final int REPEAT_MODE_REPEAT_ALL_AND_SHUFFLE = 3;
    public static final int REPEAT_MODE_REPEAT_OFF = 0;
    public static final int REPEAT_MODE_REPEAT_SINGLE = 2;
    String zzamN;
    private JSONObject zzamO;
    private long[] zzaoE;
    private long zzaoG;
    private int zzaoH;
    private double zzaoI;
    private int zzaoJ;
    private int zzaoK;
    private long zzaoL;
    long zzaoM;
    private double zzaoN;
    private boolean zzaoO;
    private int zzaoP;
    private int zzaoQ;
    int zzaoR;
    final ArrayList<MediaQueueItem> zzaoS;
    private boolean zzaoT;
    private AdBreakStatus zzaoU;
    private VideoInfo zzaoV;
    private final SparseArray<Integer> zzaoW;
    private MediaInfo zzaoq;

    MediaStatus(MediaInfo mediaInfo, long j, int i, double d, int i2, int i3, long j2, long j3, double d2, boolean z, long[] jArr, int i4, int i5, String str, int i6, List<MediaQueueItem> list, boolean z2, AdBreakStatus adBreakStatus, VideoInfo videoInfo) {
        this.zzaoS = new ArrayList();
        this.zzaoW = new SparseArray();
        this.zzaoq = mediaInfo;
        this.zzaoG = j;
        this.zzaoH = i;
        this.zzaoI = d;
        this.zzaoJ = i2;
        this.zzaoK = i3;
        this.zzaoL = j2;
        this.zzaoM = j3;
        this.zzaoN = d2;
        this.zzaoO = z;
        this.zzaoE = jArr;
        this.zzaoP = i4;
        this.zzaoQ = i5;
        this.zzamN = str;
        if (this.zzamN != null) {
            try {
                this.zzamO = new JSONObject(this.zzamN);
            } catch (JSONException e) {
                this.zzamO = null;
                this.zzamN = null;
            }
        } else {
            this.zzamO = null;
        }
        this.zzaoR = i6;
        if (!(list == null || list.isEmpty())) {
            zza((MediaQueueItem[]) list.toArray(new MediaQueueItem[list.size()]));
        }
        this.zzaoT = z2;
        this.zzaoU = adBreakStatus;
        this.zzaoV = videoInfo;
    }

    public MediaStatus(JSONObject jSONObject) throws JSONException {
        this(null, 0, 0, 0.0d, 0, 0, 0, 0, 0.0d, false, null, 0, 0, null, 0, null, false, null, null);
        zza(jSONObject, 0);
    }

    private void zza(MediaQueueItem[] mediaQueueItemArr) {
        this.zzaoS.clear();
        this.zzaoW.clear();
        for (int i = 0; i < mediaQueueItemArr.length; i++) {
            MediaQueueItem mediaQueueItem = mediaQueueItemArr[i];
            this.zzaoS.add(mediaQueueItem);
            this.zzaoW.put(mediaQueueItem.getItemId(), Integer.valueOf(i));
        }
    }

    private boolean zza(MediaStatus mediaStatus) {
        return this.zzamO == null || mediaStatus.zzamO == null || zzq.zze(this.zzamO, mediaStatus.zzamO);
    }

    private boolean zzf(int i, int i2, int i3, int i4) {
        if (i != 1) {
            return false;
        }
        switch (i2) {
            case 1:
            case 3:
                return i3 == 0;
            case 2:
                return i4 != 2;
            default:
                return true;
        }
    }

    private void zzsz() {
        this.zzaoR = 0;
        this.zzaoS.clear();
        this.zzaoW.clear();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaStatus)) {
            return false;
        }
        MediaStatus mediaStatus = (MediaStatus) obj;
        return (this.zzamO == null) != (mediaStatus.zzamO == null) ? false : this.zzaoG == mediaStatus.zzaoG && this.zzaoH == mediaStatus.zzaoH && this.zzaoI == mediaStatus.zzaoI && this.zzaoJ == mediaStatus.zzaoJ && this.zzaoK == mediaStatus.zzaoK && this.zzaoL == mediaStatus.zzaoL && this.zzaoN == mediaStatus.zzaoN && this.zzaoO == mediaStatus.zzaoO && this.zzaoP == mediaStatus.zzaoP && this.zzaoQ == mediaStatus.zzaoQ && this.zzaoR == mediaStatus.zzaoR && Arrays.equals(this.zzaoE, mediaStatus.zzaoE) && zzyr.zza(Long.valueOf(this.zzaoM), Long.valueOf(mediaStatus.zzaoM)) && zzyr.zza(this.zzaoS, mediaStatus.zzaoS) && zzyr.zza(this.zzaoq, mediaStatus.zzaoq) && zza(mediaStatus) && this.zzaoT == mediaStatus.isPlayingAd();
    }

    public long[] getActiveTrackIds() {
        return this.zzaoE;
    }

    public AdBreakStatus getAdBreakStatus() {
        return this.zzaoU;
    }

    public AdBreakInfo getCurrentAdBreak() {
        if (this.zzaoU == null || this.zzaoq == null) {
            return null;
        }
        Object breakId = this.zzaoU.getBreakId();
        if (TextUtils.isEmpty(breakId)) {
            return null;
        }
        List<AdBreakInfo> adBreaks = this.zzaoq.getAdBreaks();
        if (adBreaks == null || adBreaks.isEmpty()) {
            return null;
        }
        for (AdBreakInfo adBreakInfo : adBreaks) {
            if (breakId.equals(adBreakInfo.getId())) {
                return adBreakInfo;
            }
        }
        return null;
    }

    public AdBreakClipInfo getCurrentAdBreakClip() {
        if (this.zzaoU == null || this.zzaoq == null) {
            return null;
        }
        Object breakClipId = this.zzaoU.getBreakClipId();
        if (TextUtils.isEmpty(breakClipId)) {
            return null;
        }
        List<AdBreakClipInfo> adBreakClips = this.zzaoq.getAdBreakClips();
        if (adBreakClips == null || adBreakClips.isEmpty()) {
            return null;
        }
        for (AdBreakClipInfo adBreakClipInfo : adBreakClips) {
            if (breakClipId.equals(adBreakClipInfo.getId())) {
                return adBreakClipInfo;
            }
        }
        return null;
    }

    public int getCurrentItemId() {
        return this.zzaoH;
    }

    public JSONObject getCustomData() {
        return this.zzamO;
    }

    public int getIdleReason() {
        return this.zzaoK;
    }

    public Integer getIndexById(int i) {
        return (Integer) this.zzaoW.get(i);
    }

    public MediaQueueItem getItemById(int i) {
        Integer num = (Integer) this.zzaoW.get(i);
        return num == null ? null : (MediaQueueItem) this.zzaoS.get(num.intValue());
    }

    public MediaQueueItem getItemByIndex(int i) {
        return (i < 0 || i >= this.zzaoS.size()) ? null : (MediaQueueItem) this.zzaoS.get(i);
    }

    public int getLoadingItemId() {
        return this.zzaoP;
    }

    public MediaInfo getMediaInfo() {
        return this.zzaoq;
    }

    public double getPlaybackRate() {
        return this.zzaoI;
    }

    public int getPlayerState() {
        return this.zzaoJ;
    }

    public int getPreloadedItemId() {
        return this.zzaoQ;
    }

    public MediaQueueItem getQueueItem(int i) {
        return getItemByIndex(i);
    }

    public MediaQueueItem getQueueItemById(int i) {
        return getItemById(i);
    }

    public int getQueueItemCount() {
        return this.zzaoS.size();
    }

    public List<MediaQueueItem> getQueueItems() {
        return this.zzaoS;
    }

    public int getQueueRepeatMode() {
        return this.zzaoR;
    }

    public long getStreamPosition() {
        return this.zzaoL;
    }

    public double getStreamVolume() {
        return this.zzaoN;
    }

    public VideoInfo getVideoInfo() {
        return this.zzaoV;
    }

    public int hashCode() {
        return zzaa.hashCode(this.zzaoq, Long.valueOf(this.zzaoG), Integer.valueOf(this.zzaoH), Double.valueOf(this.zzaoI), Integer.valueOf(this.zzaoJ), Integer.valueOf(this.zzaoK), Long.valueOf(this.zzaoL), Long.valueOf(this.zzaoM), Double.valueOf(this.zzaoN), Boolean.valueOf(this.zzaoO), Integer.valueOf(Arrays.hashCode(this.zzaoE)), Integer.valueOf(this.zzaoP), Integer.valueOf(this.zzaoQ), String.valueOf(this.zzamO), Integer.valueOf(this.zzaoR), this.zzaoS, Boolean.valueOf(this.zzaoT));
    }

    public boolean isMediaCommandSupported(long j) {
        return (this.zzaoM & j) != 0;
    }

    public boolean isMute() {
        return this.zzaoO;
    }

    public boolean isPlayingAd() {
        return this.zzaoT;
    }

    public void writeToParcel(Parcel parcel, int i) {
        this.zzamN = this.zzamO == null ? null : this.zzamO.toString();
        zzl.zza(this, parcel, i);
    }

    public int zza(JSONObject jSONObject, int i) throws JSONException {
        int i2;
        int i3;
        double d;
        long zzf;
        boolean z;
        int i4 = 2;
        boolean z2 = true;
        long j = jSONObject.getLong("mediaSessionId");
        if (j != this.zzaoG) {
            this.zzaoG = j;
            i2 = 1;
        } else {
            i2 = 0;
        }
        if (jSONObject.has("playerState")) {
            String string = jSONObject.getString("playerState");
            i3 = string.equals("IDLE") ? 1 : string.equals("PLAYING") ? 2 : string.equals("PAUSED") ? 3 : string.equals("BUFFERING") ? 4 : 0;
            if (i3 != this.zzaoJ) {
                this.zzaoJ = i3;
                i2 |= 2;
            }
            if (i3 == 1 && jSONObject.has("idleReason")) {
                string = jSONObject.getString("idleReason");
                if (!string.equals("CANCELLED")) {
                    i4 = string.equals("INTERRUPTED") ? 3 : string.equals("FINISHED") ? 1 : string.equals("ERROR") ? 4 : 0;
                }
                if (i4 != this.zzaoK) {
                    this.zzaoK = i4;
                    i2 |= 2;
                }
            }
        }
        if (jSONObject.has("playbackRate")) {
            d = jSONObject.getDouble("playbackRate");
            if (this.zzaoI != d) {
                this.zzaoI = d;
                i2 |= 2;
            }
        }
        if (jSONObject.has("currentTime") && (i & 2) == 0) {
            zzf = zzyr.zzf(jSONObject.getDouble("currentTime"));
            if (zzf != this.zzaoL) {
                this.zzaoL = zzf;
                i2 |= 2;
            }
        }
        if (jSONObject.has("supportedMediaCommands")) {
            zzf = jSONObject.getLong("supportedMediaCommands");
            if (zzf != this.zzaoM) {
                this.zzaoM = zzf;
                i2 |= 2;
            }
        }
        if (jSONObject.has(MediaRouteProviderProtocol.CLIENT_DATA_VOLUME) && (i & 1) == 0) {
            JSONObject jSONObject2 = jSONObject.getJSONObject(MediaRouteProviderProtocol.CLIENT_DATA_VOLUME);
            d = jSONObject2.getDouble(Param.LEVEL);
            if (d != this.zzaoN) {
                this.zzaoN = d;
                i2 |= 2;
            }
            boolean z3 = jSONObject2.getBoolean("muted");
            if (z3 != this.zzaoO) {
                this.zzaoO = z3;
                i2 |= 2;
            }
        }
        long[] jArr = null;
        if (jSONObject.has("activeTrackIds")) {
            JSONArray jSONArray = jSONObject.getJSONArray("activeTrackIds");
            int length = jSONArray.length();
            jArr = new long[length];
            for (i4 = 0; i4 < length; i4++) {
                jArr[i4] = jSONArray.getLong(i4);
            }
            if (this.zzaoE == null) {
                z = true;
            } else if (this.zzaoE.length != length) {
                z = true;
            } else {
                for (i4 = 0; i4 < length; i4++) {
                    if (this.zzaoE[i4] != jArr[i4]) {
                        z = true;
                        break;
                    }
                }
                z = false;
            }
            if (z) {
                this.zzaoE = jArr;
            }
        } else {
            z = this.zzaoE != null;
        }
        if (z) {
            this.zzaoE = jArr;
            i2 |= 2;
        }
        if (jSONObject.has("customData")) {
            this.zzamO = jSONObject.getJSONObject("customData");
            this.zzamN = null;
            i2 |= 2;
        }
        if (jSONObject.has("media")) {
            jSONObject2 = jSONObject.getJSONObject("media");
            MediaInfo mediaInfo = new MediaInfo(jSONObject2);
            if (this.zzaoq == null || !(this.zzaoq == null || this.zzaoq.equals(mediaInfo))) {
                this.zzaoq = mediaInfo;
                i2 |= 2;
            }
            if (jSONObject2.has("metadata")) {
                i2 |= 4;
            }
        }
        if (jSONObject.has("currentItemId")) {
            i3 = jSONObject.getInt("currentItemId");
            if (this.zzaoH != i3) {
                this.zzaoH = i3;
                i2 |= 2;
            }
        }
        i3 = jSONObject.optInt("preloadedItemId", 0);
        if (this.zzaoQ != i3) {
            this.zzaoQ = i3;
            i2 |= 16;
        }
        i3 = jSONObject.optInt("loadingItemId", 0);
        if (this.zzaoP != i3) {
            this.zzaoP = i3;
            i2 |= 2;
        }
        if (zzf(this.zzaoJ, this.zzaoK, this.zzaoP, this.zzaoq == null ? -1 : this.zzaoq.getStreamType())) {
            this.zzaoH = 0;
            this.zzaoP = 0;
            this.zzaoQ = 0;
            if (!this.zzaoS.isEmpty()) {
                zzsz();
                i2 |= 8;
            }
        } else if (zzp(jSONObject)) {
            i2 |= 8;
        }
        AdBreakStatus zzl = AdBreakStatus.zzl(jSONObject.optJSONObject("breakStatus"));
        if ((this.zzaoU == null && zzl != null) || !(this.zzaoU == null || this.zzaoU.equals(zzl))) {
            if (zzl == null) {
                z2 = false;
            }
            zzam(z2);
            this.zzaoU = zzl;
            i2 |= 32;
        }
        VideoInfo zzq = VideoInfo.zzq(jSONObject.optJSONObject("videoInfo"));
        if ((this.zzaoV == null && zzq != null) || !(this.zzaoV == null || this.zzaoV.equals(zzq))) {
            this.zzaoV = zzq;
            i2 |= 64;
        }
        if (!jSONObject.has("breakInfo") || this.zzaoq == null) {
            return i2;
        }
        this.zzaoq.zzm(jSONObject.getJSONObject("breakInfo"));
        return i2 | 2;
    }

    public void zzam(boolean z) {
        this.zzaoT = z;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    boolean zzp(org.json.JSONObject r11) throws org.json.JSONException {
        /*
        r10 = this;
        r3 = 3;
        r0 = 2;
        r1 = 0;
        r2 = 1;
        r4 = "repeatMode";
        r4 = r11.has(r4);
        if (r4 == 0) goto L_0x00ef;
    L_0x000c:
        r4 = r10.zzaoR;
        r5 = "repeatMode";
        r6 = r11.getString(r5);
        r5 = -1;
        r7 = r6.hashCode();
        switch(r7) {
            case -1118317585: goto L_0x0073;
            case -962896020: goto L_0x0069;
            case 1645938909: goto L_0x005f;
            case 1645952171: goto L_0x0055;
            default: goto L_0x001c;
        };
    L_0x001c:
        switch(r5) {
            case 0: goto L_0x007d;
            case 1: goto L_0x007f;
            case 2: goto L_0x0020;
            case 3: goto L_0x0081;
            default: goto L_0x001f;
        };
    L_0x001f:
        r0 = r4;
    L_0x0020:
        r3 = r10.zzaoR;
        if (r3 == r0) goto L_0x00ef;
    L_0x0024:
        r10.zzaoR = r0;
        r0 = r2;
    L_0x0027:
        r3 = "items";
        r3 = r11.has(r3);
        if (r3 == 0) goto L_0x00ed;
    L_0x002f:
        r3 = "items";
        r4 = r11.getJSONArray(r3);
        r5 = r4.length();
        r6 = new android.util.SparseArray;
        r6.<init>();
        r3 = r1;
    L_0x003f:
        if (r3 >= r5) goto L_0x0083;
    L_0x0041:
        r7 = r4.getJSONObject(r3);
        r8 = "itemId";
        r7 = r7.getInt(r8);
        r7 = java.lang.Integer.valueOf(r7);
        r6.put(r3, r7);
        r3 = r3 + 1;
        goto L_0x003f;
    L_0x0055:
        r7 = "REPEAT_OFF";
        r6 = r6.equals(r7);
        if (r6 == 0) goto L_0x001c;
    L_0x005d:
        r5 = r1;
        goto L_0x001c;
    L_0x005f:
        r7 = "REPEAT_ALL";
        r6 = r6.equals(r7);
        if (r6 == 0) goto L_0x001c;
    L_0x0067:
        r5 = r2;
        goto L_0x001c;
    L_0x0069:
        r7 = "REPEAT_SINGLE";
        r6 = r6.equals(r7);
        if (r6 == 0) goto L_0x001c;
    L_0x0071:
        r5 = r0;
        goto L_0x001c;
    L_0x0073:
        r7 = "REPEAT_ALL_AND_SHUFFLE";
        r6 = r6.equals(r7);
        if (r6 == 0) goto L_0x001c;
    L_0x007b:
        r5 = r3;
        goto L_0x001c;
    L_0x007d:
        r0 = r1;
        goto L_0x0020;
    L_0x007f:
        r0 = r2;
        goto L_0x0020;
    L_0x0081:
        r0 = r3;
        goto L_0x0020;
    L_0x0083:
        r7 = new com.google.android.gms.cast.MediaQueueItem[r5];
        r3 = r1;
        r1 = r0;
    L_0x0087:
        if (r3 >= r5) goto L_0x00dd;
    L_0x0089:
        r0 = r6.get(r3);
        r0 = (java.lang.Integer) r0;
        r8 = r4.getJSONObject(r3);
        r9 = r0.intValue();
        r9 = r10.getItemById(r9);
        if (r9 == 0) goto L_0x00b8;
    L_0x009d:
        r8 = r9.zzo(r8);
        r1 = r1 | r8;
        r7[r3] = r9;
        r0 = r0.intValue();
        r0 = r10.getIndexById(r0);
        r0 = r0.intValue();
        if (r3 == r0) goto L_0x00eb;
    L_0x00b2:
        r0 = r2;
    L_0x00b3:
        r1 = r3 + 1;
        r3 = r1;
        r1 = r0;
        goto L_0x0087;
    L_0x00b8:
        r0 = r0.intValue();
        r1 = r10.zzaoH;
        if (r0 != r1) goto L_0x00d4;
    L_0x00c0:
        r0 = new com.google.android.gms.cast.MediaQueueItem$Builder;
        r1 = r10.zzaoq;
        r0.<init>(r1);
        r0 = r0.build();
        r7[r3] = r0;
        r0 = r7[r3];
        r0.zzo(r8);
        r0 = r2;
        goto L_0x00b3;
    L_0x00d4:
        r0 = new com.google.android.gms.cast.MediaQueueItem;
        r0.<init>(r8);
        r7[r3] = r0;
        r0 = r2;
        goto L_0x00b3;
    L_0x00dd:
        r0 = r10.zzaoS;
        r0 = r0.size();
        if (r0 == r5) goto L_0x00e9;
    L_0x00e5:
        r10.zza(r7);
    L_0x00e8:
        return r2;
    L_0x00e9:
        r2 = r1;
        goto L_0x00e5;
    L_0x00eb:
        r0 = r1;
        goto L_0x00b3;
    L_0x00ed:
        r2 = r0;
        goto L_0x00e8;
    L_0x00ef:
        r0 = r1;
        goto L_0x0027;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.cast.MediaStatus.zzp(org.json.JSONObject):boolean");
    }

    public long zzsy() {
        return this.zzaoG;
    }
}
