package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzm implements Creator<MediaTrack> {
    static void zza(MediaTrack mediaTrack, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, mediaTrack.getId());
        zzc.zzc(parcel, 3, mediaTrack.getType());
        zzc.zza(parcel, 4, mediaTrack.getContentId(), false);
        zzc.zza(parcel, 5, mediaTrack.getContentType(), false);
        zzc.zza(parcel, 6, mediaTrack.getName(), false);
        zzc.zza(parcel, 7, mediaTrack.getLanguage(), false);
        zzc.zzc(parcel, 8, mediaTrack.getSubtype());
        zzc.zza(parcel, 9, mediaTrack.zzamN, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzay(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzbT(i);
    }

    public MediaTrack zzay(Parcel parcel) {
        int i = 0;
        String str = null;
        int zzaY = zzb.zzaY(parcel);
        long j = 0;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        int i2 = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    j = zzb.zzi(parcel, zzaX);
                    break;
                case 3:
                    i2 = zzb.zzg(parcel, zzaX);
                    break;
                case 4:
                    str5 = zzb.zzq(parcel, zzaX);
                    break;
                case 5:
                    str4 = zzb.zzq(parcel, zzaX);
                    break;
                case 6:
                    str3 = zzb.zzq(parcel, zzaX);
                    break;
                case 7:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 8:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 9:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new MediaTrack(j, i2, str5, str4, str3, str2, i, str);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public MediaTrack[] zzbT(int i) {
        return new MediaTrack[i];
    }
}
