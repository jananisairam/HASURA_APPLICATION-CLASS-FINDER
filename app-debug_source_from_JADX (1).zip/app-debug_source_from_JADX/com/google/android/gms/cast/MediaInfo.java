package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.util.zzq;
import com.google.android.gms.internal.zzyr;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class MediaInfo extends zza implements ReflectedParcelable {
    public static final Creator<MediaInfo> CREATOR = new zzi();
    public static final int STREAM_TYPE_BUFFERED = 1;
    public static final int STREAM_TYPE_INVALID = -1;
    public static final int STREAM_TYPE_LIVE = 2;
    public static final int STREAM_TYPE_NONE = 0;
    public static final long UNKNOWN_DURATION = -1;
    String zzamN;
    private JSONObject zzamO;
    private final String zzaoh;
    private int zzaoi;
    private String zzaoj;
    private MediaMetadata zzaok;
    private long zzaol;
    private List<MediaTrack> zzaom;
    private TextTrackStyle zzaon;
    private List<AdBreakInfo> zzaoo;
    private List<AdBreakClipInfo> zzaop;

    public static class Builder {
        private final MediaInfo zzaoq;

        public Builder(String str) throws IllegalArgumentException {
            if (TextUtils.isEmpty(str)) {
                throw new IllegalArgumentException("Content ID cannot be empty");
            }
            this.zzaoq = new MediaInfo(str);
        }

        public MediaInfo build() throws IllegalArgumentException {
            this.zzaoq.zzsx();
            return this.zzaoq;
        }

        public Builder setContentType(String str) throws IllegalArgumentException {
            this.zzaoq.setContentType(str);
            return this;
        }

        public Builder setCustomData(JSONObject jSONObject) {
            this.zzaoq.setCustomData(jSONObject);
            return this;
        }

        public Builder setMediaTracks(List<MediaTrack> list) {
            this.zzaoq.zzz(list);
            return this;
        }

        public Builder setMetadata(MediaMetadata mediaMetadata) {
            this.zzaoq.zza(mediaMetadata);
            return this;
        }

        public Builder setStreamDuration(long j) throws IllegalArgumentException {
            this.zzaoq.zzC(j);
            return this;
        }

        public Builder setStreamType(int i) throws IllegalArgumentException {
            this.zzaoq.setStreamType(i);
            return this;
        }

        public Builder setTextTrackStyle(TextTrackStyle textTrackStyle) {
            this.zzaoq.setTextTrackStyle(textTrackStyle);
            return this;
        }
    }

    MediaInfo(String str) throws IllegalArgumentException {
        this(str, -1, null, null, -1, null, null, null, null, null);
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("content ID cannot be null or empty");
        }
    }

    MediaInfo(String str, int i, String str2, MediaMetadata mediaMetadata, long j, List<MediaTrack> list, TextTrackStyle textTrackStyle, String str3, List<AdBreakInfo> list2, List<AdBreakClipInfo> list3) {
        this.zzaoh = str;
        this.zzaoi = i;
        this.zzaoj = str2;
        this.zzaok = mediaMetadata;
        this.zzaol = j;
        this.zzaom = list;
        this.zzaon = textTrackStyle;
        this.zzamN = str3;
        if (this.zzamN != null) {
            try {
                this.zzamO = new JSONObject(this.zzamN);
            } catch (JSONException e) {
                this.zzamO = null;
                this.zzamN = null;
            }
        } else {
            this.zzamO = null;
        }
        this.zzaoo = list2;
        this.zzaop = list3;
    }

    MediaInfo(JSONObject jSONObject) throws JSONException {
        int i = 0;
        this(jSONObject.getString("contentId"), -1, null, null, -1, null, null, null, null, null);
        String string = jSONObject.getString("streamType");
        if ("NONE".equals(string)) {
            this.zzaoi = 0;
        } else if ("BUFFERED".equals(string)) {
            this.zzaoi = 1;
        } else if ("LIVE".equals(string)) {
            this.zzaoi = 2;
        } else {
            this.zzaoi = -1;
        }
        this.zzaoj = jSONObject.getString("contentType");
        if (jSONObject.has("metadata")) {
            JSONObject jSONObject2 = jSONObject.getJSONObject("metadata");
            this.zzaok = new MediaMetadata(jSONObject2.getInt("metadataType"));
            this.zzaok.zzn(jSONObject2);
        }
        this.zzaol = -1;
        if (jSONObject.has("duration") && !jSONObject.isNull("duration")) {
            double optDouble = jSONObject.optDouble("duration", 0.0d);
            if (!(Double.isNaN(optDouble) || Double.isInfinite(optDouble))) {
                this.zzaol = zzyr.zzf(optDouble);
            }
        }
        if (jSONObject.has("tracks")) {
            this.zzaom = new ArrayList();
            JSONArray jSONArray = jSONObject.getJSONArray("tracks");
            while (i < jSONArray.length()) {
                this.zzaom.add(new MediaTrack(jSONArray.getJSONObject(i)));
                i++;
            }
        } else {
            this.zzaom = null;
        }
        if (jSONObject.has("textTrackStyle")) {
            JSONObject jSONObject3 = jSONObject.getJSONObject("textTrackStyle");
            TextTrackStyle textTrackStyle = new TextTrackStyle();
            textTrackStyle.zzn(jSONObject3);
            this.zzaon = textTrackStyle;
        } else {
            this.zzaon = null;
        }
        zzm(jSONObject);
        this.zzamO = jSONObject.optJSONObject("customData");
    }

    private void zzsx() throws IllegalArgumentException {
        if (TextUtils.isEmpty(this.zzaoh)) {
            throw new IllegalArgumentException("content ID cannot be null or empty");
        } else if (TextUtils.isEmpty(this.zzaoj)) {
            throw new IllegalArgumentException("content type cannot be null or empty");
        } else if (this.zzaoi == -1) {
            throw new IllegalArgumentException("a valid stream type must be specified");
        }
    }

    public boolean equals(Object obj) {
        boolean z = true;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MediaInfo)) {
            return false;
        }
        MediaInfo mediaInfo = (MediaInfo) obj;
        if ((this.zzamO == null) != (mediaInfo.zzamO == null)) {
            return false;
        }
        if (this.zzamO != null && mediaInfo.zzamO != null && !zzq.zze(this.zzamO, mediaInfo.zzamO)) {
            return false;
        }
        if (!(zzyr.zza(this.zzaoh, mediaInfo.zzaoh) && this.zzaoi == mediaInfo.zzaoi && zzyr.zza(this.zzaoj, mediaInfo.zzaoj) && zzyr.zza(this.zzaok, mediaInfo.zzaok) && this.zzaol == mediaInfo.zzaol && zzyr.zza(this.zzaom, mediaInfo.zzaom) && zzyr.zza(this.zzaon, mediaInfo.zzaon) && zzyr.zza(this.zzaoo, mediaInfo.zzaoo) && zzyr.zza(this.zzaop, mediaInfo.zzaop))) {
            z = false;
        }
        return z;
    }

    public List<AdBreakClipInfo> getAdBreakClips() {
        return this.zzaop == null ? null : Collections.unmodifiableList(this.zzaop);
    }

    public List<AdBreakInfo> getAdBreaks() {
        return this.zzaoo == null ? null : Collections.unmodifiableList(this.zzaoo);
    }

    public String getContentId() {
        return this.zzaoh;
    }

    public String getContentType() {
        return this.zzaoj;
    }

    public JSONObject getCustomData() {
        return this.zzamO;
    }

    public List<MediaTrack> getMediaTracks() {
        return this.zzaom;
    }

    public MediaMetadata getMetadata() {
        return this.zzaok;
    }

    public long getStreamDuration() {
        return this.zzaol;
    }

    public int getStreamType() {
        return this.zzaoi;
    }

    public TextTrackStyle getTextTrackStyle() {
        return this.zzaon;
    }

    public int hashCode() {
        return zzaa.hashCode(this.zzaoh, Integer.valueOf(this.zzaoi), this.zzaoj, this.zzaok, Long.valueOf(this.zzaol), String.valueOf(this.zzamO), this.zzaom, this.zzaon, this.zzaoo, this.zzaop);
    }

    void setContentType(String str) throws IllegalArgumentException {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("content type cannot be null or empty");
        }
        this.zzaoj = str;
    }

    void setCustomData(JSONObject jSONObject) {
        this.zzamO = jSONObject;
    }

    void setStreamType(int i) throws IllegalArgumentException {
        if (i < -1 || i > 2) {
            throw new IllegalArgumentException("invalid stream type");
        }
        this.zzaoi = i;
    }

    public void setTextTrackStyle(TextTrackStyle textTrackStyle) {
        this.zzaon = textTrackStyle;
    }

    public JSONObject toJson() {
        JSONObject jSONObject = new JSONObject();
        try {
            Object obj;
            jSONObject.put("contentId", this.zzaoh);
            switch (this.zzaoi) {
                case 1:
                    obj = "BUFFERED";
                    break;
                case 2:
                    obj = "LIVE";
                    break;
                default:
                    obj = "NONE";
                    break;
            }
            jSONObject.put("streamType", obj);
            if (this.zzaoj != null) {
                jSONObject.put("contentType", this.zzaoj);
            }
            if (this.zzaok != null) {
                jSONObject.put("metadata", this.zzaok.toJson());
            }
            if (this.zzaol <= -1) {
                jSONObject.put("duration", JSONObject.NULL);
            } else {
                jSONObject.put("duration", zzyr.zzG(this.zzaol));
            }
            if (this.zzaom != null) {
                JSONArray jSONArray = new JSONArray();
                for (MediaTrack toJson : this.zzaom) {
                    jSONArray.put(toJson.toJson());
                }
                jSONObject.put("tracks", jSONArray);
            }
            if (this.zzaon != null) {
                jSONObject.put("textTrackStyle", this.zzaon.toJson());
            }
            if (this.zzamO != null) {
                jSONObject.put("customData", this.zzamO);
            }
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public void writeToParcel(Parcel parcel, int i) {
        this.zzamN = this.zzamO == null ? null : this.zzamO.toString();
        zzi.zza(this, parcel, i);
    }

    public void zzA(List<AdBreakInfo> list) {
        this.zzaoo = list;
    }

    void zzC(long j) throws IllegalArgumentException {
        if (j >= 0 || j == -1) {
            this.zzaol = j;
            return;
        }
        throw new IllegalArgumentException("Invalid stream duration");
    }

    void zza(MediaMetadata mediaMetadata) {
        this.zzaok = mediaMetadata;
    }

    void zzm(JSONObject jSONObject) throws JSONException {
        int i = 0;
        if (jSONObject.has("breaks")) {
            JSONArray jSONArray = jSONObject.getJSONArray("breaks");
            this.zzaoo = new ArrayList(jSONArray.length());
            int i2 = 0;
            while (i2 < jSONArray.length()) {
                AdBreakInfo zzk = AdBreakInfo.zzk(jSONArray.getJSONObject(i2));
                if (zzk == null) {
                    this.zzaoo.clear();
                    break;
                } else {
                    this.zzaoo.add(zzk);
                    i2++;
                }
            }
        }
        if (jSONObject.has("breakClips")) {
            JSONArray jSONArray2 = jSONObject.getJSONArray("breakClips");
            this.zzaop = new ArrayList(jSONArray2.length());
            while (i < jSONArray2.length()) {
                AdBreakClipInfo zzj = AdBreakClipInfo.zzj(jSONArray2.getJSONObject(i));
                if (zzj != null) {
                    this.zzaop.add(zzj);
                    i++;
                } else {
                    this.zzaop.clear();
                    return;
                }
            }
        }
    }

    void zzz(List<MediaTrack> list) {
        this.zzaom = list;
    }
}
