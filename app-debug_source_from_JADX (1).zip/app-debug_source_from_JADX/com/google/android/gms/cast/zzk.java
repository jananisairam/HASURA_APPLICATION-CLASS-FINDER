package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzk implements Creator<MediaQueueItem> {
    static void zza(MediaQueueItem mediaQueueItem, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, mediaQueueItem.getMedia(), i, false);
        zzc.zzc(parcel, 3, mediaQueueItem.getItemId());
        zzc.zza(parcel, 4, mediaQueueItem.getAutoplay());
        zzc.zza(parcel, 5, mediaQueueItem.getStartTime());
        zzc.zza(parcel, 6, mediaQueueItem.getPlaybackDuration());
        zzc.zza(parcel, 7, mediaQueueItem.getPreloadTime());
        zzc.zza(parcel, 8, mediaQueueItem.getActiveTrackIds(), false);
        zzc.zza(parcel, 9, mediaQueueItem.zzamN, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzaw(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzbQ(i);
    }

    public MediaQueueItem zzaw(Parcel parcel) {
        boolean z = false;
        String str = null;
        double d = 0.0d;
        int zzaY = zzb.zzaY(parcel);
        long[] jArr = null;
        double d2 = 0.0d;
        double d3 = 0.0d;
        int i = 0;
        MediaInfo mediaInfo = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    mediaInfo = (MediaInfo) zzb.zza(parcel, zzaX, MediaInfo.CREATOR);
                    break;
                case 3:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 4:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                case 5:
                    d3 = zzb.zzn(parcel, zzaX);
                    break;
                case 6:
                    d2 = zzb.zzn(parcel, zzaX);
                    break;
                case 7:
                    d = zzb.zzn(parcel, zzaX);
                    break;
                case 8:
                    jArr = zzb.zzx(parcel, zzaX);
                    break;
                case 9:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new MediaQueueItem(mediaInfo, i, z, d3, d2, d, jArr, str);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public MediaQueueItem[] zzbQ(int i) {
        return new MediaQueueItem[i];
    }
}
