package com.google.android.gms.wearable;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzh implements Creator<PutDataRequest> {
    static void zza(PutDataRequest putDataRequest, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, putDataRequest.getUri(), i, false);
        zzc.zza(parcel, 4, putDataRequest.zzUg(), false);
        zzc.zza(parcel, 5, putDataRequest.getData(), false);
        zzc.zza(parcel, 6, putDataRequest.zzUh());
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzkM(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpl(i);
    }

    public PutDataRequest zzkM(Parcel parcel) {
        byte[] bArr = null;
        int zzaY = zzb.zzaY(parcel);
        long j = 0;
        Bundle bundle = null;
        Uri uri = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    uri = (Uri) zzb.zza(parcel, zzaX, Uri.CREATOR);
                    break;
                case 4:
                    bundle = zzb.zzs(parcel, zzaX);
                    break;
                case 5:
                    bArr = zzb.zzt(parcel, zzaX);
                    break;
                case 6:
                    j = zzb.zzi(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new PutDataRequest(uri, bundle, bArr, j);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public PutDataRequest[] zzpl(int i) {
        return new PutDataRequest[i];
    }
}
