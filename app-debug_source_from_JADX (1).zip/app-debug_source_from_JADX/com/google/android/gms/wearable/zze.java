package com.google.android.gms.wearable;

import android.net.Uri;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zze implements Creator<Asset> {
    static void zza(Asset asset, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, asset.getData(), false);
        zzc.zza(parcel, 3, asset.getDigest(), false);
        zzc.zza(parcel, 4, asset.zzbSM, i, false);
        zzc.zza(parcel, 5, asset.uri, i, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzkK(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpj(i);
    }

    public Asset zzkK(Parcel parcel) {
        Uri uri = null;
        int zzaY = zzb.zzaY(parcel);
        ParcelFileDescriptor parcelFileDescriptor = null;
        String str = null;
        byte[] bArr = null;
        while (parcel.dataPosition() < zzaY) {
            ParcelFileDescriptor parcelFileDescriptor2;
            String str2;
            byte[] zzt;
            Uri uri2;
            int zzaX = zzb.zzaX(parcel);
            Uri uri3;
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    uri3 = uri;
                    parcelFileDescriptor2 = parcelFileDescriptor;
                    str2 = str;
                    zzt = zzb.zzt(parcel, zzaX);
                    uri2 = uri3;
                    break;
                case 3:
                    zzt = bArr;
                    ParcelFileDescriptor parcelFileDescriptor3 = parcelFileDescriptor;
                    str2 = zzb.zzq(parcel, zzaX);
                    uri2 = uri;
                    parcelFileDescriptor2 = parcelFileDescriptor3;
                    break;
                case 4:
                    str2 = str;
                    zzt = bArr;
                    uri3 = uri;
                    parcelFileDescriptor2 = (ParcelFileDescriptor) zzb.zza(parcel, zzaX, ParcelFileDescriptor.CREATOR);
                    uri2 = uri3;
                    break;
                case 5:
                    uri2 = (Uri) zzb.zza(parcel, zzaX, Uri.CREATOR);
                    parcelFileDescriptor2 = parcelFileDescriptor;
                    str2 = str;
                    zzt = bArr;
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    uri2 = uri;
                    parcelFileDescriptor2 = parcelFileDescriptor;
                    str2 = str;
                    zzt = bArr;
                    break;
            }
            bArr = zzt;
            str = str2;
            parcelFileDescriptor = parcelFileDescriptor2;
            uri = uri2;
        }
        if (parcel.dataPosition() == zzaY) {
            return new Asset(bArr, str, parcelFileDescriptor, uri);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public Asset[] zzpj(int i) {
        return new Asset[i];
    }
}
