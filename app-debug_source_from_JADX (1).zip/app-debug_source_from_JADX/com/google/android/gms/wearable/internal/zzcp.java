package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzcp implements Creator<zzco> {
    static void zza(zzco com_google_android_gms_wearable_internal_zzco, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzco.statusCode);
        zzc.zzc(parcel, 3, com_google_android_gms_wearable_internal_zzco.zzbhU);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzlu(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpW(i);
    }

    public zzco zzlu(Parcel parcel) {
        int i = 0;
        int zzaY = zzb.zzaY(parcel);
        int i2 = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i2 = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzco(i2, i);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzco[] zzpW(int i) {
        return new zzco[i];
    }
}
