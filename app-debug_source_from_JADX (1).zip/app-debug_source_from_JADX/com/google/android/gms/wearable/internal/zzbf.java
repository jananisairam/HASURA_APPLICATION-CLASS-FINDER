package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzbf implements Creator<zzbg> {
    static void zza(zzbg com_google_android_gms_wearable_internal_zzbg, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzbg.statusCode);
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzbg.enabled);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzlg(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpI(i);
    }

    public zzbg zzlg(Parcel parcel) {
        boolean z = false;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzbg(i, z);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzbg[] zzpI(int i) {
        return new zzbg[i];
    }
}
