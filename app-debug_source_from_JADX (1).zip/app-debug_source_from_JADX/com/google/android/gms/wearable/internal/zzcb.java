package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.zzabh;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.NodeApi;
import com.google.android.gms.wearable.NodeApi$GetConnectedNodesResult;
import com.google.android.gms.wearable.NodeApi$GetLocalNodeResult;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import java.util.ArrayList;
import java.util.List;

public final class zzcb implements NodeApi {

    class C17733 implements zza<NodeListener> {
        final /* synthetic */ IntentFilter[] zzbTK;

        C17733(IntentFilter[] intentFilterArr) {
            this.zzbTK = intentFilterArr;
        }

        public void zza(zzcx com_google_android_gms_wearable_internal_zzcx, com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status, NodeListener nodeListener, zzabh<NodeListener> com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_NodeApi_NodeListener) throws RemoteException {
            com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status, nodeListener, (zzabh) com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_NodeApi_NodeListener, this.zzbTK);
        }
    }

    public static class zza implements NodeApi$GetConnectedNodesResult {
        private final Status zzair;
        private final List<Node> zzbUL;

        public zza(Status status, List<Node> list) {
            this.zzair = status;
            this.zzbUL = list;
        }

        public List<Node> getNodes() {
            return this.zzbUL;
        }

        public Status getStatus() {
            return this.zzair;
        }
    }

    public static class zzb implements NodeApi$GetLocalNodeResult {
        private final Status zzair;
        private final Node zzbUM;

        public zzb(Status status, Node node) {
            this.zzair = status;
            this.zzbUM = node;
        }

        public Node getNode() {
            return this.zzbUM;
        }

        public Status getStatus() {
            return this.zzair;
        }
    }

    private static zza<NodeListener> zza(IntentFilter[] intentFilterArr) {
        return new C17733(intentFilterArr);
    }

    public PendingResult<Status> addListener(GoogleApiClient googleApiClient, NodeListener nodeListener) {
        return zzb.zza(googleApiClient, zza(new IntentFilter[]{zzcv.zzip("com.google.android.gms.wearable.NODE_CHANGED")}), nodeListener);
    }

    public PendingResult<NodeApi$GetConnectedNodesResult> getConnectedNodes(GoogleApiClient googleApiClient) {
        return googleApiClient.zza(new zzm<NodeApi$GetConnectedNodesResult>(this, googleApiClient) {
            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zzy(this);
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzcc(status);
            }

            protected NodeApi$GetConnectedNodesResult zzcc(Status status) {
                return new zza(status, new ArrayList());
            }
        });
    }

    public PendingResult<NodeApi$GetLocalNodeResult> getLocalNode(GoogleApiClient googleApiClient) {
        return googleApiClient.zza(new zzm<NodeApi$GetLocalNodeResult>(this, googleApiClient) {
            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zzx(this);
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzcb(status);
            }

            protected NodeApi$GetLocalNodeResult zzcb(Status status) {
                return new zzb(status, null);
            }
        });
    }

    public PendingResult<Status> removeListener(GoogleApiClient googleApiClient, final NodeListener nodeListener) {
        return googleApiClient.zza(new zzm<Status>(this, googleApiClient) {
            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) this, nodeListener);
            }

            public Status zzb(Status status) {
                return status;
            }

            public /* synthetic */ Result zzc(Status status) {
                return zzb(status);
            }
        });
    }
}
