package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzcl implements Creator<zzck> {
    static void zza(zzck com_google_android_gms_wearable_internal_zzck, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, com_google_android_gms_wearable_internal_zzck.zzaiI);
        zzc.zza(parcel, 2, com_google_android_gms_wearable_internal_zzck.zzAh(), false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzls(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpU(i);
    }

    public zzck zzls(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        IBinder iBinder = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 2:
                    iBinder = zzb.zzr(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzck(i, iBinder);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzck[] zzpU(int i) {
        return new zzck[i];
    }
}
