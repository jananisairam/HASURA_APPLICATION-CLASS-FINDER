package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zzc extends zza {
    public static final Creator<zzc> CREATOR = new zzd();
    public final String zzbTA;
    public final zzbv zzbTx;
    public final IntentFilter[] zzbTy;
    public final String zzbTz;

    zzc(IBinder iBinder, IntentFilter[] intentFilterArr, String str, String str2) {
        if (iBinder != null) {
            this.zzbTx = zzbv.zza.zzfC(iBinder);
        } else {
            this.zzbTx = null;
        }
        this.zzbTy = intentFilterArr;
        this.zzbTz = str;
        this.zzbTA = str2;
    }

    public zzc(zzcy com_google_android_gms_wearable_internal_zzcy) {
        this.zzbTx = com_google_android_gms_wearable_internal_zzcy;
        this.zzbTy = com_google_android_gms_wearable_internal_zzcy.zzUz();
        this.zzbTz = com_google_android_gms_wearable_internal_zzcy.zzUA();
        this.zzbTA = null;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzd.zza(this, parcel, i);
    }

    IBinder zzAh() {
        return this.zzbTx == null ? null : this.zzbTx.asBinder();
    }
}
