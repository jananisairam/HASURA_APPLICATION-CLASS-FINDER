package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzcd implements Creator<zzcc> {
    static void zza(zzcc com_google_android_gms_wearable_internal_zzcc, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, com_google_android_gms_wearable_internal_zzcc.getId(), false);
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzcc.getDisplayName(), false);
        zzc.zzc(parcel, 4, com_google_android_gms_wearable_internal_zzcc.getHopCount());
        zzc.zza(parcel, 5, com_google_android_gms_wearable_internal_zzcc.isNearby());
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzlo(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpQ(i);
    }

    public zzcc zzlo(Parcel parcel) {
        String str = null;
        boolean z = false;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        String str2 = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 4:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 5:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzcc(str2, str, i, z);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzcc[] zzpQ(int i) {
        return new zzcc[i];
    }
}
