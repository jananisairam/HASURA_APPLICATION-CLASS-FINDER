package com.google.android.gms.wearable.internal;

final class zzr {
    final int zzbTU;
    final int zzbTV;

    zzr(int i, int i2) {
        this.zzbTU = i;
        this.zzbTV = i2;
    }
}
