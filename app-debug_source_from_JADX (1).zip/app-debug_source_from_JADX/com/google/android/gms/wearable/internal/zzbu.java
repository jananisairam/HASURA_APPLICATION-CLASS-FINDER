package com.google.android.gms.wearable.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;

public interface zzbu extends IInterface {

    public static abstract class zza extends Binder implements zzbu {

        private static class zza implements zzbu {
            private IBinder zzrk;

            zza(IBinder iBinder) {
                this.zzrk = iBinder;
            }

            public IBinder asBinder() {
                return this.zzrk;
            }

            public void zza(Status status) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (status != null) {
                        obtain.writeInt(1);
                        status.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzaa com_google_android_gms_wearable_internal_zzaa) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzaa != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzaa.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(20, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzae com_google_android_gms_wearable_internal_zzae) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzae != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzae.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(15, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzar com_google_android_gms_wearable_internal_zzar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzar != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzat com_google_android_gms_wearable_internal_zzat) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzat != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzat.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(23, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzav com_google_android_gms_wearable_internal_zzav) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzav != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzav.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(22, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzax com_google_android_gms_wearable_internal_zzax) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzax != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzax.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(17, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzaz com_google_android_gms_wearable_internal_zzaz) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzaz != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzaz.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(18, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzbc com_google_android_gms_wearable_internal_zzbc) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzbc != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzbc.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(28, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzbe com_google_android_gms_wearable_internal_zzbe) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzbe != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzbe.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(30, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzbg com_google_android_gms_wearable_internal_zzbg) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzbg != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzbg.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(29, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzbh com_google_android_gms_wearable_internal_zzbh) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzbh != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzbh.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzbj com_google_android_gms_wearable_internal_zzbj) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzbj != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzbj.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzbl com_google_android_gms_wearable_internal_zzbl) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzbl != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzbl.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzbn com_google_android_gms_wearable_internal_zzbn) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzbn != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzbn.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzbp com_google_android_gms_wearable_internal_zzbp) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzbp != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzbp.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzbr com_google_android_gms_wearable_internal_zzbr) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzbr != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzbr.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzce com_google_android_gms_wearable_internal_zzce) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzce != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzce.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(14, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzci com_google_android_gms_wearable_internal_zzci) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzci != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzci.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzcm com_google_android_gms_wearable_internal_zzcm) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzcm != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzcm.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(27, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzco com_google_android_gms_wearable_internal_zzco) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzco != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzco.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzcs com_google_android_gms_wearable_internal_zzcs) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzcs != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzcs.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zze com_google_android_gms_wearable_internal_zze) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zze != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zze.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(26, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzy com_google_android_gms_wearable_internal_zzy) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzy != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzy.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(19, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzar(DataHolder dataHolder) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (dataHolder != null) {
                        obtain.writeInt(1);
                        dataHolder.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzb(zzae com_google_android_gms_wearable_internal_zzae) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (com_google_android_gms_wearable_internal_zzae != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzae.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(16, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public zza() {
            attachInterface(this, "com.google.android.gms.wearable.internal.IWearableCallbacks");
        }

        public static zzbu zzfB(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof zzbu)) ? new zza(iBinder) : (zzbu) queryLocalInterface;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            zzcm com_google_android_gms_wearable_internal_zzcm = null;
            zzae com_google_android_gms_wearable_internal_zzae;
            switch (i) {
                case 2:
                    zzbh com_google_android_gms_wearable_internal_zzbh;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzbh = (zzbh) zzbh.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzbh);
                    parcel2.writeNoException();
                    return true;
                case 3:
                    zzci com_google_android_gms_wearable_internal_zzci;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzci = (zzci) zzci.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzci);
                    parcel2.writeNoException();
                    return true;
                case 4:
                    zzbn com_google_android_gms_wearable_internal_zzbn;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzbn = (zzbn) zzbn.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzbn);
                    parcel2.writeNoException();
                    return true;
                case 5:
                    DataHolder dataHolder;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        dataHolder = (DataHolder) DataHolder.CREATOR.createFromParcel(parcel);
                    }
                    zzar(dataHolder);
                    parcel2.writeNoException();
                    return true;
                case 6:
                    zzar com_google_android_gms_wearable_internal_zzar;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzar = (zzar) zzar.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzar);
                    parcel2.writeNoException();
                    return true;
                case 7:
                    zzco com_google_android_gms_wearable_internal_zzco;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzco = (zzco) zzco.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzco);
                    parcel2.writeNoException();
                    return true;
                case 8:
                    zzbp com_google_android_gms_wearable_internal_zzbp;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzbp = (zzbp) zzbp.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzbp);
                    parcel2.writeNoException();
                    return true;
                case 9:
                    zzbr com_google_android_gms_wearable_internal_zzbr;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzbr = (zzbr) zzbr.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzbr);
                    parcel2.writeNoException();
                    return true;
                case 10:
                    zzbl com_google_android_gms_wearable_internal_zzbl;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzbl = (zzbl) zzbl.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzbl);
                    parcel2.writeNoException();
                    return true;
                case 11:
                    Status status;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        status = (Status) Status.CREATOR.createFromParcel(parcel);
                    }
                    zza(status);
                    parcel2.writeNoException();
                    return true;
                case 12:
                    zzcs com_google_android_gms_wearable_internal_zzcs;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzcs = (zzcs) zzcs.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzcs);
                    parcel2.writeNoException();
                    return true;
                case 13:
                    zzbj com_google_android_gms_wearable_internal_zzbj;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzbj = (zzbj) zzbj.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzbj);
                    parcel2.writeNoException();
                    return true;
                case 14:
                    zzce com_google_android_gms_wearable_internal_zzce;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzce = (zzce) zzce.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzce);
                    parcel2.writeNoException();
                    return true;
                case 15:
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzae = (zzae) zzae.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzae);
                    parcel2.writeNoException();
                    return true;
                case 16:
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzae = (zzae) zzae.CREATOR.createFromParcel(parcel);
                    }
                    zzb(com_google_android_gms_wearable_internal_zzae);
                    parcel2.writeNoException();
                    return true;
                case 17:
                    zzax com_google_android_gms_wearable_internal_zzax;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzax = (zzax) zzax.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzax);
                    parcel2.writeNoException();
                    return true;
                case 18:
                    zzaz com_google_android_gms_wearable_internal_zzaz;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzaz = (zzaz) zzaz.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzaz);
                    parcel2.writeNoException();
                    return true;
                case 19:
                    zzy com_google_android_gms_wearable_internal_zzy;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzy = (zzy) zzy.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzy);
                    parcel2.writeNoException();
                    return true;
                case 20:
                    zzaa com_google_android_gms_wearable_internal_zzaa;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzaa = (zzaa) zzaa.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzaa);
                    parcel2.writeNoException();
                    return true;
                case 22:
                    zzav com_google_android_gms_wearable_internal_zzav;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzav = (zzav) zzav.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzav);
                    parcel2.writeNoException();
                    return true;
                case 23:
                    zzat com_google_android_gms_wearable_internal_zzat;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzat = (zzat) zzat.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzat);
                    parcel2.writeNoException();
                    return true;
                case 26:
                    zze com_google_android_gms_wearable_internal_zze;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zze = (zze) zze.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zze);
                    parcel2.writeNoException();
                    return true;
                case 27:
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzcm = (zzcm) zzcm.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzcm);
                    parcel2.writeNoException();
                    return true;
                case 28:
                    zzbc com_google_android_gms_wearable_internal_zzbc;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzbc = (zzbc) zzbc.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzbc);
                    parcel2.writeNoException();
                    return true;
                case 29:
                    zzbg com_google_android_gms_wearable_internal_zzbg;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzbg = (zzbg) zzbg.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzbg);
                    parcel2.writeNoException();
                    return true;
                case 30:
                    zzbe com_google_android_gms_wearable_internal_zzbe;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzbe = (zzbe) zzbe.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzbe);
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.gms.wearable.internal.IWearableCallbacks");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void zza(Status status) throws RemoteException;

    void zza(zzaa com_google_android_gms_wearable_internal_zzaa) throws RemoteException;

    void zza(zzae com_google_android_gms_wearable_internal_zzae) throws RemoteException;

    void zza(zzar com_google_android_gms_wearable_internal_zzar) throws RemoteException;

    void zza(zzat com_google_android_gms_wearable_internal_zzat) throws RemoteException;

    void zza(zzav com_google_android_gms_wearable_internal_zzav) throws RemoteException;

    void zza(zzax com_google_android_gms_wearable_internal_zzax) throws RemoteException;

    void zza(zzaz com_google_android_gms_wearable_internal_zzaz) throws RemoteException;

    void zza(zzbc com_google_android_gms_wearable_internal_zzbc) throws RemoteException;

    void zza(zzbe com_google_android_gms_wearable_internal_zzbe) throws RemoteException;

    void zza(zzbg com_google_android_gms_wearable_internal_zzbg) throws RemoteException;

    void zza(zzbh com_google_android_gms_wearable_internal_zzbh) throws RemoteException;

    void zza(zzbj com_google_android_gms_wearable_internal_zzbj) throws RemoteException;

    void zza(zzbl com_google_android_gms_wearable_internal_zzbl) throws RemoteException;

    void zza(zzbn com_google_android_gms_wearable_internal_zzbn) throws RemoteException;

    void zza(zzbp com_google_android_gms_wearable_internal_zzbp) throws RemoteException;

    void zza(zzbr com_google_android_gms_wearable_internal_zzbr) throws RemoteException;

    void zza(zzce com_google_android_gms_wearable_internal_zzce) throws RemoteException;

    void zza(zzci com_google_android_gms_wearable_internal_zzci) throws RemoteException;

    void zza(zzcm com_google_android_gms_wearable_internal_zzcm) throws RemoteException;

    void zza(zzco com_google_android_gms_wearable_internal_zzco) throws RemoteException;

    void zza(zzcs com_google_android_gms_wearable_internal_zzcs) throws RemoteException;

    void zza(zze com_google_android_gms_wearable_internal_zze) throws RemoteException;

    void zza(zzy com_google_android_gms_wearable_internal_zzy) throws RemoteException;

    void zzar(DataHolder dataHolder) throws RemoteException;

    void zzb(zzae com_google_android_gms_wearable_internal_zzae) throws RemoteException;
}
