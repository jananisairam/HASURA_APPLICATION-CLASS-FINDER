package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.internal.zzbt.zza;

public final class zzac extends zza {
    private zzr zzbUe;
    private zzad zzbUi;
    private final Object zzrJ = new Object();

    public void zzE(int i, int i2) {
        synchronized (this.zzrJ) {
            zzad com_google_android_gms_wearable_internal_zzad = this.zzbUi;
            zzr com_google_android_gms_wearable_internal_zzr = new zzr(i, i2);
            this.zzbUe = com_google_android_gms_wearable_internal_zzr;
        }
        if (com_google_android_gms_wearable_internal_zzad != null) {
            com_google_android_gms_wearable_internal_zzad.zzb(com_google_android_gms_wearable_internal_zzr);
        }
    }

    public void zza(zzad com_google_android_gms_wearable_internal_zzad) {
        synchronized (this.zzrJ) {
            this.zzbUi = (zzad) com.google.android.gms.common.internal.zzac.zzw(com_google_android_gms_wearable_internal_zzad);
            zzr com_google_android_gms_wearable_internal_zzr = this.zzbUe;
        }
        if (com_google_android_gms_wearable_internal_zzr != null) {
            com_google_android_gms_wearable_internal_zzad.zzb(com_google_android_gms_wearable_internal_zzr);
        }
    }
}
