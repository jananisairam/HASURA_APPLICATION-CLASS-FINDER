package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.net.Uri;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.internal.zzabh;
import com.google.android.gms.wearable.MessageApi;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.MessageApi.SendMessageResult;

public final class zzby implements MessageApi {

    private static final class zza extends zzm<Status> {
        private zzabh<MessageListener> zzaDf;
        private MessageListener zzbUI;
        private IntentFilter[] zzbUJ;

        private zza(GoogleApiClient googleApiClient, MessageListener messageListener, zzabh<MessageListener> com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_MessageApi_MessageListener, IntentFilter[] intentFilterArr) {
            super(googleApiClient);
            this.zzbUI = (MessageListener) zzac.zzw(messageListener);
            this.zzaDf = (zzabh) zzac.zzw(com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_MessageApi_MessageListener);
            this.zzbUJ = (IntentFilter[]) zzac.zzw(intentFilterArr);
        }

        protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
            com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) this, this.zzbUI, this.zzaDf, this.zzbUJ);
            this.zzbUI = null;
            this.zzaDf = null;
            this.zzbUJ = null;
        }

        public Status zzb(Status status) {
            this.zzbUI = null;
            this.zzaDf = null;
            this.zzbUJ = null;
            return status;
        }

        public /* synthetic */ Result zzc(Status status) {
            return zzb(status);
        }
    }

    public static class zzb implements SendMessageResult {
        private final int zzaKE;
        private final Status zzair;

        public zzb(Status status, int i) {
            this.zzair = status;
            this.zzaKE = i;
        }

        public int getRequestId() {
            return this.zzaKE;
        }

        public Status getStatus() {
            return this.zzair;
        }
    }

    private PendingResult<Status> zza(GoogleApiClient googleApiClient, MessageListener messageListener, IntentFilter[] intentFilterArr) {
        return googleApiClient.zza(new zza(googleApiClient, messageListener, googleApiClient.zzr(messageListener), intentFilterArr));
    }

    public PendingResult<Status> addListener(GoogleApiClient googleApiClient, MessageListener messageListener) {
        return zza(googleApiClient, messageListener, new IntentFilter[]{zzcv.zzip(MessageApi.ACTION_MESSAGE_RECEIVED)});
    }

    public PendingResult<Status> addListener(GoogleApiClient googleApiClient, MessageListener messageListener, Uri uri, int i) {
        zzac.zzb(uri != null, "uri must not be null");
        boolean z = i == 0 || i == 1;
        zzac.zzb(z, "invalid filter type");
        return zza(googleApiClient, messageListener, new IntentFilter[]{zzcv.zza(MessageApi.ACTION_MESSAGE_RECEIVED, uri, i)});
    }

    public PendingResult<Status> removeListener(GoogleApiClient googleApiClient, final MessageListener messageListener) {
        return googleApiClient.zza(new zzm<Status>(this, googleApiClient) {
            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) this, messageListener);
            }

            public Status zzb(Status status) {
                return status;
            }

            public /* synthetic */ Result zzc(Status status) {
                return zzb(status);
            }
        });
    }

    public PendingResult<SendMessageResult> sendMessage(GoogleApiClient googleApiClient, String str, String str2, byte[] bArr) {
        final String str3 = str;
        final String str4 = str2;
        final byte[] bArr2 = bArr;
        return googleApiClient.zza(new zzm<SendMessageResult>(this, googleApiClient) {
            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) this, str3, str4, bArr2);
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzca(status);
            }

            protected SendMessageResult zzca(Status status) {
                return new zzb(status, -1);
            }
        });
    }
}
