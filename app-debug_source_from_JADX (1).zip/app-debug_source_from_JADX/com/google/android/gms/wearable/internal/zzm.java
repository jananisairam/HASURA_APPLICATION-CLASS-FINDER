package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.internal.zzaad.zza;
import com.google.android.gms.wearable.Wearable;

abstract class zzm<R extends Result> extends zza<R, zzcx> {
    public zzm(GoogleApiClient googleApiClient) {
        super(Wearable.API, googleApiClient);
    }

    public /* synthetic */ void setResult(Object obj) {
        super.zzb((Result) obj);
    }
}
