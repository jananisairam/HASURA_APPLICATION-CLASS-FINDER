package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzbs implements Creator<zzbr> {
    static void zza(zzbr com_google_android_gms_wearable_internal_zzbr, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzbr.statusCode);
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzbr.zzbUD, i, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzlm(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpO(i);
    }

    public zzbr zzlm(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        zzcc com_google_android_gms_wearable_internal_zzcc = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    com_google_android_gms_wearable_internal_zzcc = (zzcc) zzb.zza(parcel, zzaX, zzcc.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzbr(i, com_google_android_gms_wearable_internal_zzcc);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzbr[] zzpO(int i) {
        return new zzbr[i];
    }
}
