package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzcj implements Creator<zzci> {
    static void zza(zzci com_google_android_gms_wearable_internal_zzci, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzci.statusCode);
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzci.zzbUC, i, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzlr(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpT(i);
    }

    public zzci zzlr(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        zzao com_google_android_gms_wearable_internal_zzao = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    com_google_android_gms_wearable_internal_zzao = (zzao) zzb.zza(parcel, zzaX, zzao.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzci(i, com_google_android_gms_wearable_internal_zzao);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzci[] zzpT(int i) {
        return new zzci[i];
    }
}
