package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.internal.zzabh;
import com.google.android.gms.internal.zzabh.zzc;
import com.google.android.gms.wearable.CapabilityApi.CapabilityListener;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import com.google.android.gms.wearable.internal.zzbv.zza;
import java.util.List;

public class zzcy<T> extends zza {
    private final IntentFilter[] zzbUJ;
    private zzabh<Object> zzbVf;
    private zzabh<Object> zzbVg;
    private zzabh<DataListener> zzbVh;
    private zzabh<MessageListener> zzbVi;
    private zzabh<NodeListener> zzbVj;
    private zzabh<Object> zzbVk;
    private zzabh<ChannelListener> zzbVl;
    private zzabh<CapabilityListener> zzbVm;
    private final String zzbVn;

    class C17781 implements zzc<DataListener> {
        final /* synthetic */ DataHolder zzbTn;

        C17781(DataHolder dataHolder) {
            this.zzbTn = dataHolder;
        }

        public void zza(DataListener dataListener) {
            try {
                dataListener.onDataChanged(new DataEventBuffer(this.zzbTn));
            } finally {
                this.zzbTn.close();
            }
        }

        public /* synthetic */ void zzs(Object obj) {
            zza((DataListener) obj);
        }

        public void zzwc() {
            this.zzbTn.close();
        }
    }

    class C17792 implements zzc<MessageListener> {
        final /* synthetic */ zzbz zzbTp;

        C17792(zzbz com_google_android_gms_wearable_internal_zzbz) {
            this.zzbTp = com_google_android_gms_wearable_internal_zzbz;
        }

        public void zza(MessageListener messageListener) {
            messageListener.onMessageReceived(this.zzbTp);
        }

        public /* synthetic */ void zzs(Object obj) {
            zza((MessageListener) obj);
        }

        public void zzwc() {
        }
    }

    class C17803 implements zzc<NodeListener> {
        final /* synthetic */ zzcc zzbTq;

        C17803(zzcc com_google_android_gms_wearable_internal_zzcc) {
            this.zzbTq = com_google_android_gms_wearable_internal_zzcc;
        }

        public void zza(NodeListener nodeListener) {
            nodeListener.onPeerConnected(this.zzbTq);
        }

        public /* synthetic */ void zzs(Object obj) {
            zza((NodeListener) obj);
        }

        public void zzwc() {
        }
    }

    class C17814 implements zzc<NodeListener> {
        final /* synthetic */ zzcc zzbTq;

        C17814(zzcc com_google_android_gms_wearable_internal_zzcc) {
            this.zzbTq = com_google_android_gms_wearable_internal_zzcc;
        }

        public void zza(NodeListener nodeListener) {
            nodeListener.onPeerDisconnected(this.zzbTq);
        }

        public /* synthetic */ void zzs(Object obj) {
            zza((NodeListener) obj);
        }

        public void zzwc() {
        }
    }

    class C17825 implements zzc<ChannelListener> {
        final /* synthetic */ zzs zzbTv;

        C17825(zzs com_google_android_gms_wearable_internal_zzs) {
            this.zzbTv = com_google_android_gms_wearable_internal_zzs;
        }

        public void zzb(ChannelListener channelListener) {
            this.zzbTv.zza(channelListener);
        }

        public /* synthetic */ void zzs(Object obj) {
            zzb((ChannelListener) obj);
        }

        public void zzwc() {
        }
    }

    class C17836 implements zzc<CapabilityListener> {
        final /* synthetic */ zzo zzbVo;

        C17836(zzo com_google_android_gms_wearable_internal_zzo) {
            this.zzbVo = com_google_android_gms_wearable_internal_zzo;
        }

        public void zza(CapabilityListener capabilityListener) {
            capabilityListener.onCapabilityChanged(this.zzbVo);
        }

        public /* synthetic */ void zzs(Object obj) {
            zza((CapabilityListener) obj);
        }

        public void zzwc() {
        }
    }

    private zzcy(IntentFilter[] intentFilterArr, String str) {
        this.zzbUJ = (IntentFilter[]) zzac.zzw(intentFilterArr);
        this.zzbVn = str;
    }

    public static zzcy<ChannelListener> zza(zzabh<ChannelListener> com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_ChannelApi_ChannelListener, String str, IntentFilter[] intentFilterArr) {
        zzcy<ChannelListener> com_google_android_gms_wearable_internal_zzcy = new zzcy(intentFilterArr, (String) zzac.zzw(str));
        com_google_android_gms_wearable_internal_zzcy.zzbVl = (zzabh) zzac.zzw(com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_ChannelApi_ChannelListener);
        return com_google_android_gms_wearable_internal_zzcy;
    }

    public static zzcy<DataListener> zza(zzabh<DataListener> com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_DataApi_DataListener, IntentFilter[] intentFilterArr) {
        zzcy<DataListener> com_google_android_gms_wearable_internal_zzcy = new zzcy(intentFilterArr, null);
        com_google_android_gms_wearable_internal_zzcy.zzbVh = (zzabh) zzac.zzw(com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_DataApi_DataListener);
        return com_google_android_gms_wearable_internal_zzcy;
    }

    private static zzc<DataListener> zzas(DataHolder dataHolder) {
        return new C17781(dataHolder);
    }

    private static zzc<MessageListener> zzb(zzbz com_google_android_gms_wearable_internal_zzbz) {
        return new C17792(com_google_android_gms_wearable_internal_zzbz);
    }

    private static zzc<CapabilityListener> zzb(zzo com_google_android_gms_wearable_internal_zzo) {
        return new C17836(com_google_android_gms_wearable_internal_zzo);
    }

    private static zzc<ChannelListener> zzb(zzs com_google_android_gms_wearable_internal_zzs) {
        return new C17825(com_google_android_gms_wearable_internal_zzs);
    }

    public static zzcy<MessageListener> zzb(zzabh<MessageListener> com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_MessageApi_MessageListener, IntentFilter[] intentFilterArr) {
        zzcy<MessageListener> com_google_android_gms_wearable_internal_zzcy = new zzcy(intentFilterArr, null);
        com_google_android_gms_wearable_internal_zzcy.zzbVi = (zzabh) zzac.zzw(com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_MessageApi_MessageListener);
        return com_google_android_gms_wearable_internal_zzcy;
    }

    private static zzc<NodeListener> zzc(zzcc com_google_android_gms_wearable_internal_zzcc) {
        return new C17803(com_google_android_gms_wearable_internal_zzcc);
    }

    public static zzcy<NodeListener> zzc(zzabh<NodeListener> com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_NodeApi_NodeListener, IntentFilter[] intentFilterArr) {
        zzcy<NodeListener> com_google_android_gms_wearable_internal_zzcy = new zzcy(intentFilterArr, null);
        com_google_android_gms_wearable_internal_zzcy.zzbVj = (zzabh) zzac.zzw(com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_NodeApi_NodeListener);
        return com_google_android_gms_wearable_internal_zzcy;
    }

    private static zzc<NodeListener> zzd(zzcc com_google_android_gms_wearable_internal_zzcc) {
        return new C17814(com_google_android_gms_wearable_internal_zzcc);
    }

    public static zzcy<ChannelListener> zzd(zzabh<ChannelListener> com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_ChannelApi_ChannelListener, IntentFilter[] intentFilterArr) {
        zzcy<ChannelListener> com_google_android_gms_wearable_internal_zzcy = new zzcy(intentFilterArr, null);
        com_google_android_gms_wearable_internal_zzcy.zzbVl = (zzabh) zzac.zzw(com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_ChannelApi_ChannelListener);
        return com_google_android_gms_wearable_internal_zzcy;
    }

    public static zzcy<CapabilityListener> zze(zzabh<CapabilityListener> com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_CapabilityApi_CapabilityListener, IntentFilter[] intentFilterArr) {
        zzcy<CapabilityListener> com_google_android_gms_wearable_internal_zzcy = new zzcy(intentFilterArr, null);
        com_google_android_gms_wearable_internal_zzcy.zzbVm = (zzabh) zzac.zzw(com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_CapabilityApi_CapabilityListener);
        return com_google_android_gms_wearable_internal_zzcy;
    }

    private static void zzl(zzabh<?> com_google_android_gms_internal_zzabh_) {
        if (com_google_android_gms_internal_zzabh_ != null) {
            com_google_android_gms_internal_zzabh_.clear();
        }
    }

    public void clear() {
        zzl(null);
        this.zzbVf = null;
        zzl(null);
        this.zzbVg = null;
        zzl(this.zzbVh);
        this.zzbVh = null;
        zzl(this.zzbVi);
        this.zzbVi = null;
        zzl(this.zzbVj);
        this.zzbVj = null;
        zzl(null);
        this.zzbVk = null;
        zzl(this.zzbVl);
        this.zzbVl = null;
        zzl(this.zzbVm);
        this.zzbVm = null;
    }

    public void onConnectedNodes(List<zzcc> list) {
    }

    public String zzUA() {
        return this.zzbVn;
    }

    public IntentFilter[] zzUz() {
        return this.zzbUJ;
    }

    public void zza(zzbz com_google_android_gms_wearable_internal_zzbz) {
        if (this.zzbVi != null) {
            this.zzbVi.zza(zzb(com_google_android_gms_wearable_internal_zzbz));
        }
    }

    public void zza(zzcc com_google_android_gms_wearable_internal_zzcc) {
        if (this.zzbVj != null) {
            this.zzbVj.zza(zzc(com_google_android_gms_wearable_internal_zzcc));
        }
    }

    public void zza(zzh com_google_android_gms_wearable_internal_zzh) {
    }

    public void zza(zzk com_google_android_gms_wearable_internal_zzk) {
    }

    public void zza(zzo com_google_android_gms_wearable_internal_zzo) {
        if (this.zzbVm != null) {
            this.zzbVm.zza(zzb(com_google_android_gms_wearable_internal_zzo));
        }
    }

    public void zza(zzs com_google_android_gms_wearable_internal_zzs) {
        if (this.zzbVl != null) {
            this.zzbVl.zza(zzb(com_google_android_gms_wearable_internal_zzs));
        }
    }

    public void zzaq(DataHolder dataHolder) {
        if (this.zzbVh != null) {
            this.zzbVh.zza(zzas(dataHolder));
        } else {
            dataHolder.close();
        }
    }

    public void zzb(zzcc com_google_android_gms_wearable_internal_zzcc) {
        if (this.zzbVj != null) {
            this.zzbVj.zza(zzd(com_google_android_gms_wearable_internal_zzcc));
        }
    }
}
