package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.DataItemAsset;

public class zzak implements DataItemAsset {
    private final String zzAX;
    private final String zzGV;

    public zzak(DataItemAsset dataItemAsset) {
        this.zzGV = dataItemAsset.getId();
        this.zzAX = dataItemAsset.getDataItemKey();
    }

    public /* synthetic */ Object freeze() {
        return zzUw();
    }

    public String getDataItemKey() {
        return this.zzAX;
    }

    public String getId() {
        return this.zzGV;
    }

    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DataItemAssetEntity[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.zzGV == null) {
            stringBuilder.append(",noid");
        } else {
            stringBuilder.append(",");
            stringBuilder.append(this.zzGV);
        }
        stringBuilder.append(", key=");
        stringBuilder.append(this.zzAX);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public DataItemAsset zzUw() {
        return this;
    }
}
