package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.wearable.ConnectionConfiguration;

public class zzbi implements Creator<zzbh> {
    static void zza(zzbh com_google_android_gms_wearable_internal_zzbh, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzbh.statusCode);
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzbh.zzbUz, i, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzlh(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpJ(i);
    }

    public zzbh zzlh(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        ConnectionConfiguration connectionConfiguration = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    connectionConfiguration = (ConnectionConfiguration) zzb.zza(parcel, zzaX, ConnectionConfiguration.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzbh(i, connectionConfiguration);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzbh[] zzpJ(int i) {
        return new zzbh[i];
    }
}
