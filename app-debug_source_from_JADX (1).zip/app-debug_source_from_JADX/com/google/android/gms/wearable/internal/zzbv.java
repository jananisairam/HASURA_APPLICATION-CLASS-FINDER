package com.google.android.gms.wearable.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.common.data.DataHolder;
import java.util.List;

public interface zzbv extends IInterface {

    public static abstract class zza extends Binder implements zzbv {

        private static class zza implements zzbv {
            private IBinder zzrk;

            zza(IBinder iBinder) {
                this.zzrk = iBinder;
            }

            public IBinder asBinder() {
                return this.zzrk;
            }

            public void onConnectedNodes(List<zzcc> list) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
                    obtain.writeTypedList(list);
                    this.zzrk.transact(5, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void zza(zzbz com_google_android_gms_wearable_internal_zzbz) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
                    if (com_google_android_gms_wearable_internal_zzbz != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzbz.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(2, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void zza(zzcc com_google_android_gms_wearable_internal_zzcc) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
                    if (com_google_android_gms_wearable_internal_zzcc != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzcc.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(3, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void zza(zzh com_google_android_gms_wearable_internal_zzh) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
                    if (com_google_android_gms_wearable_internal_zzh != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzh.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(9, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void zza(zzk com_google_android_gms_wearable_internal_zzk) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
                    if (com_google_android_gms_wearable_internal_zzk != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzk.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(6, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void zza(zzo com_google_android_gms_wearable_internal_zzo) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
                    if (com_google_android_gms_wearable_internal_zzo != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzo.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(8, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void zza(zzs com_google_android_gms_wearable_internal_zzs) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
                    if (com_google_android_gms_wearable_internal_zzs != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzs.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(7, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void zzaq(DataHolder dataHolder) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
                    if (dataHolder != null) {
                        obtain.writeInt(1);
                        dataHolder.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(1, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void zzb(zzcc com_google_android_gms_wearable_internal_zzcc) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
                    if (com_google_android_gms_wearable_internal_zzcc != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_wearable_internal_zzcc.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.zzrk.transact(4, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }
        }

        public zza() {
            attachInterface(this, "com.google.android.gms.wearable.internal.IWearableListener");
        }

        public static zzbv zzfC(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.wearable.internal.IWearableListener");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof zzbv)) ? new zza(iBinder) : (zzbv) queryLocalInterface;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            zzh com_google_android_gms_wearable_internal_zzh = null;
            zzcc com_google_android_gms_wearable_internal_zzcc;
            switch (i) {
                case 1:
                    DataHolder dataHolder;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                    if (parcel.readInt() != 0) {
                        dataHolder = (DataHolder) DataHolder.CREATOR.createFromParcel(parcel);
                    }
                    zzaq(dataHolder);
                    return true;
                case 2:
                    zzbz com_google_android_gms_wearable_internal_zzbz;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzbz = (zzbz) zzbz.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzbz);
                    return true;
                case 3:
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzcc = (zzcc) zzcc.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzcc);
                    return true;
                case 4:
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzcc = (zzcc) zzcc.CREATOR.createFromParcel(parcel);
                    }
                    zzb(com_google_android_gms_wearable_internal_zzcc);
                    return true;
                case 5:
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                    onConnectedNodes(parcel.createTypedArrayList(zzcc.CREATOR));
                    return true;
                case 6:
                    zzk com_google_android_gms_wearable_internal_zzk;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzk = (zzk) zzk.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzk);
                    return true;
                case 7:
                    zzs com_google_android_gms_wearable_internal_zzs;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzs = (zzs) zzs.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzs);
                    return true;
                case 8:
                    zzo com_google_android_gms_wearable_internal_zzo;
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzo = (zzo) zzo.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzo);
                    return true;
                case 9:
                    parcel.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_wearable_internal_zzh = (zzh) zzh.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_wearable_internal_zzh);
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.gms.wearable.internal.IWearableListener");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void onConnectedNodes(List<zzcc> list) throws RemoteException;

    void zza(zzbz com_google_android_gms_wearable_internal_zzbz) throws RemoteException;

    void zza(zzcc com_google_android_gms_wearable_internal_zzcc) throws RemoteException;

    void zza(zzh com_google_android_gms_wearable_internal_zzh) throws RemoteException;

    void zza(zzk com_google_android_gms_wearable_internal_zzk) throws RemoteException;

    void zza(zzo com_google_android_gms_wearable_internal_zzo) throws RemoteException;

    void zza(zzs com_google_android_gms_wearable_internal_zzs) throws RemoteException;

    void zzaq(DataHolder dataHolder) throws RemoteException;

    void zzb(zzcc com_google_android_gms_wearable_internal_zzcc) throws RemoteException;
}
