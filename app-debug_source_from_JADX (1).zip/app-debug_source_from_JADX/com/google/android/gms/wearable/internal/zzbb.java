package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzbb implements Creator<zzbc> {
    static void zza(zzbc com_google_android_gms_wearable_internal_zzbc, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzbc.statusCode);
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzbc.zzbUw);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzle(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpG(i);
    }

    public zzbc zzle(Parcel parcel) {
        boolean z = false;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzbc(i, z);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzbc[] zzpG(int i) {
        return new zzbc[i];
    }
}
