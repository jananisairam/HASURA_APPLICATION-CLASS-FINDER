package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.internal.zzabh;
import com.google.android.gms.wearable.Channel;
import com.google.android.gms.wearable.Channel.GetInputStreamResult;
import com.google.android.gms.wearable.Channel.GetOutputStreamResult;
import com.google.android.gms.wearable.ChannelApi;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class zzu extends com.google.android.gms.common.internal.safeparcel.zza implements Channel {
    public static final Creator<zzu> CREATOR = new zzv();
    private final String mPath;
    private final String zzaiJ;
    private final String zzbSS;

    class C17977 implements zza<ChannelListener> {
        final /* synthetic */ String zzaiD;
        final /* synthetic */ IntentFilter[] zzbTK;

        C17977(String str, IntentFilter[] intentFilterArr) {
            this.zzaiD = str;
            this.zzbTK = intentFilterArr;
        }

        public void zza(zzcx com_google_android_gms_wearable_internal_zzcx, com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status, ChannelListener channelListener, zzabh<ChannelListener> com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_ChannelApi_ChannelListener) throws RemoteException {
            com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status, channelListener, (zzabh) com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_ChannelApi_ChannelListener, this.zzaiD, this.zzbTK);
        }
    }

    static final class zza implements GetInputStreamResult {
        private final Status zzair;
        private final InputStream zzbUb;

        zza(Status status, InputStream inputStream) {
            this.zzair = (Status) zzac.zzw(status);
            this.zzbUb = inputStream;
        }

        public InputStream getInputStream() {
            return this.zzbUb;
        }

        public Status getStatus() {
            return this.zzair;
        }

        public void release() {
            if (this.zzbUb != null) {
                try {
                    this.zzbUb.close();
                } catch (IOException e) {
                }
            }
        }
    }

    static final class zzb implements GetOutputStreamResult {
        private final Status zzair;
        private final OutputStream zzbUc;

        zzb(Status status, OutputStream outputStream) {
            this.zzair = (Status) zzac.zzw(status);
            this.zzbUc = outputStream;
        }

        public OutputStream getOutputStream() {
            return this.zzbUc;
        }

        public Status getStatus() {
            return this.zzair;
        }

        public void release() {
            if (this.zzbUc != null) {
                try {
                    this.zzbUc.close();
                } catch (IOException e) {
                }
            }
        }
    }

    public zzu(String str, String str2, String str3) {
        this.zzaiJ = (String) zzac.zzw(str);
        this.zzbSS = (String) zzac.zzw(str2);
        this.mPath = (String) zzac.zzw(str3);
    }

    private static zza<ChannelListener> zza(String str, IntentFilter[] intentFilterArr) {
        return new C17977(str, intentFilterArr);
    }

    public PendingResult<Status> addListener(GoogleApiClient googleApiClient, ChannelListener channelListener) {
        return zzb.zza(googleApiClient, zza(this.zzaiJ, new IntentFilter[]{zzcv.zzip(ChannelApi.ACTION_CHANNEL_EVENT)}), channelListener);
    }

    public PendingResult<Status> close(GoogleApiClient googleApiClient) {
        return googleApiClient.zza(new zzm<Status>(this, googleApiClient) {
            final /* synthetic */ zzu zzbTX;

            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zzx(this, this.zzbTX.zzaiJ);
            }

            protected Status zzb(Status status) {
                return status;
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzb(status);
            }
        });
    }

    public PendingResult<Status> close(GoogleApiClient googleApiClient, final int i) {
        return googleApiClient.zza(new zzm<Status>(this, googleApiClient) {
            final /* synthetic */ zzu zzbTX;

            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zzi(this, this.zzbTX.zzaiJ, i);
            }

            protected Status zzb(Status status) {
                return status;
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzb(status);
            }
        });
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzu)) {
            return false;
        }
        zzu com_google_android_gms_wearable_internal_zzu = (zzu) obj;
        return this.zzaiJ.equals(com_google_android_gms_wearable_internal_zzu.zzaiJ) && zzaa.equal(com_google_android_gms_wearable_internal_zzu.zzbSS, this.zzbSS) && zzaa.equal(com_google_android_gms_wearable_internal_zzu.mPath, this.mPath);
    }

    public PendingResult<GetInputStreamResult> getInputStream(GoogleApiClient googleApiClient) {
        return googleApiClient.zza(new zzm<GetInputStreamResult>(this, googleApiClient) {
            final /* synthetic */ zzu zzbTX;

            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zzy(this, this.zzbTX.zzaiJ);
            }

            public GetInputStreamResult zzbU(Status status) {
                return new zza(status, null);
            }

            public /* synthetic */ Result zzc(Status status) {
                return zzbU(status);
            }
        });
    }

    public String getNodeId() {
        return this.zzbSS;
    }

    public PendingResult<GetOutputStreamResult> getOutputStream(GoogleApiClient googleApiClient) {
        return googleApiClient.zza(new zzm<GetOutputStreamResult>(this, googleApiClient) {
            final /* synthetic */ zzu zzbTX;

            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zzz(this, this.zzbTX.zzaiJ);
            }

            public GetOutputStreamResult zzbV(Status status) {
                return new zzb(status, null);
            }

            public /* synthetic */ Result zzc(Status status) {
                return zzbV(status);
            }
        });
    }

    public String getPath() {
        return this.mPath;
    }

    public String getToken() {
        return this.zzaiJ;
    }

    public int hashCode() {
        return this.zzaiJ.hashCode();
    }

    public PendingResult<Status> receiveFile(GoogleApiClient googleApiClient, final Uri uri, final boolean z) {
        zzac.zzb(googleApiClient, "client is null");
        zzac.zzb(uri, "uri is null");
        return googleApiClient.zza(new zzm<Status>(this, googleApiClient) {
            final /* synthetic */ zzu zzbTX;

            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) this, this.zzbTX.zzaiJ, uri, z);
            }

            public Status zzb(Status status) {
                return status;
            }

            public /* synthetic */ Result zzc(Status status) {
                return zzb(status);
            }
        });
    }

    public PendingResult<Status> removeListener(GoogleApiClient googleApiClient, ChannelListener channelListener) {
        zzac.zzb(googleApiClient, "client is null");
        zzac.zzb(channelListener, "listener is null");
        return googleApiClient.zza(new zzb(googleApiClient, channelListener, this.zzaiJ));
    }

    public PendingResult<Status> sendFile(GoogleApiClient googleApiClient, Uri uri) {
        return sendFile(googleApiClient, uri, 0, -1);
    }

    public PendingResult<Status> sendFile(GoogleApiClient googleApiClient, Uri uri, long j, long j2) {
        zzac.zzb(googleApiClient, "client is null");
        zzac.zzb(this.zzaiJ, "token is null");
        zzac.zzb(uri, "uri is null");
        zzac.zzb(j >= 0, "startOffset is negative: %s", new Object[]{Long.valueOf(j)});
        boolean z = j2 >= 0 || j2 == -1;
        zzac.zzb(z, "invalid length: %s", new Object[]{Long.valueOf(j2)});
        final Uri uri2 = uri;
        final long j3 = j;
        final long j4 = j2;
        return googleApiClient.zza(new zzm<Status>(this, googleApiClient) {
            final /* synthetic */ zzu zzbTX;

            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) this, this.zzbTX.zzaiJ, uri2, j3, j4);
            }

            public Status zzb(Status status) {
                return status;
            }

            public /* synthetic */ Result zzc(Status status) {
                return zzb(status);
            }
        });
    }

    public String toString() {
        String str = this.zzaiJ;
        String str2 = this.zzbSS;
        String str3 = this.mPath;
        return new StringBuilder(((String.valueOf(str).length() + 43) + String.valueOf(str2).length()) + String.valueOf(str3).length()).append("ChannelImpl{, token='").append(str).append("'").append(", nodeId='").append(str2).append("'").append(", path='").append(str3).append("'").append("}").toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzv.zza(this, parcel, i);
    }
}
