package com.google.android.gms.wearable.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.internal.zzabh;

final class zzb<T> extends zzm<Status> {
    private T mListener;
    private zzabh<T> zzaDf;
    private zza<T> zzbTw;

    interface zza<T> {
        void zza(zzcx com_google_android_gms_wearable_internal_zzcx, com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status, T t, zzabh<T> com_google_android_gms_internal_zzabh_T) throws RemoteException;
    }

    private zzb(GoogleApiClient googleApiClient, T t, zzabh<T> com_google_android_gms_internal_zzabh_T, zza<T> com_google_android_gms_wearable_internal_zzb_zza_T) {
        super(googleApiClient);
        this.mListener = zzac.zzw(t);
        this.zzaDf = (zzabh) zzac.zzw(com_google_android_gms_internal_zzabh_T);
        this.zzbTw = (zza) zzac.zzw(com_google_android_gms_wearable_internal_zzb_zza_T);
    }

    static <T> PendingResult<Status> zza(GoogleApiClient googleApiClient, zza<T> com_google_android_gms_wearable_internal_zzb_zza_T, T t) {
        return googleApiClient.zza(new zzb(googleApiClient, t, googleApiClient.zzr(t), com_google_android_gms_wearable_internal_zzb_zza_T));
    }

    protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
        this.zzbTw.zza(com_google_android_gms_wearable_internal_zzcx, this, this.mListener, this.zzaDf);
        this.mListener = null;
        this.zzaDf = null;
    }

    protected Status zzb(Status status) {
        this.mListener = null;
        this.zzaDf = null;
        return status;
    }

    protected /* synthetic */ Result zzc(Status status) {
        return zzb(status);
    }
}
