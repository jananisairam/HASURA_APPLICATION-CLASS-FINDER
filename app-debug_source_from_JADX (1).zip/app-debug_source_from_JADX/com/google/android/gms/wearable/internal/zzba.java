package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzba implements Creator<zzaz> {
    static void zza(zzaz com_google_android_gms_wearable_internal_zzaz, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzaz.statusCode);
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzaz.zzbUv, i, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzld(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpF(i);
    }

    public zzaz zzld(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        ParcelFileDescriptor parcelFileDescriptor = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    parcelFileDescriptor = (ParcelFileDescriptor) zzb.zza(parcel, zzaX, ParcelFileDescriptor.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzaz(i, parcelFileDescriptor);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzaz[] zzpF(int i) {
        return new zzaz[i];
    }
}
