package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import java.util.List;

public class zzau implements Creator<zzat> {
    static void zza(zzat com_google_android_gms_wearable_internal_zzat, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzat.statusCode);
        zzc.zzc(parcel, 3, com_google_android_gms_wearable_internal_zzat.zzbUt, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzla(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpC(i);
    }

    public zzat zzla(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        List list = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    list = zzb.zzc(parcel, zzaX, zzo.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzat(i, list);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzat[] zzpC(int i) {
        return new zzat[i];
    }
}
