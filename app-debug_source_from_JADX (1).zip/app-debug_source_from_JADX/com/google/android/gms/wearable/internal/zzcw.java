package com.google.android.gms.wearable.internal;

import android.os.ParcelFileDescriptor.AutoCloseInputStream;
import android.os.ParcelFileDescriptor.AutoCloseOutputStream;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.wearable.CapabilityApi.AddLocalCapabilityResult;
import com.google.android.gms.wearable.CapabilityApi.GetAllCapabilitiesResult;
import com.google.android.gms.wearable.CapabilityApi.GetCapabilityResult;
import com.google.android.gms.wearable.CapabilityApi.RemoveLocalCapabilityResult;
import com.google.android.gms.wearable.CapabilityInfo;
import com.google.android.gms.wearable.Channel.GetInputStreamResult;
import com.google.android.gms.wearable.Channel.GetOutputStreamResult;
import com.google.android.gms.wearable.ChannelApi.OpenChannelResult;
import com.google.android.gms.wearable.DataApi.DataItemResult;
import com.google.android.gms.wearable.DataApi.DeleteDataItemsResult;
import com.google.android.gms.wearable.DataApi.GetFdForAssetResult;
import com.google.android.gms.wearable.DataItemBuffer;
import com.google.android.gms.wearable.MessageApi.SendMessageResult;
import com.google.android.gms.wearable.NodeApi$GetConnectedNodesResult;
import com.google.android.gms.wearable.NodeApi$GetLocalNodeResult;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.FutureTask;

final class zzcw {

    static abstract class zzb<T> extends zza {
        private com.google.android.gms.internal.zzaad.zzb<T> zzahW;

        public zzb(com.google.android.gms.internal.zzaad.zzb<T> com_google_android_gms_internal_zzaad_zzb_T) {
            this.zzahW = com_google_android_gms_internal_zzaad_zzb_T;
        }

        public void zzaa(T t) {
            com.google.android.gms.internal.zzaad.zzb com_google_android_gms_internal_zzaad_zzb = this.zzahW;
            if (com_google_android_gms_internal_zzaad_zzb != null) {
                com_google_android_gms_internal_zzaad_zzb.setResult(t);
                this.zzahW = null;
            }
        }
    }

    static final class zza extends zzb<AddLocalCapabilityResult> {
        public zza(com.google.android.gms.internal.zzaad.zzb<AddLocalCapabilityResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_CapabilityApi_AddLocalCapabilityResult) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_CapabilityApi_AddLocalCapabilityResult);
        }

        public void zza(zze com_google_android_gms_wearable_internal_zze) {
            zzaa(new com.google.android.gms.wearable.internal.zzn.zza(zzcr.zzik(com_google_android_gms_wearable_internal_zze.statusCode)));
        }
    }

    static final class zzc extends zzb<Status> {
        public zzc(com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status);
        }

        public void zza(zzae com_google_android_gms_wearable_internal_zzae) {
            zzaa(new Status(com_google_android_gms_wearable_internal_zzae.statusCode));
        }
    }

    static final class zzd extends zzb<Status> {
        public zzd(com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status);
        }

        public void zzb(zzae com_google_android_gms_wearable_internal_zzae) {
            zzaa(new Status(com_google_android_gms_wearable_internal_zzae.statusCode));
        }
    }

    static final class zze extends zzb<DeleteDataItemsResult> {
        public zze(com.google.android.gms.internal.zzaad.zzb<DeleteDataItemsResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_DataApi_DeleteDataItemsResult) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_DataApi_DeleteDataItemsResult);
        }

        public void zza(zzar com_google_android_gms_wearable_internal_zzar) {
            zzaa(new com.google.android.gms.wearable.internal.zzah.zzb(zzcr.zzik(com_google_android_gms_wearable_internal_zzar.statusCode), com_google_android_gms_wearable_internal_zzar.zzbUs));
        }
    }

    static final class zzf extends zzb<GetAllCapabilitiesResult> {
        public zzf(com.google.android.gms.internal.zzaad.zzb<GetAllCapabilitiesResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_CapabilityApi_GetAllCapabilitiesResult) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_CapabilityApi_GetAllCapabilitiesResult);
        }

        public void zza(zzat com_google_android_gms_wearable_internal_zzat) {
            zzaa(new com.google.android.gms.wearable.internal.zzn.zzd(zzcr.zzik(com_google_android_gms_wearable_internal_zzat.statusCode), zzcw.zzS(com_google_android_gms_wearable_internal_zzat.zzbUt)));
        }
    }

    static final class zzg extends zzb<GetCapabilityResult> {
        public zzg(com.google.android.gms.internal.zzaad.zzb<GetCapabilityResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_CapabilityApi_GetCapabilityResult) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_CapabilityApi_GetCapabilityResult);
        }

        public void zza(zzav com_google_android_gms_wearable_internal_zzav) {
            zzaa(new com.google.android.gms.wearable.internal.zzn.zze(zzcr.zzik(com_google_android_gms_wearable_internal_zzav.statusCode), new com.google.android.gms.wearable.internal.zzn.zzc(com_google_android_gms_wearable_internal_zzav.zzbUu)));
        }
    }

    static final class zzh extends zzb<GetInputStreamResult> {
        private final zzac zzbUS;

        public zzh(com.google.android.gms.internal.zzaad.zzb<GetInputStreamResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_Channel_GetInputStreamResult, zzac com_google_android_gms_wearable_internal_zzac) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_Channel_GetInputStreamResult);
            this.zzbUS = (zzac) zzac.zzw(com_google_android_gms_wearable_internal_zzac);
        }

        public void zza(zzax com_google_android_gms_wearable_internal_zzax) {
            InputStream inputStream = null;
            if (com_google_android_gms_wearable_internal_zzax.zzbUv != null) {
                inputStream = new zzw(new AutoCloseInputStream(com_google_android_gms_wearable_internal_zzax.zzbUv));
                this.zzbUS.zza(inputStream.zzUu());
            }
            zzaa(new zza(new Status(com_google_android_gms_wearable_internal_zzax.statusCode), inputStream));
        }
    }

    static final class zzi extends zzb<GetOutputStreamResult> {
        private final zzac zzbUS;

        public zzi(com.google.android.gms.internal.zzaad.zzb<GetOutputStreamResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_Channel_GetOutputStreamResult, zzac com_google_android_gms_wearable_internal_zzac) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_Channel_GetOutputStreamResult);
            this.zzbUS = (zzac) zzac.zzw(com_google_android_gms_wearable_internal_zzac);
        }

        public void zza(zzaz com_google_android_gms_wearable_internal_zzaz) {
            OutputStream outputStream = null;
            if (com_google_android_gms_wearable_internal_zzaz.zzbUv != null) {
                outputStream = new zzx(new AutoCloseOutputStream(com_google_android_gms_wearable_internal_zzaz.zzbUv));
                this.zzbUS.zza(outputStream.zzUu());
            }
            zzaa(new zzb(new Status(com_google_android_gms_wearable_internal_zzaz.statusCode), outputStream));
        }
    }

    static final class zzj extends zzb<NodeApi$GetConnectedNodesResult> {
        public zzj(com.google.android.gms.internal.zzaad.zzb<NodeApi$GetConnectedNodesResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_NodeApi_GetConnectedNodesResult) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_NodeApi_GetConnectedNodesResult);
        }

        public void zza(zzbl com_google_android_gms_wearable_internal_zzbl) {
            List arrayList = new ArrayList();
            arrayList.addAll(com_google_android_gms_wearable_internal_zzbl.zzbUB);
            zzaa(new com.google.android.gms.wearable.internal.zzcb.zza(zzcr.zzik(com_google_android_gms_wearable_internal_zzbl.statusCode), arrayList));
        }
    }

    static final class zzk extends zzb<DataItemResult> {
        public zzk(com.google.android.gms.internal.zzaad.zzb<DataItemResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_DataApi_DataItemResult) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_DataApi_DataItemResult);
        }

        public void zza(zzbn com_google_android_gms_wearable_internal_zzbn) {
            zzaa(new com.google.android.gms.wearable.internal.zzah.zza(zzcr.zzik(com_google_android_gms_wearable_internal_zzbn.statusCode), com_google_android_gms_wearable_internal_zzbn.zzbUC));
        }
    }

    static final class zzl extends zzb<DataItemBuffer> {
        public zzl(com.google.android.gms.internal.zzaad.zzb<DataItemBuffer> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_DataItemBuffer) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_DataItemBuffer);
        }

        public void zzar(DataHolder dataHolder) {
            zzaa(new DataItemBuffer(dataHolder));
        }
    }

    static final class zzm extends zzb<GetFdForAssetResult> {
        public zzm(com.google.android.gms.internal.zzaad.zzb<GetFdForAssetResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_DataApi_GetFdForAssetResult) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_DataApi_GetFdForAssetResult);
        }

        public void zza(zzbp com_google_android_gms_wearable_internal_zzbp) {
            zzaa(new com.google.android.gms.wearable.internal.zzah.zzc(zzcr.zzik(com_google_android_gms_wearable_internal_zzbp.statusCode), com_google_android_gms_wearable_internal_zzbp.zzbyd));
        }
    }

    static final class zzn extends zzb<NodeApi$GetLocalNodeResult> {
        public zzn(com.google.android.gms.internal.zzaad.zzb<NodeApi$GetLocalNodeResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_NodeApi_GetLocalNodeResult) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_NodeApi_GetLocalNodeResult);
        }

        public void zza(zzbr com_google_android_gms_wearable_internal_zzbr) {
            zzaa(new com.google.android.gms.wearable.internal.zzcb.zzb(zzcr.zzik(com_google_android_gms_wearable_internal_zzbr.statusCode), com_google_android_gms_wearable_internal_zzbr.zzbUD));
        }
    }

    static final class zzo extends zza {
        zzo() {
        }

        public void zza(Status status) {
        }
    }

    static final class zzp extends zzb<OpenChannelResult> {
        public zzp(com.google.android.gms.internal.zzaad.zzb<OpenChannelResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_ChannelApi_OpenChannelResult) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_ChannelApi_OpenChannelResult);
        }

        public void zza(zzce com_google_android_gms_wearable_internal_zzce) {
            zzaa(new zza(zzcr.zzik(com_google_android_gms_wearable_internal_zzce.statusCode), com_google_android_gms_wearable_internal_zzce.zzbTW));
        }
    }

    static final class zzq extends zzb<DataItemResult> {
        private final List<FutureTask<Boolean>> zzIz;

        zzq(com.google.android.gms.internal.zzaad.zzb<DataItemResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_DataApi_DataItemResult, List<FutureTask<Boolean>> list) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_DataApi_DataItemResult);
            this.zzIz = list;
        }

        public void zza(zzci com_google_android_gms_wearable_internal_zzci) {
            zzaa(new com.google.android.gms.wearable.internal.zzah.zza(zzcr.zzik(com_google_android_gms_wearable_internal_zzci.statusCode), com_google_android_gms_wearable_internal_zzci.zzbUC));
            if (com_google_android_gms_wearable_internal_zzci.statusCode != 0) {
                for (FutureTask cancel : this.zzIz) {
                    cancel.cancel(true);
                }
            }
        }
    }

    static final class zzr extends zzb<Status> {
        public zzr(com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status);
        }

        public void zza(zzaa com_google_android_gms_wearable_internal_zzaa) {
            zzaa(new Status(com_google_android_gms_wearable_internal_zzaa.statusCode));
        }
    }

    static final class zzs extends zzb<RemoveLocalCapabilityResult> {
        public zzs(com.google.android.gms.internal.zzaad.zzb<RemoveLocalCapabilityResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_CapabilityApi_RemoveLocalCapabilityResult) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_CapabilityApi_RemoveLocalCapabilityResult);
        }

        public void zza(zzcm com_google_android_gms_wearable_internal_zzcm) {
            zzaa(new com.google.android.gms.wearable.internal.zzn.zza(zzcr.zzik(com_google_android_gms_wearable_internal_zzcm.statusCode)));
        }
    }

    static final class zzt extends zzb<SendMessageResult> {
        public zzt(com.google.android.gms.internal.zzaad.zzb<SendMessageResult> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_MessageApi_SendMessageResult) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_wearable_MessageApi_SendMessageResult);
        }

        public void zza(zzco com_google_android_gms_wearable_internal_zzco) {
            zzaa(new com.google.android.gms.wearable.internal.zzby.zzb(zzcr.zzik(com_google_android_gms_wearable_internal_zzco.statusCode), com_google_android_gms_wearable_internal_zzco.zzbhU));
        }
    }

    static final class zzu extends zzb<Status> {
        public zzu(com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status);
        }

        public void zza(zzy com_google_android_gms_wearable_internal_zzy) {
            zzaa(new Status(com_google_android_gms_wearable_internal_zzy.statusCode));
        }
    }

    private static Map<String, CapabilityInfo> zzS(List<zzo> list) {
        Map hashMap = new HashMap(list.size() * 2);
        for (zzo com_google_android_gms_wearable_internal_zzo : list) {
            hashMap.put(com_google_android_gms_wearable_internal_zzo.getName(), new com.google.android.gms.wearable.internal.zzn.zzc(com_google_android_gms_wearable_internal_zzo));
        }
        return hashMap;
    }
}
