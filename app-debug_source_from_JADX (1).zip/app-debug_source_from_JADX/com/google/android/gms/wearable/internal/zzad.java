package com.google.android.gms.wearable.internal;

interface zzad {
    void zzb(zzr com_google_android_gms_wearable_internal_zzr);
}
