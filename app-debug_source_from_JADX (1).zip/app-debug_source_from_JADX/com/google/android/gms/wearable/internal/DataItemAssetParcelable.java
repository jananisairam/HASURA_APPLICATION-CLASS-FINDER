package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.wearable.DataItemAsset;

@KeepName
public class DataItemAssetParcelable extends zza implements ReflectedParcelable, DataItemAsset {
    public static final Creator<DataItemAssetParcelable> CREATOR = new zzal();
    private final String zzAX;
    private final String zzGV;

    public DataItemAssetParcelable(DataItemAsset dataItemAsset) {
        this.zzGV = (String) zzac.zzw(dataItemAsset.getId());
        this.zzAX = (String) zzac.zzw(dataItemAsset.getDataItemKey());
    }

    DataItemAssetParcelable(String str, String str2) {
        this.zzGV = str;
        this.zzAX = str2;
    }

    public /* synthetic */ Object freeze() {
        return zzUw();
    }

    public String getDataItemKey() {
        return this.zzAX;
    }

    public String getId() {
        return this.zzGV;
    }

    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DataItemAssetParcelable[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.zzGV == null) {
            stringBuilder.append(",noid");
        } else {
            stringBuilder.append(",");
            stringBuilder.append(this.zzGV);
        }
        stringBuilder.append(", key=");
        stringBuilder.append(this.zzAX);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzal.zza(this, parcel, i);
    }

    public DataItemAsset zzUw() {
        return this;
    }
}
