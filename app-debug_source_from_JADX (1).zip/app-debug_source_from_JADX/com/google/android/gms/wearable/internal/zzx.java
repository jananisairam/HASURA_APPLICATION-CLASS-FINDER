package com.google.android.gms.wearable.internal;

import android.util.Log;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.wearable.ChannelIOException;
import java.io.IOException;
import java.io.OutputStream;

public final class zzx extends OutputStream {
    private volatile zzr zzbUe;
    private final OutputStream zzbUg;

    class C17991 implements zzad {
        final /* synthetic */ zzx zzbUh;

        C17991(zzx com_google_android_gms_wearable_internal_zzx) {
            this.zzbUh = com_google_android_gms_wearable_internal_zzx;
        }

        public void zzb(zzr com_google_android_gms_wearable_internal_zzr) {
            this.zzbUh.zzc(com_google_android_gms_wearable_internal_zzr);
        }
    }

    public zzx(OutputStream outputStream) {
        this.zzbUg = (OutputStream) zzac.zzw(outputStream);
    }

    private IOException zza(IOException iOException) {
        zzr com_google_android_gms_wearable_internal_zzr = this.zzbUe;
        if (com_google_android_gms_wearable_internal_zzr == null) {
            return iOException;
        }
        if (Log.isLoggable("ChannelOutputStream", 2)) {
            Log.v("ChannelOutputStream", "Caught IOException, but channel has been closed. Translating to ChannelIOException.", iOException);
        }
        return new ChannelIOException("Channel closed unexpectedly before stream was finished", com_google_android_gms_wearable_internal_zzr.zzbTU, com_google_android_gms_wearable_internal_zzr.zzbTV);
    }

    public void close() throws IOException {
        try {
            this.zzbUg.close();
        } catch (IOException e) {
            throw zza(e);
        }
    }

    public void flush() throws IOException {
        try {
            this.zzbUg.flush();
        } catch (IOException e) {
            throw zza(e);
        }
    }

    public void write(int i) throws IOException {
        try {
            this.zzbUg.write(i);
        } catch (IOException e) {
            throw zza(e);
        }
    }

    public void write(byte[] bArr) throws IOException {
        try {
            this.zzbUg.write(bArr);
        } catch (IOException e) {
            throw zza(e);
        }
    }

    public void write(byte[] bArr, int i, int i2) throws IOException {
        try {
            this.zzbUg.write(bArr, i, i2);
        } catch (IOException e) {
            throw zza(e);
        }
    }

    zzad zzUu() {
        return new C17991(this);
    }

    void zzc(zzr com_google_android_gms_wearable_internal_zzr) {
        this.zzbUe = com_google_android_gms_wearable_internal_zzr;
    }
}
