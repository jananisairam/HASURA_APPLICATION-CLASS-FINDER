package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzi implements Creator<zzh> {
    static void zza(zzh com_google_android_gms_wearable_internal_zzh, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, com_google_android_gms_wearable_internal_zzh.zzUk());
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzh.zzUl());
        zzc.zza(parcel, 4, com_google_android_gms_wearable_internal_zzh.getValue(), false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzkP(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpo(i);
    }

    public zzh zzkP(Parcel parcel) {
        byte b = (byte) 0;
        int zzaY = zzb.zzaY(parcel);
        String str = null;
        byte b2 = (byte) 0;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    b2 = zzb.zze(parcel, zzaX);
                    break;
                case 3:
                    b = zzb.zze(parcel, zzaX);
                    break;
                case 4:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzh(b2, b, str);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzh[] zzpo(int i) {
        return new zzh[i];
    }
}
