package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zzck extends zza {
    public static final Creator<zzck> CREATOR = new zzcl();
    final int zzaiI;
    public final zzbv zzbTx;

    zzck(int i, IBinder iBinder) {
        this.zzaiI = i;
        if (iBinder != null) {
            this.zzbTx = zzbv.zza.zzfC(iBinder);
        } else {
            this.zzbTx = null;
        }
    }

    public zzck(zzbv com_google_android_gms_wearable_internal_zzbv) {
        this.zzaiI = 1;
        this.zzbTx = com_google_android_gms_wearable_internal_zzbv;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzcl.zza(this, parcel, i);
    }

    IBinder zzAh() {
        return this.zzbTx == null ? null : this.zzbTx.asBinder();
    }
}
