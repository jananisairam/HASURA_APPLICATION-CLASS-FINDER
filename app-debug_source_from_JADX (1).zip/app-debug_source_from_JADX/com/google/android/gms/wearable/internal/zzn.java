package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.net.Uri;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.internal.zzabh;
import com.google.android.gms.wearable.CapabilityApi;
import com.google.android.gms.wearable.CapabilityApi.AddLocalCapabilityResult;
import com.google.android.gms.wearable.CapabilityApi.CapabilityListener;
import com.google.android.gms.wearable.CapabilityApi.GetAllCapabilitiesResult;
import com.google.android.gms.wearable.CapabilityApi.GetCapabilityResult;
import com.google.android.gms.wearable.CapabilityApi.RemoveLocalCapabilityResult;
import com.google.android.gms.wearable.CapabilityInfo;
import com.google.android.gms.wearable.Node;
import java.util.Map;
import java.util.Set;

public class zzn implements CapabilityApi {

    class C17885 implements zza<CapabilityListener> {
        final /* synthetic */ IntentFilter[] zzbTK;

        C17885(IntentFilter[] intentFilterArr) {
            this.zzbTK = intentFilterArr;
        }

        public void zza(zzcx com_google_android_gms_wearable_internal_zzcx, com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status, CapabilityListener capabilityListener, zzabh<CapabilityListener> com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_CapabilityApi_CapabilityListener) throws RemoteException {
            com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status, capabilityListener, (zzabh) com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_CapabilityApi_CapabilityListener, this.zzbTK);
        }
    }

    public static class zza implements AddLocalCapabilityResult, RemoveLocalCapabilityResult {
        private final Status zzair;

        public zza(Status status) {
            this.zzair = status;
        }

        public Status getStatus() {
            return this.zzair;
        }
    }

    private static class zzb implements CapabilityListener {
        final CapabilityListener zzbTL;
        final String zzbTM;

        zzb(CapabilityListener capabilityListener, String str) {
            this.zzbTL = capabilityListener;
            this.zzbTM = str;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            zzb com_google_android_gms_wearable_internal_zzn_zzb = (zzb) obj;
            return this.zzbTL.equals(com_google_android_gms_wearable_internal_zzn_zzb.zzbTL) ? this.zzbTM.equals(com_google_android_gms_wearable_internal_zzn_zzb.zzbTM) : false;
        }

        public int hashCode() {
            return (this.zzbTL.hashCode() * 31) + this.zzbTM.hashCode();
        }

        public void onCapabilityChanged(CapabilityInfo capabilityInfo) {
            this.zzbTL.onCapabilityChanged(capabilityInfo);
        }
    }

    public static class zzc implements CapabilityInfo {
        private final String mName;
        private final Set<Node> zzbTN;

        public zzc(CapabilityInfo capabilityInfo) {
            this(capabilityInfo.getName(), capabilityInfo.getNodes());
        }

        public zzc(String str, Set<Node> set) {
            this.mName = str;
            this.zzbTN = set;
        }

        public String getName() {
            return this.mName;
        }

        public Set<Node> getNodes() {
            return this.zzbTN;
        }
    }

    public static class zzd implements GetAllCapabilitiesResult {
        private final Status zzair;
        private final Map<String, CapabilityInfo> zzbTO;

        public zzd(Status status, Map<String, CapabilityInfo> map) {
            this.zzair = status;
            this.zzbTO = map;
        }

        public Map<String, CapabilityInfo> getAllCapabilities() {
            return this.zzbTO;
        }

        public Status getStatus() {
            return this.zzair;
        }
    }

    public static class zze implements GetCapabilityResult {
        private final Status zzair;
        private final CapabilityInfo zzbTP;

        public zze(Status status, CapabilityInfo capabilityInfo) {
            this.zzair = status;
            this.zzbTP = capabilityInfo;
        }

        public CapabilityInfo getCapability() {
            return this.zzbTP;
        }

        public Status getStatus() {
            return this.zzair;
        }
    }

    private static final class zzf extends zzm<Status> {
        private CapabilityListener zzbTL;

        private zzf(GoogleApiClient googleApiClient, CapabilityListener capabilityListener) {
            super(googleApiClient);
            this.zzbTL = capabilityListener;
        }

        protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
            com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) this, this.zzbTL);
            this.zzbTL = null;
        }

        public Status zzb(Status status) {
            this.zzbTL = null;
            return status;
        }

        public /* synthetic */ Result zzc(Status status) {
            return zzb(status);
        }
    }

    private PendingResult<Status> zza(GoogleApiClient googleApiClient, CapabilityListener capabilityListener, IntentFilter[] intentFilterArr) {
        return zzb.zza(googleApiClient, zza(intentFilterArr), capabilityListener);
    }

    private static zza<CapabilityListener> zza(IntentFilter[] intentFilterArr) {
        return new C17885(intentFilterArr);
    }

    public PendingResult<Status> addCapabilityListener(GoogleApiClient googleApiClient, CapabilityListener capabilityListener, String str) {
        String str2;
        zzac.zzb(str != null, "capability must not be null");
        CapabilityListener com_google_android_gms_wearable_internal_zzn_zzb = new zzb(capabilityListener, str);
        IntentFilter zzip = zzcv.zzip(CapabilityApi.ACTION_CAPABILITY_CHANGED);
        if (str.startsWith("/")) {
            str2 = str;
        } else {
            String str3 = "/";
            str2 = String.valueOf(str);
            str2 = str2.length() != 0 ? str3.concat(str2) : new String(str3);
        }
        zzip.addDataPath(str2, 0);
        return zza(googleApiClient, com_google_android_gms_wearable_internal_zzn_zzb, new IntentFilter[]{zzip});
    }

    public PendingResult<Status> addListener(GoogleApiClient googleApiClient, CapabilityListener capabilityListener, Uri uri, int i) {
        zzac.zzb(uri != null, "uri must not be null");
        boolean z = i == 0 || i == 1;
        zzac.zzb(z, "invalid filter type");
        return zza(googleApiClient, capabilityListener, new IntentFilter[]{zzcv.zza(CapabilityApi.ACTION_CAPABILITY_CHANGED, uri, i)});
    }

    public PendingResult<AddLocalCapabilityResult> addLocalCapability(GoogleApiClient googleApiClient, final String str) {
        return googleApiClient.zza(new zzm<AddLocalCapabilityResult>(this, googleApiClient) {
            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zzv(this, str);
            }

            protected AddLocalCapabilityResult zzbR(Status status) {
                return new zza(status);
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzbR(status);
            }
        });
    }

    public PendingResult<GetAllCapabilitiesResult> getAllCapabilities(GoogleApiClient googleApiClient, final int i) {
        boolean z = true;
        if (!(i == 0 || i == 1)) {
            z = false;
        }
        zzac.zzax(z);
        return googleApiClient.zza(new zzm<GetAllCapabilitiesResult>(this, googleApiClient) {
            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zzd(this, i);
            }

            protected GetAllCapabilitiesResult zzbQ(Status status) {
                return new zzd(status, null);
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzbQ(status);
            }
        });
    }

    public PendingResult<GetCapabilityResult> getCapability(GoogleApiClient googleApiClient, final String str, final int i) {
        boolean z = true;
        if (!(i == 0 || i == 1)) {
            z = false;
        }
        zzac.zzax(z);
        return googleApiClient.zza(new zzm<GetCapabilityResult>(this, googleApiClient) {
            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zzh(this, str, i);
            }

            protected GetCapabilityResult zzbP(Status status) {
                return new zze(status, null);
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzbP(status);
            }
        });
    }

    public PendingResult<Status> removeCapabilityListener(GoogleApiClient googleApiClient, CapabilityListener capabilityListener, String str) {
        return googleApiClient.zza(new zzf(googleApiClient, new zzb(capabilityListener, str)));
    }

    public PendingResult<Status> removeListener(GoogleApiClient googleApiClient, CapabilityListener capabilityListener) {
        return googleApiClient.zza(new zzf(googleApiClient, capabilityListener));
    }

    public PendingResult<RemoveLocalCapabilityResult> removeLocalCapability(GoogleApiClient googleApiClient, final String str) {
        return googleApiClient.zza(new zzm<RemoveLocalCapabilityResult>(this, googleApiClient) {
            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zzw(this, str);
            }

            protected RemoveLocalCapabilityResult zzbS(Status status) {
                return new zza(status);
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzbS(status);
            }
        });
    }
}
