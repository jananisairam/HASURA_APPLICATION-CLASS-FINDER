package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.wearable.Channel;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;

final class zzcq implements ChannelListener {
    private final String zzaiJ;
    private final ChannelListener zzbUQ;

    zzcq(String str, ChannelListener channelListener) {
        this.zzaiJ = (String) zzac.zzw(str);
        this.zzbUQ = (ChannelListener) zzac.zzw(channelListener);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzcq)) {
            return false;
        }
        zzcq com_google_android_gms_wearable_internal_zzcq = (zzcq) obj;
        return this.zzbUQ.equals(com_google_android_gms_wearable_internal_zzcq.zzbUQ) && this.zzaiJ.equals(com_google_android_gms_wearable_internal_zzcq.zzaiJ);
    }

    public int hashCode() {
        return (this.zzaiJ.hashCode() * 31) + this.zzbUQ.hashCode();
    }

    public void onChannelClosed(Channel channel, int i, int i2) {
        this.zzbUQ.onChannelClosed(channel, i, i2);
    }

    public void onChannelOpened(Channel channel) {
        this.zzbUQ.onChannelOpened(channel);
    }

    public void onInputClosed(Channel channel, int i, int i2) {
        this.zzbUQ.onInputClosed(channel, i, i2);
    }

    public void onOutputClosed(Channel channel, int i, int i2) {
        this.zzbUQ.onOutputClosed(channel, i, i2);
    }
}
