package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzl implements Creator<zzk> {
    static void zza(zzk com_google_android_gms_wearable_internal_zzk, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzk.getId());
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzk.zzke(), false);
        zzc.zza(parcel, 4, com_google_android_gms_wearable_internal_zzk.zzUm(), false);
        zzc.zza(parcel, 5, com_google_android_gms_wearable_internal_zzk.zzUn(), false);
        zzc.zza(parcel, 6, com_google_android_gms_wearable_internal_zzk.getTitle(), false);
        zzc.zza(parcel, 7, com_google_android_gms_wearable_internal_zzk.zzEv(), false);
        zzc.zza(parcel, 8, com_google_android_gms_wearable_internal_zzk.getDisplayName(), false);
        zzc.zza(parcel, 9, com_google_android_gms_wearable_internal_zzk.zzUo());
        zzc.zza(parcel, 10, com_google_android_gms_wearable_internal_zzk.zzUp());
        zzc.zza(parcel, 11, com_google_android_gms_wearable_internal_zzk.zzUq());
        zzc.zza(parcel, 12, com_google_android_gms_wearable_internal_zzk.zzUr());
        zzc.zza(parcel, 13, com_google_android_gms_wearable_internal_zzk.getPackageName(), false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzkQ(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpp(i);
    }

    public zzk zzkQ(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        byte b = (byte) 0;
        byte b2 = (byte) 0;
        byte b3 = (byte) 0;
        byte b4 = (byte) 0;
        String str7 = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 4:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 5:
                    str3 = zzb.zzq(parcel, zzaX);
                    break;
                case 6:
                    str4 = zzb.zzq(parcel, zzaX);
                    break;
                case 7:
                    str5 = zzb.zzq(parcel, zzaX);
                    break;
                case 8:
                    str6 = zzb.zzq(parcel, zzaX);
                    break;
                case 9:
                    b = zzb.zze(parcel, zzaX);
                    break;
                case 10:
                    b2 = zzb.zze(parcel, zzaX);
                    break;
                case 11:
                    b3 = zzb.zze(parcel, zzaX);
                    break;
                case 12:
                    b4 = zzb.zze(parcel, zzaX);
                    break;
                case 13:
                    str7 = zzb.zzq(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzk(i, str, str2, str3, str4, str5, str6, b, b2, b3, b4, str7);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzk[] zzpp(int i) {
        return new zzk[i];
    }
}
