package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import com.google.android.gms.wearable.ConnectionConfiguration;

public class zzbk implements Creator<zzbj> {
    static void zza(zzbj com_google_android_gms_wearable_internal_zzbj, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzbj.statusCode);
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzbj.zzbUA, i, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzli(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpK(i);
    }

    public zzbj zzli(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        ConnectionConfiguration[] connectionConfigurationArr = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    connectionConfigurationArr = (ConnectionConfiguration[]) zzb.zzb(parcel, zzaX, ConnectionConfiguration.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzbj(i, connectionConfigurationArr);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzbj[] zzpK(int i) {
        return new zzbj[i];
    }
}
