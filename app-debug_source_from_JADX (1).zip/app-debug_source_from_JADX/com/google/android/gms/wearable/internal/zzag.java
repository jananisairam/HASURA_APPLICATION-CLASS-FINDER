package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.zzf;

public final class zzag implements zzf {
}
