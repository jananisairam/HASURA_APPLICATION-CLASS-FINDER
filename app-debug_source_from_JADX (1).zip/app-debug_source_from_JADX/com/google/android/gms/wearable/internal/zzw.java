package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.wearable.ChannelIOException;
import java.io.IOException;
import java.io.InputStream;

public final class zzw extends InputStream {
    private final InputStream zzbUd;
    private volatile zzr zzbUe;

    class C17981 implements zzad {
        final /* synthetic */ zzw zzbUf;

        C17981(zzw com_google_android_gms_wearable_internal_zzw) {
            this.zzbUf = com_google_android_gms_wearable_internal_zzw;
        }

        public void zzb(zzr com_google_android_gms_wearable_internal_zzr) {
            this.zzbUf.zza(com_google_android_gms_wearable_internal_zzr);
        }
    }

    public zzw(InputStream inputStream) {
        this.zzbUd = (InputStream) zzac.zzw(inputStream);
    }

    private int zzpv(int i) throws ChannelIOException {
        if (i == -1) {
            zzr com_google_android_gms_wearable_internal_zzr = this.zzbUe;
            if (com_google_android_gms_wearable_internal_zzr != null) {
                throw new ChannelIOException("Channel closed unexpectedly before stream was finished", com_google_android_gms_wearable_internal_zzr.zzbTU, com_google_android_gms_wearable_internal_zzr.zzbTV);
            }
        }
        return i;
    }

    public int available() throws IOException {
        return this.zzbUd.available();
    }

    public void close() throws IOException {
        this.zzbUd.close();
    }

    public void mark(int i) {
        this.zzbUd.mark(i);
    }

    public boolean markSupported() {
        return this.zzbUd.markSupported();
    }

    public int read() throws IOException {
        return zzpv(this.zzbUd.read());
    }

    public int read(byte[] bArr) throws IOException {
        return zzpv(this.zzbUd.read(bArr));
    }

    public int read(byte[] bArr, int i, int i2) throws IOException {
        return zzpv(this.zzbUd.read(bArr, i, i2));
    }

    public void reset() throws IOException {
        this.zzbUd.reset();
    }

    public long skip(long j) throws IOException {
        return this.zzbUd.skip(j);
    }

    zzad zzUu() {
        return new C17981(this);
    }

    void zza(zzr com_google_android_gms_wearable_internal_zzr) {
        this.zzbUe = (zzr) zzac.zzw(com_google_android_gms_wearable_internal_zzr);
    }
}
