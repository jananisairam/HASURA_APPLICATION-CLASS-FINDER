package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zze extends zza {
    public static final Creator<zze> CREATOR = new zzf();
    public final int statusCode;

    public zze(int i) {
        this.statusCode = i;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzf.zza(this, parcel, i);
    }
}
