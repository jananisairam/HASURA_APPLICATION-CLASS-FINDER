package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzca implements Creator<zzbz> {
    static void zza(zzbz com_google_android_gms_wearable_internal_zzbz, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzbz.getRequestId());
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzbz.getPath(), false);
        zzc.zza(parcel, 4, com_google_android_gms_wearable_internal_zzbz.getData(), false);
        zzc.zza(parcel, 5, com_google_android_gms_wearable_internal_zzbz.getSourceNodeId(), false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzln(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpP(i);
    }

    public zzbz zzln(Parcel parcel) {
        String str = null;
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        byte[] bArr = null;
        String str2 = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 4:
                    bArr = zzb.zzt(parcel, zzaX);
                    break;
                case 5:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzbz(i, str2, bArr, str);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzbz[] zzpP(int i) {
        return new zzbz[i];
    }
}
