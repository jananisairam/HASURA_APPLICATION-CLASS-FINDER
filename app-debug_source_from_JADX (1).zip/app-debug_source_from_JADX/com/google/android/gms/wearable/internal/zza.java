package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;

public abstract class zza extends com.google.android.gms.wearable.internal.zzbu.zza {
    public void zza(Status status) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzaa com_google_android_gms_wearable_internal_zzaa) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzae com_google_android_gms_wearable_internal_zzae) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzar com_google_android_gms_wearable_internal_zzar) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzat com_google_android_gms_wearable_internal_zzat) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzav com_google_android_gms_wearable_internal_zzav) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzax com_google_android_gms_wearable_internal_zzax) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzaz com_google_android_gms_wearable_internal_zzaz) {
        throw new UnsupportedOperationException();
    }

    @Deprecated
    public void zza(zzbc com_google_android_gms_wearable_internal_zzbc) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzbe com_google_android_gms_wearable_internal_zzbe) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzbg com_google_android_gms_wearable_internal_zzbg) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzbh com_google_android_gms_wearable_internal_zzbh) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzbj com_google_android_gms_wearable_internal_zzbj) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzbl com_google_android_gms_wearable_internal_zzbl) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzbn com_google_android_gms_wearable_internal_zzbn) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzbp com_google_android_gms_wearable_internal_zzbp) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzbr com_google_android_gms_wearable_internal_zzbr) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzce com_google_android_gms_wearable_internal_zzce) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzci com_google_android_gms_wearable_internal_zzci) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzcm com_google_android_gms_wearable_internal_zzcm) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzco com_google_android_gms_wearable_internal_zzco) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzcs com_google_android_gms_wearable_internal_zzcs) {
        throw new UnsupportedOperationException();
    }

    public void zza(zze com_google_android_gms_wearable_internal_zze) {
        throw new UnsupportedOperationException();
    }

    public void zza(zzy com_google_android_gms_wearable_internal_zzy) {
        throw new UnsupportedOperationException();
    }

    public void zzar(DataHolder dataHolder) {
        throw new UnsupportedOperationException();
    }

    public void zzb(zzae com_google_android_gms_wearable_internal_zzae) {
        throw new UnsupportedOperationException();
    }
}
