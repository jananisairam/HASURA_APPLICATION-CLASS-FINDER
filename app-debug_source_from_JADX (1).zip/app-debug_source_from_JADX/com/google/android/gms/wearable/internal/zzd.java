package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzd implements Creator<zzc> {
    static void zza(zzc com_google_android_gms_wearable_internal_zzc, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, com_google_android_gms_wearable_internal_zzc.zzAh(), false);
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzc.zzbTy, i, false);
        zzc.zza(parcel, 4, com_google_android_gms_wearable_internal_zzc.zzbTz, false);
        zzc.zza(parcel, 5, com_google_android_gms_wearable_internal_zzc.zzbTA, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzkN(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpm(i);
    }

    public zzc zzkN(Parcel parcel) {
        String str = null;
        int zzaY = zzb.zzaY(parcel);
        String str2 = null;
        IntentFilter[] intentFilterArr = null;
        IBinder iBinder = null;
        while (parcel.dataPosition() < zzaY) {
            IntentFilter[] intentFilterArr2;
            IBinder zzr;
            String str3;
            int zzaX = zzb.zzaX(parcel);
            String str4;
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    str4 = str;
                    str = str2;
                    intentFilterArr2 = intentFilterArr;
                    zzr = zzb.zzr(parcel, zzaX);
                    str3 = str4;
                    break;
                case 3:
                    zzr = iBinder;
                    str4 = str2;
                    intentFilterArr2 = (IntentFilter[]) zzb.zzb(parcel, zzaX, IntentFilter.CREATOR);
                    str3 = str;
                    str = str4;
                    break;
                case 4:
                    intentFilterArr2 = intentFilterArr;
                    zzr = iBinder;
                    str4 = str;
                    str = zzb.zzq(parcel, zzaX);
                    str3 = str4;
                    break;
                case 5:
                    str3 = zzb.zzq(parcel, zzaX);
                    str = str2;
                    intentFilterArr2 = intentFilterArr;
                    zzr = iBinder;
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    str3 = str;
                    str = str2;
                    intentFilterArr2 = intentFilterArr;
                    zzr = iBinder;
                    break;
            }
            iBinder = zzr;
            intentFilterArr = intentFilterArr2;
            str2 = str;
            str = str3;
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzc(iBinder, intentFilterArr, str2, str);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzc[] zzpm(int i) {
        return new zzc[i];
    }
}
