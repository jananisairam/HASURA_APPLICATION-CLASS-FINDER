package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.api.Status;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

final class zzbx<T> {
    private final Map<T, zzcy<T>> zzaWg = new HashMap();

    private static class zza<T> extends zzb<Status> {
        private WeakReference<Map<T, zzcy<T>>> zzbUE;
        private WeakReference<T> zzbUF;

        zza(Map<T, zzcy<T>> map, T t, com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status);
            this.zzbUE = new WeakReference(map);
            this.zzbUF = new WeakReference(t);
        }

        public void zza(Status status) {
            Map map = (Map) this.zzbUE.get();
            Object obj = this.zzbUF.get();
            if (!(status.getStatus().isSuccess() || map == null || obj == null)) {
                synchronized (map) {
                    zzcy com_google_android_gms_wearable_internal_zzcy = (zzcy) map.remove(obj);
                    if (com_google_android_gms_wearable_internal_zzcy != null) {
                        com_google_android_gms_wearable_internal_zzcy.clear();
                    }
                }
            }
            zzaa(status);
        }
    }

    private static class zzb<T> extends zzb<Status> {
        private WeakReference<Map<T, zzcy<T>>> zzbUE;
        private WeakReference<T> zzbUF;

        zzb(Map<T, zzcy<T>> map, T t, com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status) {
            super(com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status);
            this.zzbUE = new WeakReference(map);
            this.zzbUF = new WeakReference(t);
        }

        public void zza(Status status) {
            Map map = (Map) this.zzbUE.get();
            Object obj = this.zzbUF.get();
            if (!(status.getStatus().getStatusCode() != 4002 || map == null || obj == null)) {
                synchronized (map) {
                    zzcy com_google_android_gms_wearable_internal_zzcy = (zzcy) map.remove(obj);
                    if (com_google_android_gms_wearable_internal_zzcy != null) {
                        com_google_android_gms_wearable_internal_zzcy.clear();
                    }
                }
            }
            zzaa(status);
        }
    }

    zzbx() {
    }

    public void zza(zzcx com_google_android_gms_wearable_internal_zzcx, com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status, T t) throws RemoteException {
        synchronized (this.zzaWg) {
            zzcy com_google_android_gms_wearable_internal_zzcy = (zzcy) this.zzaWg.remove(t);
            if (com_google_android_gms_wearable_internal_zzcy == null) {
                com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status.setResult(new Status(4002));
                return;
            }
            com_google_android_gms_wearable_internal_zzcy.clear();
            ((zzbw) com_google_android_gms_wearable_internal_zzcx.zzxD()).zza(new zzb(this.zzaWg, t, com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status), new zzck(com_google_android_gms_wearable_internal_zzcy));
        }
    }

    public void zza(zzcx com_google_android_gms_wearable_internal_zzcx, com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status, T t, zzcy<T> com_google_android_gms_wearable_internal_zzcy_T) throws RemoteException {
        synchronized (this.zzaWg) {
            if (this.zzaWg.get(t) != null) {
                com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status.setResult(new Status(4001));
                return;
            }
            this.zzaWg.put(t, com_google_android_gms_wearable_internal_zzcy_T);
            try {
                ((zzbw) com_google_android_gms_wearable_internal_zzcx.zzxD()).zza(new zza(this.zzaWg, t, com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status), new zzc(com_google_android_gms_wearable_internal_zzcy_T));
            } catch (RemoteException e) {
                this.zzaWg.remove(t);
                throw e;
            }
        }
    }

    public void zzfE(IBinder iBinder) {
        synchronized (this.zzaWg) {
            zzbw zzfD = com.google.android.gms.wearable.internal.zzbw.zza.zzfD(iBinder);
            zzbu com_google_android_gms_wearable_internal_zzcw_zzo = new zzo();
            for (Entry entry : this.zzaWg.entrySet()) {
                zzcy com_google_android_gms_wearable_internal_zzcy = (zzcy) entry.getValue();
                try {
                    zzfD.zza(com_google_android_gms_wearable_internal_zzcw_zzo, new zzc(com_google_android_gms_wearable_internal_zzcy));
                    if (Log.isLoggable("WearableClient", 2)) {
                        String valueOf = String.valueOf(entry.getKey());
                        String valueOf2 = String.valueOf(com_google_android_gms_wearable_internal_zzcy);
                        Log.d("WearableClient", new StringBuilder((String.valueOf(valueOf).length() + 27) + String.valueOf(valueOf2).length()).append("onPostInitHandler: added: ").append(valueOf).append("/").append(valueOf2).toString());
                    }
                } catch (RemoteException e) {
                    String valueOf3 = String.valueOf(entry.getKey());
                    String valueOf4 = String.valueOf(com_google_android_gms_wearable_internal_zzcy);
                    Log.d("WearableClient", new StringBuilder((String.valueOf(valueOf3).length() + 32) + String.valueOf(valueOf4).length()).append("onPostInitHandler: Didn't add: ").append(valueOf3).append("/").append(valueOf4).toString());
                }
            }
        }
    }
}
