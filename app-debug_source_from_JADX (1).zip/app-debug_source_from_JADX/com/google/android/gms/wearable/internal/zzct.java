package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import java.util.List;

public class zzct implements Creator<zzcs> {
    static void zza(zzcs com_google_android_gms_wearable_internal_zzcs, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 2, com_google_android_gms_wearable_internal_zzcs.statusCode);
        zzc.zza(parcel, 3, com_google_android_gms_wearable_internal_zzcs.zzbUP);
        zzc.zzc(parcel, 4, com_google_android_gms_wearable_internal_zzcs.zzbUR, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzlv(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpX(i);
    }

    public zzcs zzlv(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        long j = 0;
        List list = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 3:
                    j = zzb.zzi(parcel, zzaX);
                    break;
                case 4:
                    list = zzb.zzc(parcel, zzaX, zzcg.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzcs(i, j, list);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzcs[] zzpX(int i) {
        return new zzcs[i];
    }
}
