package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.internal.zzabh;
import com.google.android.gms.wearable.Channel;
import com.google.android.gms.wearable.ChannelApi;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import com.google.android.gms.wearable.ChannelApi.OpenChannelResult;

public final class zzq implements ChannelApi {

    class C17902 implements zza<ChannelListener> {
        final /* synthetic */ IntentFilter[] zzbTK;

        C17902(IntentFilter[] intentFilterArr) {
            this.zzbTK = intentFilterArr;
        }

        public void zza(zzcx com_google_android_gms_wearable_internal_zzcx, com.google.android.gms.internal.zzaad.zzb<Status> com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status, ChannelListener channelListener, zzabh<ChannelListener> com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_ChannelApi_ChannelListener) throws RemoteException {
            com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) com_google_android_gms_internal_zzaad_zzb_com_google_android_gms_common_api_Status, channelListener, (zzabh) com_google_android_gms_internal_zzabh_com_google_android_gms_wearable_ChannelApi_ChannelListener, null, this.zzbTK);
        }
    }

    static final class zza implements OpenChannelResult {
        private final Status zzair;
        private final Channel zzbTS;

        zza(Status status, Channel channel) {
            this.zzair = (Status) zzac.zzw(status);
            this.zzbTS = channel;
        }

        public Channel getChannel() {
            return this.zzbTS;
        }

        public Status getStatus() {
            return this.zzair;
        }
    }

    static final class zzb extends zzm<Status> {
        private final String zzaiJ;
        private ChannelListener zzbTT;

        zzb(GoogleApiClient googleApiClient, ChannelListener channelListener, String str) {
            super(googleApiClient);
            this.zzbTT = (ChannelListener) zzac.zzw(channelListener);
            this.zzaiJ = str;
        }

        protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
            com_google_android_gms_wearable_internal_zzcx.zza((com.google.android.gms.internal.zzaad.zzb) this, this.zzbTT, this.zzaiJ);
            this.zzbTT = null;
        }

        public Status zzb(Status status) {
            this.zzbTT = null;
            return status;
        }

        public /* synthetic */ Result zzc(Status status) {
            return zzb(status);
        }
    }

    private static zza<ChannelListener> zza(IntentFilter[] intentFilterArr) {
        return new C17902(intentFilterArr);
    }

    public PendingResult<Status> addListener(GoogleApiClient googleApiClient, ChannelListener channelListener) {
        zzac.zzb(googleApiClient, "client is null");
        zzac.zzb(channelListener, "listener is null");
        return zzb.zza(googleApiClient, zza(new IntentFilter[]{zzcv.zzip(ChannelApi.ACTION_CHANNEL_EVENT)}), channelListener);
    }

    public PendingResult<OpenChannelResult> openChannel(GoogleApiClient googleApiClient, final String str, final String str2) {
        zzac.zzb(googleApiClient, "client is null");
        zzac.zzb(str, "nodeId is null");
        zzac.zzb(str2, "path is null");
        return googleApiClient.zza(new zzm<OpenChannelResult>(this, googleApiClient) {
            protected void zza(zzcx com_google_android_gms_wearable_internal_zzcx) throws RemoteException {
                com_google_android_gms_wearable_internal_zzcx.zze(this, str, str2);
            }

            public OpenChannelResult zzbT(Status status) {
                return new zza(status, null);
            }

            public /* synthetic */ Result zzc(Status status) {
                return zzbT(status);
            }
        });
    }

    public PendingResult<Status> removeListener(GoogleApiClient googleApiClient, ChannelListener channelListener) {
        zzac.zzb(googleApiClient, "client is null");
        zzac.zzb(channelListener, "listener is null");
        return googleApiClient.zza(new zzb(googleApiClient, channelListener, null));
    }
}
