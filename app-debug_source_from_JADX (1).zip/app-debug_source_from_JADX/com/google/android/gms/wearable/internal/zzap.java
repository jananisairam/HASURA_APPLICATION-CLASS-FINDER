package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzap implements Creator<zzao> {
    static void zza(zzao com_google_android_gms_wearable_internal_zzao, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, com_google_android_gms_wearable_internal_zzao.getUri(), i, false);
        zzc.zza(parcel, 4, com_google_android_gms_wearable_internal_zzao.zzUg(), false);
        zzc.zza(parcel, 5, com_google_android_gms_wearable_internal_zzao.getData(), false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzkY(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpA(i);
    }

    public zzao zzkY(Parcel parcel) {
        byte[] bArr = null;
        int zzaY = zzb.zzaY(parcel);
        Bundle bundle = null;
        Uri uri = null;
        while (parcel.dataPosition() < zzaY) {
            Bundle bundle2;
            Uri uri2;
            byte[] bArr2;
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    byte[] bArr3 = bArr;
                    bundle2 = bundle;
                    uri2 = (Uri) zzb.zza(parcel, zzaX, Uri.CREATOR);
                    bArr2 = bArr3;
                    break;
                case 4:
                    uri2 = uri;
                    Bundle zzs = zzb.zzs(parcel, zzaX);
                    bArr2 = bArr;
                    bundle2 = zzs;
                    break;
                case 5:
                    bArr2 = zzb.zzt(parcel, zzaX);
                    bundle2 = bundle;
                    uri2 = uri;
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    bArr2 = bArr;
                    bundle2 = bundle;
                    uri2 = uri;
                    break;
            }
            uri = uri2;
            bundle = bundle2;
            bArr = bArr2;
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzao(uri, bundle, bArr);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzao[] zzpA(int i) {
        return new zzao[i];
    }
}
