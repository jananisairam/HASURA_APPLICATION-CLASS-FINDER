package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataItem;

public class zzai implements DataEvent {
    private int zzakD;
    private DataItem zzbUo;

    public zzai(DataEvent dataEvent) {
        this.zzakD = dataEvent.getType();
        this.zzbUo = (DataItem) dataEvent.getDataItem().freeze();
    }

    public /* synthetic */ Object freeze() {
        return zzUv();
    }

    public DataItem getDataItem() {
        return this.zzbUo;
    }

    public int getType() {
        return this.zzakD;
    }

    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        String str = getType() == 1 ? "changed" : getType() == 2 ? "deleted" : "unknown";
        String valueOf = String.valueOf(getDataItem());
        return new StringBuilder((String.valueOf(str).length() + 35) + String.valueOf(valueOf).length()).append("DataEventEntity{ type=").append(str).append(", dataitem=").append(valueOf).append(" }").toString();
    }

    public DataEvent zzUv() {
        return this;
    }
}
