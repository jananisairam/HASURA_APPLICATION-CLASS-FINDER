package com.google.android.gms.wearable;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzg implements Creator<ConnectionConfiguration> {
    static void zza(ConnectionConfiguration connectionConfiguration, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 2, connectionConfiguration.getName(), false);
        zzc.zza(parcel, 3, connectionConfiguration.getAddress(), false);
        zzc.zzc(parcel, 4, connectionConfiguration.getType());
        zzc.zzc(parcel, 5, connectionConfiguration.getRole());
        zzc.zza(parcel, 6, connectionConfiguration.isEnabled());
        zzc.zza(parcel, 7, connectionConfiguration.isConnected());
        zzc.zza(parcel, 8, connectionConfiguration.zzUe(), false);
        zzc.zza(parcel, 9, connectionConfiguration.zzUf());
        zzc.zza(parcel, 10, connectionConfiguration.getNodeId(), false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzkL(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzpk(i);
    }

    public ConnectionConfiguration zzkL(Parcel parcel) {
        String str = null;
        boolean z = false;
        int zzaY = zzb.zzaY(parcel);
        String str2 = null;
        boolean z2 = false;
        boolean z3 = false;
        int i = 0;
        int i2 = 0;
        String str3 = null;
        String str4 = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 2:
                    str4 = zzb.zzq(parcel, zzaX);
                    break;
                case 3:
                    str3 = zzb.zzq(parcel, zzaX);
                    break;
                case 4:
                    i2 = zzb.zzg(parcel, zzaX);
                    break;
                case 5:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 6:
                    z3 = zzb.zzc(parcel, zzaX);
                    break;
                case 7:
                    z2 = zzb.zzc(parcel, zzaX);
                    break;
                case 8:
                    str2 = zzb.zzq(parcel, zzaX);
                    break;
                case 9:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                case 10:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new ConnectionConfiguration(str4, str3, i2, i, z3, z2, str2, z, str);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public ConnectionConfiguration[] zzpk(int i) {
        return new ConnectionConfiguration[i];
    }
}
