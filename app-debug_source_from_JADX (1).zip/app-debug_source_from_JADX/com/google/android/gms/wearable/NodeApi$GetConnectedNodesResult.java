package com.google.android.gms.wearable;

import com.google.android.gms.common.api.Result;
import java.util.List;

public interface NodeApi$GetConnectedNodesResult extends Result {
    List<Node> getNodes();
}
