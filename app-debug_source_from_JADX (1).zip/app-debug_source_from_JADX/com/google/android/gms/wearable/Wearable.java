package com.google.android.gms.wearable;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.Optional;
import com.google.android.gms.common.api.Api.zza;
import com.google.android.gms.common.api.Api.zzf;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.wearable.internal.zzag;
import com.google.android.gms.wearable.internal.zzah;
import com.google.android.gms.wearable.internal.zzby;
import com.google.android.gms.wearable.internal.zzcb;
import com.google.android.gms.wearable.internal.zzcu;
import com.google.android.gms.wearable.internal.zzcx;
import com.google.android.gms.wearable.internal.zzda;
import com.google.android.gms.wearable.internal.zzg;
import com.google.android.gms.wearable.internal.zzj;
import com.google.android.gms.wearable.internal.zzn;
import com.google.android.gms.wearable.internal.zzq;

public class Wearable {
    public static final Api<WearableOptions> API = new Api("Wearable.API", zzaie, zzaid);
    public static final CapabilityApi CapabilityApi = new zzn();
    public static final ChannelApi ChannelApi = new zzq();
    public static final DataApi DataApi = new zzah();
    public static final MessageApi MessageApi = new zzby();
    public static final NodeApi NodeApi = new zzcb();
    public static final zzf<zzcx> zzaid = new zzf();
    private static final zza<zzcx, WearableOptions> zzaie = new C17491();
    public static final zzc zzbSZ = new zzj();
    public static final zza zzbTa = new zzg();
    public static final zzf zzbTb = new zzag();
    public static final zzi zzbTc = new zzcu();
    public static final zzj zzbTd = new zzda();

    class C17491 extends zza<zzcx, WearableOptions> {
        C17491() {
        }

        public zzcx zza(Context context, Looper looper, com.google.android.gms.common.internal.zzg com_google_android_gms_common_internal_zzg, WearableOptions wearableOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            if (wearableOptions == null) {
                WearableOptions wearableOptions2 = new WearableOptions(new Builder());
            }
            return new zzcx(context, looper, connectionCallbacks, onConnectionFailedListener, com_google_android_gms_common_internal_zzg);
        }
    }

    public static final class WearableOptions implements Optional {

        public static class Builder {
            public WearableOptions build() {
                return new WearableOptions();
            }
        }

        private WearableOptions(Builder builder) {
        }
    }

    private Wearable() {
    }
}
