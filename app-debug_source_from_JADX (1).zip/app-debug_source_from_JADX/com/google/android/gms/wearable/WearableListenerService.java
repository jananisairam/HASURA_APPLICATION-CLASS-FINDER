package com.google.android.gms.wearable;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Binder;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.util.zzy;
import com.google.android.gms.wearable.CapabilityApi.CapabilityListener;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import com.google.android.gms.wearable.internal.zzbz;
import com.google.android.gms.wearable.internal.zzcc;
import com.google.android.gms.wearable.internal.zzcz;
import com.google.android.gms.wearable.internal.zzh;
import com.google.android.gms.wearable.internal.zzk;
import com.google.android.gms.wearable.internal.zzo;
import com.google.android.gms.wearable.internal.zzs;
import java.util.List;

public abstract class WearableListenerService extends Service implements CapabilityListener, ChannelListener, DataListener, MessageListener, NodeListener {
    public static final String BIND_LISTENER_INTENT_ACTION = "com.google.android.gms.wearable.BIND_LISTENER";
    private IBinder zzaFz;
    private ComponentName zzbTe;
    private zzb zzbTf;
    private Intent zzbTg;
    private Looper zzbTh;
    private final Object zzbTi = new Object();
    private boolean zzbTj;

    private class zza implements ServiceConnection {
        private zza(WearableListenerService wearableListenerService) {
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        }

        public void onServiceDisconnected(ComponentName componentName) {
        }
    }

    private final class zzb extends Handler {
        private boolean started;
        private final zza zzbTk = new zza();
        final /* synthetic */ WearableListenerService zzbTl;

        zzb(WearableListenerService wearableListenerService, Looper looper) {
            this.zzbTl = wearableListenerService;
            super(looper);
        }

        @SuppressLint({"UntrackedBindService"})
        private synchronized void zzUi() {
            if (!this.started) {
                if (Log.isLoggable("WearableLS", 2)) {
                    String valueOf = String.valueOf(this.zzbTl.zzbTe);
                    Log.v("WearableLS", new StringBuilder(String.valueOf(valueOf).length() + 13).append("bindService: ").append(valueOf).toString());
                }
                this.zzbTl.bindService(this.zzbTl.zzbTg, this.zzbTk, 1);
                this.started = true;
            }
        }

        @SuppressLint({"UntrackedBindService"})
        private synchronized void zzio(String str) {
            if (this.started) {
                if (Log.isLoggable("WearableLS", 2)) {
                    String valueOf = String.valueOf(this.zzbTl.zzbTe);
                    Log.v("WearableLS", new StringBuilder((String.valueOf(str).length() + 17) + String.valueOf(valueOf).length()).append("unbindService: ").append(str).append(", ").append(valueOf).toString());
                }
                try {
                    this.zzbTl.unbindService(this.zzbTk);
                } catch (Throwable e) {
                    Log.e("WearableLS", "Exception when unbinding from local service", e);
                }
                this.started = false;
            }
        }

        public void dispatchMessage(Message message) {
            zzUi();
            try {
                super.dispatchMessage(message);
            } finally {
                if (!hasMessages(0)) {
                    zzio("dispatch");
                }
            }
        }

        void quit() {
            getLooper().quit();
            zzio("quit");
        }
    }

    private final class zzc extends com.google.android.gms.wearable.internal.zzbv.zza {
        final /* synthetic */ WearableListenerService zzbTl;
        private volatile int zzbTm;

        private zzc(WearableListenerService wearableListenerService) {
            this.zzbTl = wearableListenerService;
            this.zzbTm = -1;
        }

        private boolean zzUj() {
            int callingUid = Binder.getCallingUid();
            if (callingUid == this.zzbTm) {
                return true;
            }
            if (zzcz.zzck(this.zzbTl).zziq("com.google.android.wearable.app.cn") && zzy.zzc(this.zzbTl, callingUid, "com.google.android.wearable.app.cn")) {
                this.zzbTm = callingUid;
                return true;
            } else if (zzy.zzf(this.zzbTl, callingUid)) {
                this.zzbTm = callingUid;
                return true;
            } else {
                Log.e("WearableLS", "Caller is not GooglePlayServices; caller UID: " + callingUid);
                return false;
            }
        }

        private boolean zza(Runnable runnable, String str, Object obj) {
            if (Log.isLoggable("WearableLS", 3)) {
                Log.d("WearableLS", String.format("%s: %s %s", new Object[]{str, this.zzbTl.zzbTe.toString(), obj}));
            }
            if (!zzUj()) {
                return false;
            }
            synchronized (this.zzbTl.zzbTi) {
                if (this.zzbTl.zzbTj) {
                    return false;
                }
                this.zzbTl.zzbTf.post(runnable);
                return true;
            }
        }

        public void onConnectedNodes(final List<zzcc> list) {
            zza(new Runnable(this) {
                final /* synthetic */ zzc zzbTo;

                public void run() {
                    this.zzbTo.zzbTl.onConnectedNodes(list);
                }
            }, "onConnectedNodes", list);
        }

        public void zza(final zzbz com_google_android_gms_wearable_internal_zzbz) {
            zza(new Runnable(this) {
                final /* synthetic */ zzc zzbTo;

                public void run() {
                    this.zzbTo.zzbTl.onMessageReceived(com_google_android_gms_wearable_internal_zzbz);
                }
            }, "onMessageReceived", com_google_android_gms_wearable_internal_zzbz);
        }

        public void zza(final zzcc com_google_android_gms_wearable_internal_zzcc) {
            zza(new Runnable(this) {
                final /* synthetic */ zzc zzbTo;

                public void run() {
                    this.zzbTo.zzbTl.onPeerConnected(com_google_android_gms_wearable_internal_zzcc);
                }
            }, "onPeerConnected", com_google_android_gms_wearable_internal_zzcc);
        }

        public void zza(final zzh com_google_android_gms_wearable_internal_zzh) {
            zza(new Runnable(this) {
                final /* synthetic */ zzc zzbTo;

                public void run() {
                    this.zzbTo.zzbTl.onEntityUpdate(com_google_android_gms_wearable_internal_zzh);
                }
            }, "onEntityUpdate", com_google_android_gms_wearable_internal_zzh);
        }

        public void zza(final zzk com_google_android_gms_wearable_internal_zzk) {
            zza(new Runnable(this) {
                final /* synthetic */ zzc zzbTo;

                public void run() {
                    this.zzbTo.zzbTl.onNotificationReceived(com_google_android_gms_wearable_internal_zzk);
                }
            }, "onNotificationReceived", com_google_android_gms_wearable_internal_zzk);
        }

        public void zza(final zzo com_google_android_gms_wearable_internal_zzo) {
            zza(new Runnable(this) {
                final /* synthetic */ zzc zzbTo;

                public void run() {
                    this.zzbTo.zzbTl.onCapabilityChanged(com_google_android_gms_wearable_internal_zzo);
                }
            }, "onConnectedCapabilityChanged", com_google_android_gms_wearable_internal_zzo);
        }

        public void zza(final zzs com_google_android_gms_wearable_internal_zzs) {
            zza(new Runnable(this) {
                final /* synthetic */ zzc zzbTo;

                public void run() {
                    com_google_android_gms_wearable_internal_zzs.zza(this.zzbTo.zzbTl);
                }
            }, "onChannelEvent", com_google_android_gms_wearable_internal_zzs);
        }

        public void zzaq(final DataHolder dataHolder) {
            Runnable c17511 = new Runnable(this) {
                final /* synthetic */ zzc zzbTo;

                public void run() {
                    DataEventBuffer dataEventBuffer = new DataEventBuffer(dataHolder);
                    try {
                        this.zzbTo.zzbTl.onDataChanged(dataEventBuffer);
                    } finally {
                        dataEventBuffer.release();
                    }
                }
            };
            try {
                String valueOf = String.valueOf(dataHolder);
                if (!zza(c17511, "onDataItemChanged", new StringBuilder(String.valueOf(valueOf).length() + 18).append(valueOf).append(", rows=").append(dataHolder.getCount()).toString())) {
                }
            } finally {
                dataHolder.close();
            }
        }

        public void zzb(final zzcc com_google_android_gms_wearable_internal_zzcc) {
            zza(new Runnable(this) {
                final /* synthetic */ zzc zzbTo;

                public void run() {
                    this.zzbTo.zzbTl.onPeerDisconnected(com_google_android_gms_wearable_internal_zzcc);
                }
            }, "onPeerDisconnected", com_google_android_gms_wearable_internal_zzcc);
        }
    }

    public Looper getLooper() {
        if (this.zzbTh == null) {
            HandlerThread handlerThread = new HandlerThread("WearableListenerService");
            handlerThread.start();
            this.zzbTh = handlerThread.getLooper();
        }
        return this.zzbTh;
    }

    public final IBinder onBind(Intent intent) {
        return BIND_LISTENER_INTENT_ACTION.equals(intent.getAction()) ? this.zzaFz : null;
    }

    public void onCapabilityChanged(CapabilityInfo capabilityInfo) {
    }

    public void onChannelClosed(Channel channel, int i, int i2) {
    }

    public void onChannelOpened(Channel channel) {
    }

    public void onConnectedNodes(List<Node> list) {
    }

    public void onCreate() {
        super.onCreate();
        this.zzbTe = new ComponentName(this, getClass().getName());
        if (Log.isLoggable("WearableLS", 3)) {
            String valueOf = String.valueOf(this.zzbTe);
            Log.d("WearableLS", new StringBuilder(String.valueOf(valueOf).length() + 10).append("onCreate: ").append(valueOf).toString());
        }
        this.zzbTf = new zzb(this, getLooper());
        this.zzbTg = new Intent(BIND_LISTENER_INTENT_ACTION);
        this.zzbTg.setComponent(this.zzbTe);
        this.zzaFz = new zzc();
    }

    public void onDataChanged(DataEventBuffer dataEventBuffer) {
    }

    public void onDestroy() {
        if (Log.isLoggable("WearableLS", 3)) {
            String valueOf = String.valueOf(this.zzbTe);
            Log.d("WearableLS", new StringBuilder(String.valueOf(valueOf).length() + 11).append("onDestroy: ").append(valueOf).toString());
        }
        synchronized (this.zzbTi) {
            this.zzbTj = true;
            if (this.zzbTf == null) {
                String valueOf2 = String.valueOf(this.zzbTe);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf2).length() + 111).append("onDestroy: mServiceHandler not set, did you override onCreate() but forget to call super.onCreate()? component=").append(valueOf2).toString());
            } else {
                this.zzbTf.quit();
            }
        }
        super.onDestroy();
    }

    public void onEntityUpdate(zzb com_google_android_gms_wearable_zzb) {
    }

    public void onInputClosed(Channel channel, int i, int i2) {
    }

    public void onMessageReceived(MessageEvent messageEvent) {
    }

    public void onNotificationReceived(zzd com_google_android_gms_wearable_zzd) {
    }

    public void onOutputClosed(Channel channel, int i, int i2) {
    }

    public void onPeerConnected(Node node) {
    }

    public void onPeerDisconnected(Node node) {
    }
}
