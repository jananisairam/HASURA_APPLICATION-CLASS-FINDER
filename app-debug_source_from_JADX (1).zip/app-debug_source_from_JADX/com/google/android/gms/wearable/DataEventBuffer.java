package com.google.android.gms.wearable;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.data.zzf;
import com.google.android.gms.wearable.internal.zzaj;

public class DataEventBuffer extends zzf<DataEvent> implements Result {
    private final Status zzair;

    public DataEventBuffer(DataHolder dataHolder) {
        super(dataHolder);
        this.zzair = new Status(dataHolder.getStatusCode());
    }

    public Status getStatus() {
        return this.zzair;
    }

    protected DataEvent zzC(int i, int i2) {
        return new zzaj(this.zzaBi, i, i2);
    }

    protected /* synthetic */ Object zzo(int i, int i2) {
        return zzC(i, i2);
    }

    protected String zzxn() {
        return "path";
    }
}
