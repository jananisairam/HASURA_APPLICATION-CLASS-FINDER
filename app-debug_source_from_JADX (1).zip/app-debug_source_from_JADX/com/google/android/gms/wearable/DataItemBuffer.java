package com.google.android.gms.wearable;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.data.zzf;
import com.google.android.gms.wearable.internal.zzaq;

public class DataItemBuffer extends zzf<DataItem> implements Result {
    private final Status zzair;

    public DataItemBuffer(DataHolder dataHolder) {
        super(dataHolder);
        this.zzair = new Status(dataHolder.getStatusCode());
    }

    public Status getStatus() {
        return this.zzair;
    }

    protected DataItem zzD(int i, int i2) {
        return new zzaq(this.zzaBi, i, i2);
    }

    protected /* synthetic */ Object zzo(int i, int i2) {
        return zzD(i, i2);
    }

    protected String zzxn() {
        return "path";
    }
}
