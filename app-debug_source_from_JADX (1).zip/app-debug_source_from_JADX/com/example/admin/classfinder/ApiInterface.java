package com.example.admin.classfinder;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiInterface {
    @GET("classes/{classPath}")
    Call<List<ClassesSearch>> getClasses(@Path("classPath") String str);
}
