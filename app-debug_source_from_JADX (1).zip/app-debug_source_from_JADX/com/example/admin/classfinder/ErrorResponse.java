package com.example.admin.classfinder;

import com.google.gson.annotations.SerializedName;

public class ErrorResponse {
    @SerializedName("error")
    String error;

    public String getError() {
        return this.error;
    }
}
