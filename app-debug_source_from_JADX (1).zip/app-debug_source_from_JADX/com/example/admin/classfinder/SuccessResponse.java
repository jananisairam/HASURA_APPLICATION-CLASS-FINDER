package com.example.admin.classfinder;

import com.google.gson.annotations.SerializedName;

public class SuccessResponse {
    @SerializedName("success")
    String success;

    public String getResponse() {
        return this.success;
    }
}
