package com.example.admin.classfinder;

import com.google.gson.annotations.SerializedName;

public class ClassesSearch {
    @SerializedName("__v")
    Integer __v;
    @SerializedName("classname")
    String classname;
    @SerializedName("contact")
    String contact;
    @SerializedName("_id")
    String id;
    @SerializedName("institutename")
    String instituename;
    @SerializedName("location")
    String location;

    public String getId() {
        return this.id;
    }

    public String getClassname() {
        return this.classname;
    }

    public String getInstituename() {
        return this.instituename;
    }

    public String getLocation() {
        return this.location;
    }

    public String getContact() {
        return this.contact;
    }

    public Integer get__v() {
        return this.__v;
    }
}
