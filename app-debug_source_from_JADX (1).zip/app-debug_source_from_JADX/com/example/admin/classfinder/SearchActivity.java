package com.example.admin.classfinder;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Spinner;

public class SearchActivity extends AppCompatActivity {
    private Spinner class_selector;
    private Button search;

    class C03511 implements OnClickListener {
        C03511() {
        }

        public void onClick(View view) {
            SearchActivity.this.navigateToSearchResultActivity(String.valueOf(SearchActivity.this.class_selector.getSelectedItem()));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0349R.layout.activity_search);
        this.class_selector = (Spinner) findViewById(C0349R.id.Class_Selector);
        this.search = (Button) findViewById(C0349R.id.search_specified_classes);
        this.search.setOnClickListener(new C03511());
    }

    private void navigateToSearchResultActivity(String selected_class) {
        Intent intent = new Intent(this, SearchResultActivity.class);
        intent.putExtra("selected_class", selected_class);
        startActivity(intent);
    }
}
