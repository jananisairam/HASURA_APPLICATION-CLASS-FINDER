package com.example.admin.classfinder;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailedSearchResultActivity extends AppCompatActivity {
    Bundle bundle;
    String d_Contact = "";
    String d_address = "";
    TextView d_address_;
    String d_class_name = "";
    TextView d_contact_;
    String d_institute_name = "";
    TextView d_institute_name_;
    int id1 = 0;
    ImageView img_view;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0349R.layout.activity_detailed_search_result);
        this.bundle = getIntent().getExtras();
        this.d_class_name = this.bundle.getString("class_name").toString();
        this.d_address = this.bundle.getString("address").toString();
        this.d_institute_name = this.bundle.getString("institute_name").toString();
        this.d_Contact = this.bundle.getString("Contact").toString();
        this.img_view = (ImageView) findViewById(C0349R.id.d_listview_image);
        this.d_institute_name_ = (TextView) findViewById(C0349R.id.d_institute_name__);
        this.d_address_ = (TextView) findViewById(C0349R.id.d_address_);
        this.d_contact_ = (TextView) findViewById(C0349R.id.d_contact_);
        this.id1 = getResources().getIdentifier(this.d_class_name.toLowerCase() + "dr", "drawable", getPackageName());
        this.img_view.setImageResource(this.id1);
        this.d_institute_name_.setText(this.d_institute_name);
        this.d_address_.setText(this.d_address);
        this.d_contact_.setText(this.d_Contact);
    }
}
