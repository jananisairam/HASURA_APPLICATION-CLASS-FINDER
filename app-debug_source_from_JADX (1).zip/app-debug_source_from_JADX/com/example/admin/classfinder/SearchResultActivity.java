package com.example.admin.classfinder;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchResultActivity extends AppCompatActivity {
    ClassListAdapter classListAdapter;
    ProgressDialog progressDialog;
    RecyclerView recyclerView;
    String selected_class = "";

    class C03521 implements Callback<List<ClassesSearch>> {
        C03521() {
        }

        public void onResponse(Call<List<ClassesSearch>> call, Response<List<ClassesSearch>> response) {
            SearchResultActivity.this.progressDialog.dismiss();
            if (response.isSuccessful()) {
                SearchResultActivity.this.progressDialog.dismiss();
                Toast.makeText(SearchResultActivity.this, "Response Obatined", 0).show();
                SearchResultActivity.this.classListAdapter.setData((List) response.body());
                return;
            }
            Toast.makeText(SearchResultActivity.this, "Something went Wrong", 0).show();
        }

        public void onFailure(Call<List<ClassesSearch>> call, Throwable t) {
            SearchResultActivity.this.progressDialog.dismiss();
            Toast.makeText(SearchResultActivity.this, "Connection Error", 0).show();
        }
    }

    public class ClassListAdapter extends Adapter<ClassItemViewHolder> {
        String Contact = "";
        String address = "";
        String class_name = "";
        List<ClassesSearch> classlist = new ArrayList();
        int id = 0;
        String institue_name = "";

        class C03531 implements OnClickListener {
            C03531() {
            }

            public void onClick(View view) {
                Intent intent = new Intent(SearchResultActivity.this, DetailedSearchResultActivity.class);
                intent.putExtra("class_name", ClassListAdapter.this.class_name);
                intent.putExtra("address", ClassListAdapter.this.address);
                intent.putExtra("Contact", ClassListAdapter.this.Contact);
                intent.putExtra("institute_name", ClassListAdapter.this.institue_name);
                SearchResultActivity.this.startActivity(intent);
            }
        }

        public ClassItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new ClassItemViewHolder(LayoutInflater.from(parent.getContext()).inflate(C0349R.layout.layout_class, parent, false));
        }

        public void onBindViewHolder(ClassItemViewHolder holder, int position) {
            this.class_name = ((ClassesSearch) this.classlist.get(position)).getClassname();
            this.address = ((ClassesSearch) this.classlist.get(position)).getLocation();
            this.Contact = ((ClassesSearch) this.classlist.get(position)).getContact();
            this.institue_name = ((ClassesSearch) this.classlist.get(position)).getInstituename();
            this.id = SearchResultActivity.this.getResources().getIdentifier(this.class_name.toLowerCase(), "drawable", SearchResultActivity.this.getPackageName());
            holder.classes.setText(this.class_name);
            holder.imageView.setImageResource(this.id);
            holder.address.setText(this.address);
            holder.view.setOnClickListener(new C03531());
        }

        public int getItemCount() {
            return this.classlist.size();
        }

        public void setData(List<ClassesSearch> data) {
            this.classlist = data;
            notifyDataSetChanged();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0349R.layout.activity_search_result);
        this.selected_class = getIntent().getExtras().getString("selected_class").toString();
        this.recyclerView = (RecyclerView) findViewById(C0349R.id.recyclerView);
        this.classListAdapter = new ClassListAdapter();
        this.recyclerView.setAdapter(this.classListAdapter);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        this.progressDialog = new ProgressDialog(this);
        this.progressDialog.setMessage("Fetching details");
        this.progressDialog.show();
        ApiManager.getApiInterface().getClasses(this.selected_class).enqueue(new C03521());
    }
}
