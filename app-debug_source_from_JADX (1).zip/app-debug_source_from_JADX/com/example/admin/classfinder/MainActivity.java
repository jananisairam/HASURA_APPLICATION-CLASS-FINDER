package com.example.admin.classfinder;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button register;
    Button search;

    class C03471 implements OnClickListener {
        C03471() {
        }

        public void onClick(View view) {
            MainActivity.this.navigateToSearchActivity();
        }
    }

    class C03482 implements OnClickListener {
        C03482() {
        }

        public void onClick(View view) {
            MainActivity.this.navigateToRegisterActivity();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0349R.layout.activity_main);
        this.register = (Button) findViewById(C0349R.id.Register);
        this.search = (Button) findViewById(C0349R.id.Search);
        this.search.setOnClickListener(new C03471());
        this.register.setOnClickListener(new C03482());
    }

    private void navigateToSearchActivity() {
        startActivity(new Intent(this, SearchActivity.class));
    }

    private void navigateToRegisterActivity() {
        startActivity(new Intent(this, RegisterActivity.class));
    }
}
