package com.example.admin.classfinder;

import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ClassItemViewHolder extends ViewHolder {
    TextView address;
    TextView classes;
    ImageView imageView;
    CardView view;

    public ClassItemViewHolder(View itemView) {
        super(itemView);
        this.address = (TextView) itemView.findViewById(C0349R.id.address);
        this.classes = (TextView) itemView.findViewById(C0349R.id.className);
        this.view = (CardView) itemView.findViewById(C0349R.id.card_view);
        this.imageView = (ImageView) itemView.findViewById(C0349R.id.listview_image);
    }
}
