package com.example.admin.classfinder;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    EditText address;
    Spinner class_select;
    EditText contact_no;
    EditText institute_name;
    Button register;
    String selected_class = "";

    class C03501 implements OnClickListener {
        C03501() {
        }

        public void onClick(View view) {
            if (RegisterActivity.this.isFormValid()) {
                Toast.makeText(RegisterActivity.this, "Feature Coming Soon", 0).show();
            } else {
                Toast.makeText(RegisterActivity.this, "Feature Coming Soon", 0).show();
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0349R.layout.activity_register);
        this.class_select = (Spinner) findViewById(C0349R.id.Class_Selector_Search);
        this.selected_class = this.class_select.getSelectedItem().toString();
        this.contact_no = (EditText) findViewById(C0349R.id.Contact_Number);
        this.address = (EditText) findViewById(C0349R.id.Address);
        this.institute_name = (EditText) findViewById(C0349R.id.InstitiName);
        this.register = (Button) findViewById(C0349R.id.Register_Institute);
        this.register.setOnClickListener(new C03501());
    }

    private boolean isFormValid() {
        if (this.institute_name.getText().toString().isEmpty() || this.address.getText().toString().isEmpty() || this.contact_no.getText().toString().isEmpty() || this.selected_class.isEmpty() || this.selected_class.equals("Choose a Class")) {
            return false;
        }
        return true;
    }
}
