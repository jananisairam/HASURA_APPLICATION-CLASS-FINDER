package com.example.admin.classfinder;

public class NetworkURL {
    public static final String BASE_URL = "https://class-finder-app.herokuapp.com";
}
