package com.example.admin.classfinder;

import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import okhttp3.logging.HttpLoggingInterceptor.Level;
import retrofit2.Retrofit.Builder;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiManager {
    private static ApiInterface apiInterface;

    private static void createApiInterface() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(Level.BODY);
        apiInterface = (ApiInterface) new Builder().baseUrl(NetworkURL.BASE_URL).client(new OkHttpClient.Builder().connectTimeout(1, TimeUnit.MINUTES).readTimeout(1, TimeUnit.MINUTES).writeTimeout(1, TimeUnit.MINUTES).addInterceptor(interceptor).build()).addConverterFactory(GsonConverterFactory.create()).build().create(ApiInterface.class);
    }

    public static ApiInterface getApiInterface() {
        if (apiInterface == null) {
            createApiInterface();
        }
        return apiInterface;
    }
}
